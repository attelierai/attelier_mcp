import type { Asset, Project } from "@attelier/project-schema";

export type PipelineSource = {
  id: string; kind: "input" | "url" | "search" | "library" | "connector";
  value: string; required: boolean; maxAgeHours?: number;
};
export type PipelineStage = {
  id: "collect" | "prepare" | "generate" | "fill" | "render" | "check";
  label: string; requires: string[]; produces: string[];
};
export type PipelineResource = {
  id: string; capability: "text_to_image" | "voice_generation" | "music_generation" | "image_to_video";
  input: Record<string, unknown>; maxCostUsd: number;
};
/** Test substitutions are explicit and never become the production recipe. */
export type PipelineTrialOverrides = {
  renderHeight?: 480 | 720;
  preparation?: { model: string; maxCostUsd: number };
  resources?: Record<string, { input?: Record<string, unknown>; maxCostUsd?: number; assetId?: string }>;
  sampleContent?: Record<string, string>;
};
export type PipelineRunMode = "production" | "economic" | "faithful";
export type PipelineRecipe = {
  schemaVersion: 1;
  templateProjectId: string; templateRevision: number;
  durationSeconds: number;
  inputs: Array<{ id: string; label: string; type: "text" | "data" | "library"; required: boolean; default?: unknown }>;
  sources: PipelineSource[];
  stages: PipelineStage[];
  content: Record<string, string>;
  preparation?: { model: string; instructions: string; maxOutputTokens: number; maxCostUsd: number };
  resources: PipelineResource[];
  variables: Array<{ elementId: string; from: string; property: "text.content" | "asset"; maxChars?: number; maxLines?: number; minFontSize?: number; maxPlaybackRate?: number }>;
  /** Output height; width follows the template's aspect ratio. */
  renderHeight: 480 | 720 | 1080;
  /** Final edit with an Attelier motion format instead of the template fill; the spec
   * may reference {{content.*}}, {{sources.*}} and {{assets.<id>.url}} like resources. */
  motion?: { format: string; spec: Record<string, unknown> };
  testProfiles?: { economic?: PipelineTrialOverrides; faithful?: PipelineTrialOverrides };
  /** An owned Library asset, for comparison only; it is never a successful test. */
  reference?: { assetId: string; label: string; notes?: string };
};
export type PipelineSchedule = {
  enabled: boolean; time: string; days: number[]; timezone: string; inputs: Record<string, unknown>;
};
export type PipelineLimits = { perExecutionUsd: number; perPeriodUsd: number; periodDays: number };
export type Pipeline = {
  id: string; ownerUserId: string; workspaceId: string; name: string; revision: number;
  draft: PipelineRecipe; activeVersionId: string | null; sessionId: string | null;
  schedule: PipelineSchedule; limits: PipelineLimits; scheduleActorId?: string;
  createdAt: number; updatedAt: number; lastRun?: PipelineExecution; nextRunAt?: number | null;
};
export type PipelineVersion = {
  id: string; pipelineId: string; number: number; recipe: PipelineRecipe; template: Project; createdAt: number;
};
export type PipelineCapturedSource = {
  id: string; kind: PipelineSource["kind"]; requested: string; capturedAt: number;
  publishedAt?: number; content: unknown; sha256: string;
};
export type PipelineExecution = {
  id: string; pipelineId: string; versionId: string; inputs: Record<string, unknown>;
  sources: PipelineCapturedSource[]; content: Record<string, unknown>; assets: Record<string, Asset>;
  state: "running" | "awaiting_approval" | "failed" | "cancelled" | "completed";
  stages?: Array<{ id: string; state: string; error: string | null }>;
  issues: string[]; projectId: string | null; renderJobId: string | null; renderHeight: PipelineRecipe["renderHeight"];
  estimatedCostUsd: number; actualCostUsd: number; reservedCostUsd: number;
  jobs: Array<{ resourceId: string; jobId: string; fingerprint: string }>;
  mode?: PipelineRunMode;
  sourceSnapshotId?: string;
  effectiveRecipe?: PipelineRecipe;
  differences?: string[];
  reused?: Array<{ stage: "prepare" | "generate"; resourceId?: string; runId: string }>;
  preparationFingerprint?: string;
  /** Actual motion preview height can be 540 while the native recipe uses 480. */
  outputHeight?: number;
  createdAt: number; updatedAt: number;
};
export const PIPELINE_STAGES: PipelineStage[] = [
  { id: "collect", label: "Recopilar datos", requires: [], produces: ["sources"] },
  { id: "prepare", label: "Preparar contenido", requires: ["sources"], produces: ["content"] },
  { id: "generate", label: "Generar recursos", requires: ["content"], produces: ["assets"] },
  { id: "fill", label: "Rellenar plantilla", requires: ["content", "assets"], produces: ["project"] },
  { id: "render", label: "Renderizar", requires: ["project"], produces: ["video"] },
  { id: "check", label: "Comprobar", requires: ["video"], produces: ["quality_report"] },
];
export const defaultPipelineRecipe = (projectId: string, revision: number): PipelineRecipe => ({
  schemaVersion: 1, templateProjectId: projectId, templateRevision: revision, durationSeconds: 30,
  inputs: [{ id: "headline", label: "Contenido", type: "text", required: true }], sources: [],
  stages: structuredClone(PIPELINE_STAGES), content: { headline: "{{inputs.headline}}" }, resources: [], variables: [], renderHeight: 1080,
});
