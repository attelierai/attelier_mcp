import assert from "node:assert/strict";
import test from "node:test";
import {
  assertBriefApprovedForGeneration,
  assertCreativeBriefValid,
  creativeBriefDiscoveryQuestions,
  reviseCreativeBrief,
  type CreativeBrief,
} from "./index";

const brief = (): CreativeBrief => ({
  schemaVersion: "atelier.creative-brief.v1", id: "brief-1", version: 1, status: "approved",
  objective: "Trial signups", audience: "Small teams", cta: "Start free", channel: "Instagram Reels",
  aspectRatio: "9:16", durationSeconds: 15, language: "en", voice: "warm expert", tone: "clear",
  visualDirection: "real product UI with restrained motion", concept: "From clutter to clarity",
  verifiedClaims: [{ claim: "Free trial", evidenceArtifactIds: ["source-1"] }],
  voiceoverScript: "Make work clear. Start free.", storyboard: [{ id: "s1", purpose: "hook", visual: "messy board resolves", voiceover: "Make work clear.", durationSeconds: 15, assetPlan: "owned UI capture" }],
  mediaRightsPlan: "Owned UI only", musicDirection: "light instrumental",
  estimatedCost: { currency: "USD", minimum: 0.1, maximum: 0.3, pricingStatus: "known" },
  estimatedTime: { minimumMinutes: 3, maximumMinutes: 8 }, createdAt: 1, updatedAt: 1,
});

test("generic intake asks at most three grouped material questions", () => {
  const questions = creativeBriefDiscoveryQuestions({});
  assert.equal(questions.length, 3);
  assert.deepEqual(questions.flatMap((question) => question.fields), [
    "objective", "audience", "cta", "channel", "aspectRatio", "durationSeconds",
    "language", "voice", "tone", "visualDirection",
  ]);
  assert.deepEqual(creativeBriefDiscoveryQuestions({ autonomy: "high" }), []);
});

test("sufficient intake and concrete delivery choices do not add questions", () => {
  assert.deepEqual(creativeBriefDiscoveryQuestions({ objective: "signups", audience: "teams", cta: "try", channel: "Reels", aspectRatio: "9:16", durationSeconds: 15, language: "en", voice: "warm", tone: "direct", visualDirection: "product UI" }), []);
});

test("material revisions invalidate approval and advance the version", () => {
  const result = reviseCreativeBrief(brief(), { voiceoverScript: "A materially different script." }, 2);
  assert.equal(result.requiresReapproval, true);
  assert.equal(result.brief.version, 2);
  assert.equal(result.brief.status, "awaiting_approval");
  assert.throws(() => assertBriefApprovedForGeneration(result.brief, { briefId: "brief-1", briefVersion: 1, decision: "approve_and_generate", actorId: "owner", approvedAt: 1 }), /current creative brief version/);
});

test("generation accepts only an approval bound to the current approved version", () => {
  const value = brief();
  assert.doesNotThrow(() => assertBriefApprovedForGeneration(value, { briefId: value.id, briefVersion: value.version, decision: "approve_and_generate", actorId: "owner", approvedAt: 2 }));
  assert.throws(() => assertBriefApprovedForGeneration(value, undefined), /requires approval/);
});

test("unknown pricing remains unknown instead of displaying a false zero", () => {
  const value = brief();
  value.estimatedCost = { currency: "USD", minimum: null, maximum: null, pricingStatus: "unknown" };
  assert.doesNotThrow(() => assertCreativeBriefValid(value));
  value.estimatedCost.minimum = 0;
  assert.throws(() => assertCreativeBriefValid(value), /false zero/);
});

test("duration, storyboard timing, budget and time range stay coherent", () => {
  const value = brief();
  value.durationSeconds = 10;
  assert.throws(() => assertCreativeBriefValid(value), /Storyboard timing/);
  value.storyboard[0]!.durationSeconds = 10;
  value.estimatedCost.maximum = 0.05;
  assert.throws(() => assertCreativeBriefValid(value), /budget/);
  value.estimatedCost.maximum = 0.3;
  value.estimatedTime = null;
  assert.throws(() => assertCreativeBriefValid(value), /time range/);
});
