export type ReferenceRightsDeclaration =
  | "user_owned"
  | "licensed"
  | "public_reference_only"
  | "unknown";

export type ReferenceBlueprintEvidence = {
  id: string;
  kind: "frame" | "transcript" | "metadata";
  startSeconds: number;
  endSeconds?: number;
  description: string;
  thumbnailUrl?: string;
  contentHash?: string;
};

export type ReferenceAnalysisUsage = {
  promptTokens: number;
  completionTokens: number;
  cachedPromptTokens: number;
  requestCount: number;
  retryCount: number;
};

export type ReferenceBlueprintChapter = {
  id: string;
  title: string;
  startSeconds: number;
  endSeconds: number;
  purpose: string;
  evidenceIds: string[];
};

export type ReferenceBlueprintBeat = {
  id: string;
  chapterId: string;
  startSeconds: number;
  endSeconds: number;
  narrativeFunction: string;
  picture: string;
  sound: string;
  editorialTechnique: string;
  evidenceIds: string[];
};

export type ReferenceCoverageRequirement = {
  id: string;
  beatId?: string;
  purpose: string;
  description: string;
  preferredSource: "project_media" | "library" | "stock" | "generated";
  minimumDurationSeconds: number;
  status: "missing" | "available" | "selected";
  candidateAssetIds: string[];
};

export type ReferenceBlueprint = {
  schemaVersion: "atelier.reference-blueprint.v1";
  id: string;
  projectId: string;
  version: number;
  status: "draft" | "active" | "superseded";
  source: {
    provider: "youtube" | "vimeo" | "upload" | "web";
    sourceUrl: string;
    embedUrl?: string;
    title: string;
    durationSeconds: number;
    contentHash?: string;
    rights: {
      declaration: ReferenceRightsDeclaration;
      analysisAllowed: boolean;
      trainingAllowed: boolean;
      reuseAllowed: boolean;
      note: string;
    };
  };
  objective: string;
  sourceAudienceTakeaway?: string;
  audienceTakeaway: string;
  synopsis: string;
  transcript: {
    origin: "human" | "provider" | "automatic_captions" | "local_transcription" | "unavailable";
    language?: string;
    text: string;
  };
  chapters: ReferenceBlueprintChapter[];
  beats: ReferenceBlueprintBeat[];
  style: {
    visualGrammar: string[];
    pacing: string;
    typography: string;
    sound: string;
    color: string;
    transitions: string;
  };
  transferablePatterns: string[];
  avoidCopying: string[];
  coverage: ReferenceCoverageRequirement[];
  evidence: ReferenceBlueprintEvidence[];
  analysis: {
    model: string;
    analyzerVersion: string;
    sampledFrameCount: number;
    frameObservationCount?: number;
    transcriptProvider?: string;
    models?: {
      frameVision: string;
      synthesis: string;
    };
    usage?: {
      frameVision: ReferenceAnalysisUsage;
      synthesis: ReferenceAnalysisUsage;
      totals: Omit<ReferenceAnalysisUsage, "requestCount" | "retryCount">;
    };
    requests?: Array<{
      stage: "frame_vision" | "synthesis";
      requestId: string;
      model: string;
      latencyMs: number;
      promptTokens: number;
      cachedPromptTokens: number;
      completionTokens: number;
    }>;
    cost?: {
      currency: "USD";
      basis: "measured_estimate";
      estimatedUsd: number;
      pricingSnapshotId: string;
      pricingSourceUrls: string[];
      retrievedAt: string;
      exclusions: string[];
      lineItems: Array<{
        stage: "frame_vision" | "synthesis";
        model: string;
        promptTokens: number;
        cachedPromptTokens: number;
        completionTokens: number;
        estimatedUsd: number;
      }>;
    };
    limitations: string[];
  };
  createdAt: number;
  updatedAt: number;
};

export type ReferenceBlueprintDraft = Omit<
  ReferenceBlueprint,
  "id" | "projectId" | "version" | "status" | "createdAt" | "updatedAt"
>;

export type CreativeDecisionKind =
  | "concept"
  | "script"
  | "voice"
  | "music"
  | "visual"
  | "generated_shot"
  | "rough_cut";

export type CreativeDecisionCandidate = {
  id: string;
  label: string;
  description: string;
  rationale?: string;
  preview: {
    kind: "text" | "image" | "video" | "audio";
    text?: string;
    url?: string;
    assetId?: string;
  };
};

export type CreativeDecisionPolicy = {
  subjective: boolean;
  impact: "low" | "medium" | "high";
  uncertainty: number;
  reversibility: "easy" | "moderate" | "expensive";
  estimatedCostUsd?: number;
  reason: string;
  allowAgentJudgment: boolean;
};

export type CreativeDecisionOutcome = {
  selection: "candidate" | "neither" | "use_your_judgment";
  selectedCandidateId?: string;
  feedbackTags: string[];
  note?: string;
  actorId: string;
  decidedAt: number;
};

export type CreativeDecision = {
  schemaVersion: "atelier.creative-decision.v1";
  id: string;
  projectId: string;
  projectRevision: number;
  runId?: string;
  referenceBlueprintId?: string;
  kind: CreativeDecisionKind;
  status: "open" | "resolved" | "cancelled";
  question: string;
  context: string;
  candidates: CreativeDecisionCandidate[];
  policy: CreativeDecisionPolicy;
  resumeState: "drafting" | "generating" | "editing" | "reviewing";
  outcome?: CreativeDecisionOutcome;
  createdAt: number;
  updatedAt: number;
};

export type CreativeDecisionDraft = Omit<
  CreativeDecision,
  "id" | "status" | "outcome" | "createdAt" | "updatedAt"
>;

export type CreativePreferenceEvent = {
  schemaVersion: "atelier.creative-preference-event.v1";
  id: string;
  decisionId: string;
  projectId: string;
  projectRevision: number;
  kind: CreativeDecisionKind;
  candidates: CreativeDecisionCandidate[];
  outcome: CreativeDecisionOutcome;
  context: string;
  createdAt: number;
};

const nonEmpty = (value: unknown): value is string => typeof value === "string" && value.trim().length > 0;
const validSecond = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value) && value >= 0;

export const assertReferenceBlueprintDraftValid = (draft: ReferenceBlueprintDraft): void => {
  if (draft.schemaVersion !== "atelier.reference-blueprint.v1") throw new Error("Unsupported Reference Blueprint schema version.");
  if (!nonEmpty(draft.source.sourceUrl) || !nonEmpty(draft.source.title) || !validSecond(draft.source.durationSeconds) || draft.source.durationSeconds <= 0) {
    throw new Error("Reference source URL, title and positive duration are required.");
  }
  if (!draft.source.rights.analysisAllowed) throw new Error("Reference analysis requires an explicit analysisAllowed declaration.");
  if (!nonEmpty(draft.source.rights.note)) throw new Error("Reference rights require a short declaration note.");
  if (![draft.objective, draft.audienceTakeaway, draft.synopsis].every(nonEmpty)) throw new Error("Reference objective, audience takeaway and synopsis are required.");
  if (draft.sourceAudienceTakeaway !== undefined && !nonEmpty(draft.sourceAudienceTakeaway)) throw new Error("Source audience takeaway must be non-empty when provided.");
  if (!Array.isArray(draft.chapters) || draft.chapters.length === 0 || !Array.isArray(draft.beats) || draft.beats.length === 0) {
    throw new Error("A Reference Blueprint requires timestamped chapters and beats.");
  }
  const evidenceIds = new Set(draft.evidence.map(({ id }) => id));
  if (evidenceIds.size !== draft.evidence.length || draft.evidence.some((item) => !nonEmpty(item.id) || !nonEmpty(item.description) || !validSecond(item.startSeconds) || (item.endSeconds !== undefined && (!validSecond(item.endSeconds) || item.endSeconds < item.startSeconds || item.endSeconds > draft.source.durationSeconds + 0.1)) || item.startSeconds > draft.source.durationSeconds + 0.1)) {
    throw new Error("Reference evidence requires unique IDs and valid source-relative timestamps.");
  }
  const chapterIds = new Set(draft.chapters.map(({ id }) => id));
  if (chapterIds.size !== draft.chapters.length || draft.chapters.some((chapter) => !nonEmpty(chapter.id) || !nonEmpty(chapter.title) || !nonEmpty(chapter.purpose) || !validSecond(chapter.startSeconds) || !validSecond(chapter.endSeconds) || chapter.endSeconds <= chapter.startSeconds || chapter.endSeconds > draft.source.durationSeconds + 0.1 || chapter.evidenceIds.length === 0 || chapter.evidenceIds.some((id) => !evidenceIds.has(id)))) {
    throw new Error("Reference chapters require unique IDs, valid ranges and traceable evidence.");
  }
  const beatIds = new Set(draft.beats.map(({ id }) => id));
  if (beatIds.size !== draft.beats.length || draft.beats.some((beat) => !nonEmpty(beat.id) || !chapterIds.has(beat.chapterId) || !nonEmpty(beat.narrativeFunction) || !nonEmpty(beat.picture) || !nonEmpty(beat.sound) || !nonEmpty(beat.editorialTechnique) || !validSecond(beat.startSeconds) || !validSecond(beat.endSeconds) || beat.endSeconds <= beat.startSeconds || beat.endSeconds > draft.source.durationSeconds + 0.1 || beat.evidenceIds.length === 0 || beat.evidenceIds.some((id) => !evidenceIds.has(id)))) {
    throw new Error("Reference beats require valid ranges, chapters and evidence.");
  }
  if (draft.coverage.some((item) => !nonEmpty(item.id) || !nonEmpty(item.purpose) || !nonEmpty(item.description) || !validSecond(item.minimumDurationSeconds) || item.minimumDurationSeconds <= 0 || (item.beatId !== undefined && !beatIds.has(item.beatId)))) {
    throw new Error("Coverage requirements must be actionable and point to known beats.");
  }
  if (draft.transferablePatterns.length === 0 || draft.avoidCopying.length === 0) throw new Error("Reference transfer rules and anti-copy boundaries are required.");
  if (["public_reference_only", "unknown"].includes(draft.source.rights.declaration) && (draft.source.rights.trainingAllowed || draft.source.rights.reuseAllowed)) {
    throw new Error("Public or unknown reference rights never authorize training or source reuse.");
  }
  if (draft.analysis.frameObservationCount !== undefined && (!Number.isSafeInteger(draft.analysis.frameObservationCount) || draft.analysis.frameObservationCount < 0 || draft.analysis.frameObservationCount > draft.analysis.sampledFrameCount)) {
    throw new Error("Frame observation coverage cannot exceed the sampled frame count.");
  }
  if (draft.analysis.cost && (!Number.isFinite(draft.analysis.cost.estimatedUsd) || draft.analysis.cost.estimatedUsd < 0 || draft.analysis.cost.lineItems.some((item) => !Number.isFinite(item.estimatedUsd) || item.estimatedUsd < 0))) {
    throw new Error("Reference analysis cost must be a finite non-negative measured estimate.");
  }
};

export const assertCreativeDecisionDraftValid = (draft: CreativeDecisionDraft): void => {
  if (draft.schemaVersion !== "atelier.creative-decision.v1") throw new Error("Unsupported Creative Decision schema version.");
  if (!nonEmpty(draft.projectId) || !Number.isSafeInteger(draft.projectRevision) || draft.projectRevision < 0) throw new Error("Creative Decisions require a project and pinned revision.");
  if (!nonEmpty(draft.question) || !nonEmpty(draft.context) || !nonEmpty(draft.policy.reason)) throw new Error("Creative Decision question, context and policy reason are required.");
  if (!Number.isFinite(draft.policy.uncertainty) || draft.policy.uncertainty < 0 || draft.policy.uncertainty > 1) throw new Error("Creative Decision uncertainty must be between 0 and 1.");
  if (draft.policy.estimatedCostUsd !== undefined && (!Number.isFinite(draft.policy.estimatedCostUsd) || draft.policy.estimatedCostUsd < 0)) throw new Error("Creative Decision cost cannot be negative.");
  if (!Array.isArray(draft.candidates) || draft.candidates.length < 2 || draft.candidates.length > 4) throw new Error("Creative Decisions require two to four candidates.");
  const candidateIds = new Set(draft.candidates.map(({ id }) => id));
  if (candidateIds.size !== draft.candidates.length || draft.candidates.some((candidate) => !nonEmpty(candidate.id) || !nonEmpty(candidate.label) || !nonEmpty(candidate.description) || (candidate.preview.kind === "text" ? !nonEmpty(candidate.preview.text) : !nonEmpty(candidate.preview.url) && !nonEmpty(candidate.preview.assetId)))) {
    throw new Error("Creative Decision candidates require unique IDs and usable previews.");
  }
};

export const assertCreativeDecisionOutcomeValid = (decision: CreativeDecision, outcome: CreativeDecisionOutcome): void => {
  if (outcome.selection === "candidate" && (!outcome.selectedCandidateId || !decision.candidates.some(({ id }) => id === outcome.selectedCandidateId))) {
    throw new Error("The selected candidate does not belong to this Creative Decision.");
  }
  if (outcome.selection !== "candidate" && outcome.selectedCandidateId !== undefined) throw new Error("Only a candidate selection can carry selectedCandidateId.");
  if (outcome.selection === "use_your_judgment" && !decision.policy.allowAgentJudgment) throw new Error("This Creative Decision does not allow agent judgment.");
};

export const shouldInterruptForCreativeDecision = (draft: CreativeDecisionDraft): { interrupt: boolean; reasons: string[] } => {
  assertCreativeDecisionDraftValid(draft);
  if (!draft.policy.subjective) return { interrupt: false, reasons: ["The choice is objectively testable."] };
  const reasons: string[] = [];
  if (draft.policy.impact === "high") reasons.push("high creative impact");
  if (draft.policy.uncertainty >= 0.45) reasons.push("material taste uncertainty");
  if (draft.policy.reversibility === "expensive") reasons.push("expensive to reverse");
  if ((draft.policy.estimatedCostUsd ?? 0) > 0) reasons.push("paid downstream work");
  const interrupt = reasons.length >= 2 || (draft.policy.impact === "high" && draft.policy.uncertainty >= 0.3);
  return { interrupt, reasons: interrupt ? reasons : ["Attelier has enough confidence to choose and keep the edit reversible."] };
};
