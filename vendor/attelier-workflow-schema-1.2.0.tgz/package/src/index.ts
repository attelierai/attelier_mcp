export * from "@attelier/workflow-schema/pipelines";
export type WorkflowKind =
  | "talking_head_enhancer"
  | "long_form_to_shorts"
  | "social_repurposing"
  | "restoration"
  | "generative_vfx"
  | "localization"
  | "product_ad"
  | "create_from_brief"
  | "talking_avatar"
  | "content_pipeline";
export type CreativeBriefStatus = "draft" | "awaiting_approval" | "approved" | "superseded";
export type CreativeBriefShot = { id: string; purpose: string; visual: string; voiceover: string; durationSeconds: number; assetPlan: string };
export type CreativeBrief = {
  schemaVersion: "atelier.creative-brief.v1"; id: string; version: number; status: CreativeBriefStatus;
  objective: string; audience: string; cta: string; channel: string; aspectRatio: string; durationSeconds: number;
  language: string; voice: string; tone: string; visualDirection: string; concept: string;
  verifiedClaims: Array<{ claim: string; evidenceArtifactIds: string[] }>;
  voiceoverScript: string; storyboard: CreativeBriefShot[]; mediaRightsPlan: string; musicDirection: string;
  estimatedCost: { currency: "USD"; minimum: number | null; maximum: number | null; pricingStatus: "known" | "partial" | "unknown" };
  estimatedTime: { minimumMinutes: number; maximumMinutes: number } | null;
  createdAt: number; updatedAt: number;
};
export type CreativeBriefApproval = { briefId: string; briefVersion: number; decision: "approve_and_generate" | "use_your_judgment"; actorId: string; approvedAt: number };
export type BriefIntake = Partial<Pick<CreativeBrief, "objective" | "audience" | "cta" | "channel" | "aspectRatio" | "durationSeconds" | "language" | "voice" | "tone" | "visualDirection">> & { autonomy?: "normal" | "high" };
export type DiscoveryQuestion = { fields: Array<keyof BriefIntake>; question: string };
const presentBriefValue = (value: unknown): boolean => typeof value === "string" ? value.trim().length > 0 : value !== undefined && value !== null;
export const creativeBriefDiscoveryQuestions = (input: BriefIntake): DiscoveryQuestion[] => {
  if (input.autonomy === "high") return [];
  const questions: DiscoveryQuestion[] = [];
  if (!presentBriefValue(input.objective) || !presentBriefValue(input.audience) || !presentBriefValue(input.cta)) questions.push({ fields: ["objective", "audience", "cta"], question: "What should this video achieve, who is it for, and what should they do next?" });
  if (!presentBriefValue(input.channel) || !presentBriefValue(input.aspectRatio) || !presentBriefValue(input.durationSeconds)) questions.push({ fields: ["channel", "aspectRatio", "durationSeconds"], question: "Where will it run, in which format, and for roughly how long?" });
  if (!presentBriefValue(input.language) || !presentBriefValue(input.voice) || !presentBriefValue(input.tone) || !presentBriefValue(input.visualDirection)) questions.push({ fields: ["language", "voice", "tone", "visualDirection"], question: "Which language, voice, tone, and visual direction should guide it?" });
  return questions.slice(0, 3);
};
const MATERIAL_BRIEF_FIELDS: ReadonlyArray<keyof CreativeBrief> = ["objective", "audience", "cta", "channel", "aspectRatio", "durationSeconds", "language", "voice", "tone", "visualDirection", "concept", "verifiedClaims", "voiceoverScript", "storyboard", "mediaRightsPlan", "musicDirection", "estimatedCost"];
export const assertBriefApprovedForGeneration = (brief: CreativeBrief, approval: CreativeBriefApproval | undefined): void => {
  assertCreativeBriefValid(brief);
  if (brief.status !== "approved" || !approval || approval.briefId !== brief.id || approval.briefVersion !== brief.version) throw new Error("Paid generation requires approval for the current creative brief version.");
};
export const assertCreativeBriefValid = (brief: CreativeBrief): void => {
  const required = [brief.objective, brief.audience, brief.cta, brief.channel, brief.aspectRatio, brief.language, brief.voice, brief.tone, brief.visualDirection, brief.concept, brief.voiceoverScript, brief.mediaRightsPlan, brief.musicDirection];
  if (required.some((value) => typeof value !== "string" || !value.trim())) throw new Error("Creative brief required fields cannot be empty.");
  if (!Number.isFinite(brief.durationSeconds) || brief.durationSeconds <= 0 || !Array.isArray(brief.storyboard) || brief.storyboard.length === 0) throw new Error("Creative brief duration and storyboard are required.");
  if (brief.storyboard.some((shot) => !shot.id || !shot.purpose || !shot.visual || !shot.assetPlan || !Number.isFinite(shot.durationSeconds) || shot.durationSeconds <= 0)) throw new Error("Every storyboard shot requires purpose, visual, asset plan and positive duration.");
  if (brief.verifiedClaims.some(({ claim, evidenceArtifactIds }) => !claim.trim() || !Array.isArray(evidenceArtifactIds) || evidenceArtifactIds.length === 0 || evidenceArtifactIds.some((id) => !id.trim()))) throw new Error("Every verified claim requires explicit evidence identifiers.");
  if (brief.estimatedCost.pricingStatus === "unknown" && (brief.estimatedCost.minimum !== null || brief.estimatedCost.maximum !== null)) throw new Error("Unknown pricing must remain null, never a false zero.");
  if (brief.estimatedCost.minimum !== null && brief.estimatedCost.minimum < 0 || brief.estimatedCost.maximum !== null && brief.estimatedCost.maximum < 0) throw new Error("Creative brief cost cannot be negative.");
  const storyboardDuration = brief.storyboard.reduce((sum, shot) => sum + shot.durationSeconds, 0);
  if (Math.abs(storyboardDuration - brief.durationSeconds) > 0.05) throw new Error("Storyboard timing must equal the Creative Brief duration.");
  if (brief.estimatedCost.minimum !== null && brief.estimatedCost.maximum !== null && brief.estimatedCost.maximum < brief.estimatedCost.minimum) throw new Error("Creative Brief budget cannot be below its current estimate.");
  if (!brief.estimatedTime || brief.estimatedTime.minimumMinutes < 0 || brief.estimatedTime.maximumMinutes < brief.estimatedTime.minimumMinutes) throw new Error("Creative Brief requires an honest estimated time range.");
};
export const reviseCreativeBrief = (brief: CreativeBrief, changes: Partial<CreativeBrief>, now = Date.now()): { brief: CreativeBrief; requiresReapproval: boolean } => {
  const material = MATERIAL_BRIEF_FIELDS.some((field) => changes[field] !== undefined && JSON.stringify(changes[field]) !== JSON.stringify(brief[field]));
  return { brief: { ...brief, ...changes, id: brief.id, schemaVersion: "atelier.creative-brief.v1", version: material ? brief.version + 1 : brief.version, status: material ? "awaiting_approval" : brief.status, createdAt: brief.createdAt, updatedAt: now }, requiresReapproval: material };
};
export type WorkflowStageState =
  | "pending"
  | "ready"
  | "running"
  | "awaiting_approval"
  | "retrying"
  | "blocked"
  | "failed"
  | "cancelled"
  | "completed"
  | "superseded";

export type DeliveryPromise = {
  mode: "source_led" | "motion_led" | "graphic_led" | "avatar_led" | "localization" | "hybrid";
  qualityFloor: "draft" | "presentable" | "broadcast";
  allowedFallbacks: string[];
  renderRuntime: "native_ffmpeg" | "remotion" | "hybrid";
  budgetUsd: number;
  deadlineClass: "interactive" | "standard" | "batch";
  lockedAt?: number;
};

export type WorkflowManifestStage = {
  id: string;
  kind: "deterministic" | "creative" | "project_transaction" | "durable_job" | "qc";
  requires: string[];
  produces: string[];
  approval: "never" | "always" | "policy" | "on_failure";
};

export type WorkflowManifest = {
  name: WorkflowKind;
  version: string;
  defaultDeliveryPromise: DeliveryPromise;
  stages: WorkflowManifestStage[];
  requiredSkills?: string[];
};

export type WorkflowStage = WorkflowManifestStage & {
  runId: string;
  state: WorkflowStageState;
  attempt: number;
  startedAt?: number;
  completedAt?: number;
  error?: string;
  inputArtifactIds: string[];
  outputArtifactIds: string[];
};

export type WorkflowStageAttempt = {
  stageId: string;
  attempt: number;
  state: WorkflowStageState;
  startedAt?: number;
  completedAt?: number;
  error?: string;
  inputArtifactIds: string[];
  outputArtifactIds: string[];
};

export type WorkflowArtifact<T = unknown> = {
  id: string;
  runId: string;
  stageId: string;
  kind: string;
  version: number;
  payload: T;
  contentHash: string;
  createdAt: number;
};

export type WorkflowBranch = {
  id: string;
  runId: string;
  sourceProjectId: string;
  projectId: string;
  label: string;
  kind: string;
  createdAt: number;
  studioUrl: string;
};

export type WorkflowApproval = {
  id: string;
  runId: string;
  stageId: string;
  decision: "approve" | "reject";
  actorId: string;
  note?: string;
  briefId?: string;
  briefVersion?: number;
  createdAt: number;
};

export type WorkflowRun = {
  id: string;
  kind: WorkflowKind;
  manifestVersion: string;
  projectId: string;
  workspaceId: string;
  state: "running" | "awaiting_approval" | "failed" | "cancelled" | "completed";
  currentStageId?: string;
  deliveryPromise: DeliveryPromise;
  estimatedCostUsd: number;
  actualCostUsd: number;
  estimatedRuntimeMs: number;
  actualRuntimeMs?: number;
  traceId: string;
  input: Record<string, unknown>;
  stages: WorkflowStage[];
  artifacts: WorkflowArtifact[];
  approvals: WorkflowApproval[];
  branches: WorkflowBranch[];
  attemptHistory?: WorkflowStageAttempt[];
  skillBindings?: Array<{ id: string; version: string; effects: Array<{ id: string; version: number }> }>;
  error?: string;
  createdAt: number;
  updatedAt: number;
};

export type BrandKit = {
  workspaceId: string;
  version: number;
  name: string;
  colors: string[];
  fonts: string[];
  logoAssetIds: string[];
  captionStyle: string;
  introText?: string;
  outroText?: string;
  glossary: Record<string, string>;
  rules: string[];
  researchSignalStatus?: {
    colors: "observed" | "not_observable";
    fonts: "observed" | "not_observable";
  };
  researchSources?: Array<{
    requestedUrl: string;
    resolvedUrl: string;
    fetchedAt: string;
    contentSha256: string;
    extractorVersion: string;
    fragments: Array<{
      id: string;
      kind: "title" | "description" | "heading" | "paragraph" | "list-item" | "action";
      ordinal: number;
      text: string;
      sha256: string;
      volatile: boolean;
    }>;
    claimLedger: Array<{
      claim: string;
      status: "supported" | "unsupported" | "ambiguous";
      evidenceFragmentIds: string[];
      sourceExact: boolean;
      volatile: boolean;
    }>;
  }>;
  updatedAt: number;
};

export const summarizeBrandKit = (kit: BrandKit | undefined): string => {
  if (!kit) return "";
  const parts = [
    kit.name && kit.name !== "Default brand" ? `name=\"${kit.name}\"` : undefined,
    kit.colors.length ? `colors=${kit.colors.join(",")}` : undefined,
    kit.fonts.length ? `fonts=${kit.fonts.join(",")}` : undefined,
    kit.logoAssetIds.length ? `logo assets=${kit.logoAssetIds.join(",")}` : undefined,
    kit.captionStyle ? `captions=${kit.captionStyle}` : undefined,
  ].filter(Boolean);
  const policies = [
    ...kit.rules.map((rule) => `rule=${rule}`),
    ...Object.entries(kit.glossary).map(([term, meaning]) => `${term}=${meaning}`),
  ];
  if (parts.length === 0 && policies.length === 0) return "";
  return [
    `Brand Kit: ${parts.join(" | ")}`,
    ...policies.map((policy) => `  - ${policy}`),
  ].join("\n");
};

export type ProjectElementKind =
  | "character"
  | "product"
  | "location"
  | "style"
  | "logo"
  | "reference";

export type ProjectElement = {
  id: string;
  projectId: string;
  kind: ProjectElementKind;
  name: string;
  description?: string;
  workspaceAssetId?: string;
  projectAssetId?: string;
  referenceBlueprintId?: string;
  createdAt: number;
  updatedAt: number;
};

export type ProjectElementInput = Omit<
  ProjectElement,
  "id" | "projectId" | "createdAt" | "updatedAt"
>;

export const PROJECT_ELEMENT_KINDS: readonly ProjectElementKind[] = [
  "character",
  "product",
  "location",
  "style",
  "logo",
  "reference",
];

export const summarizeProjectElements = (
  elements: readonly ProjectElement[],
): string => {
  if (elements.length === 0) return "";
  return [
    "Project elements (reuse these consistently):",
    ...elements.map((element) => {
      const references = [
        element.workspaceAssetId
          ? `workspace asset ${element.workspaceAssetId}`
          : undefined,
        element.projectAssetId
          ? `project asset ${element.projectAssetId}`
          : undefined,
        element.referenceBlueprintId
          ? `reference blueprint ${element.referenceBlueprintId}`
          : undefined,
      ]
        .filter(Boolean)
        .join(", ");
      return `  - ${element.kind} "${element.name}"${element.description ? ` - ${element.description}` : ""}${references ? ` [${references}]` : ""}`;
    }),
  ].join("\n");
};

const sourceLed = (): DeliveryPromise => ({
  mode: "source_led",
  qualityFloor: "presentable",
  allowedFallbacks: [],
  renderRuntime: "native_ffmpeg",
  budgetUsd: 1,
  deadlineClass: "standard",
});

export const WORKFLOW_MANIFESTS: Record<WorkflowKind, WorkflowManifest> = {
  content_pipeline: {
    name: "content_pipeline", version: "1.0.0", defaultDeliveryPromise: sourceLed(), requiredSkills: ["content-pipeline"],
    stages: [
      { id: "collect", kind: "deterministic", requires: [], produces: ["sources"], approval: "on_failure" },
      { id: "prepare", kind: "creative", requires: ["sources"], produces: ["content"], approval: "on_failure" },
      { id: "generate", kind: "durable_job", requires: ["content"], produces: ["assets"], approval: "on_failure" },
      { id: "fill", kind: "project_transaction", requires: ["content", "assets"], produces: ["project"], approval: "on_failure" },
      { id: "render", kind: "durable_job", requires: ["project"], produces: ["video"], approval: "on_failure" },
      { id: "check", kind: "qc", requires: ["video"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  talking_head_enhancer: {
    name: "talking_head_enhancer",
    version: "1.1.0",
    defaultDeliveryPromise: sourceLed(),
    stages: [
      { id: "analyze", kind: "deterministic", requires: [], produces: ["analysis_bundle"], approval: "never" },
      { id: "proposal", kind: "creative", requires: ["analysis_bundle"], produces: ["proposal_packet"], approval: "always" },
      { id: "edit", kind: "project_transaction", requires: ["proposal_packet"], produces: ["change_set", "project_branch", "reframe_report"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branch"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  long_form_to_shorts: {
    name: "long_form_to_shorts",
    version: "1.3.0",
    defaultDeliveryPromise: { ...sourceLed(), deadlineClass: "batch" },
    stages: [
      { id: "analyze", kind: "deterministic", requires: [], produces: ["analysis_bundle", "clip_candidates"], approval: "never" },
      { id: "candidates", kind: "creative", requires: ["clip_candidates"], produces: ["proposal_packet"], approval: "always" },
      { id: "edit", kind: "project_transaction", requires: ["proposal_packet"], produces: ["change_set", "project_branches", "reframe_report"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branches"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  social_repurposing: {
    name: "social_repurposing",
    version: "1.0.0",
    defaultDeliveryPromise: { ...sourceLed(), deadlineClass: "batch" },
    requiredSkills: ["video-craft", "social-repurposing"],
    stages: [
      { id: "analyze", kind: "deterministic", requires: [], produces: ["analysis_bundle", "clip_candidates"], approval: "never" },
      { id: "candidates", kind: "creative", requires: ["clip_candidates"], produces: ["proposal_packet"], approval: "always" },
      { id: "edit", kind: "project_transaction", requires: ["proposal_packet"], produces: ["change_set", "project_branches", "reframe_report"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branches"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  restoration: {
    name: "restoration",
    version: "1.0.0",
    defaultDeliveryPromise: { ...sourceLed(), qualityFloor: "presentable" },
    requiredSkills: ["video-craft", "restoration"],
    stages: [
      { id: "analyze", kind: "deterministic", requires: [], produces: ["defect_inventory"], approval: "never" },
      { id: "proposal", kind: "creative", requires: ["defect_inventory"], produces: ["restoration_plan"], approval: "always" },
      { id: "restore", kind: "durable_job", requires: ["restoration_plan"], produces: ["restoration_assets"], approval: "never" },
      { id: "edit", kind: "project_transaction", requires: ["restoration_assets"], produces: ["change_set", "project_branches", "restoration_report"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branches"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  generative_vfx: {
    name: "generative_vfx",
    version: "1.0.0",
    defaultDeliveryPromise: { ...sourceLed(), mode: "hybrid", budgetUsd: 1.5, renderRuntime: "hybrid" },
    requiredSkills: ["video-craft", "generative-vfx"],
    stages: [
      { id: "analyze", kind: "deterministic", requires: [], produces: ["vfx_shot_contract"], approval: "never" },
      { id: "proposal", kind: "creative", requires: ["vfx_shot_contract"], produces: ["vfx_plan"], approval: "always" },
      { id: "generate", kind: "durable_job", requires: ["vfx_plan"], produces: ["vfx_take_manifest"], approval: "never" },
      { id: "edit", kind: "project_transaction", requires: ["vfx_take_manifest"], produces: ["change_set", "project_branch", "vfx_report"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branch"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  localization: {
    name: "localization",
    version: "1.2.0",
    defaultDeliveryPromise: { ...sourceLed(), mode: "localization" },
    stages: [
      { id: "analyze", kind: "deterministic", requires: [], produces: ["analysis_bundle"], approval: "never" },
      { id: "translate", kind: "creative", requires: ["analysis_bundle"], produces: ["localized_scripts", "translation_manifest", "timing_report"], approval: "always" },
      { id: "edit", kind: "project_transaction", requires: ["localized_scripts"], produces: ["project_branches", "dub_manifest"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branches"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  product_ad: {
    name: "product_ad",
    version: "1.21.0",
    defaultDeliveryPromise: {
      ...sourceLed(),
      mode: "graphic_led",
      budgetUsd: 1.5,
      renderRuntime: "native_ffmpeg",
    },
    stages: [
      { id: "intake", kind: "deterministic", requires: [], produces: ["creative_brief"], approval: "never" },
      { id: "storyboard", kind: "creative", requires: ["creative_brief"], produces: ["concepts", "storyboard", "animatic", "contact_sheet"], approval: "always" },
      { id: "generate", kind: "durable_job", requires: ["storyboard"], produces: ["asset_request_manifest", "take_manifest"], approval: "never" },
      { id: "edit", kind: "project_transaction", requires: ["take_manifest"], produces: ["project_branches", "change_set"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branches"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  create_from_brief: {
    name: "create_from_brief",
    version: "1.0.0",
    defaultDeliveryPromise: {
      ...sourceLed(),
      mode: "hybrid",
      budgetUsd: 1.5,
      renderRuntime: "hybrid",
    },
    stages: [
      { id: "intake", kind: "deterministic", requires: [], produces: ["creative_brief"], approval: "never" },
      { id: "storyboard", kind: "creative", requires: ["creative_brief"], produces: ["script", "shot_list", "storyboard", "animatic", "contact_sheet"], approval: "always" },
      { id: "generate", kind: "durable_job", requires: ["storyboard"], produces: ["asset_request_manifest", "take_manifest"], approval: "never" },
      { id: "edit", kind: "project_transaction", requires: ["take_manifest"], produces: ["project_branches", "change_set"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branches"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
  talking_avatar: {
    name: "talking_avatar",
    version: "1.0.0",
    defaultDeliveryPromise: {
      ...sourceLed(),
      mode: "avatar_led",
      allowedFallbacks: ["voice_synchronized_portrait"],
      budgetUsd: 2,
      renderRuntime: "hybrid",
    },
    stages: [
      { id: "intake", kind: "deterministic", requires: [], produces: ["avatar_brief", "consent_check"], approval: "never" },
      { id: "script", kind: "creative", requires: ["avatar_brief"], produces: ["avatar_script", "delivery_plan"], approval: "always" },
      { id: "generate", kind: "durable_job", requires: ["avatar_script"], produces: ["avatar_take_manifest"], approval: "never" },
      { id: "edit", kind: "project_transaction", requires: ["avatar_take_manifest"], produces: ["project_branch", "change_set"], approval: "never" },
      { id: "qc", kind: "qc", requires: ["project_branch"], produces: ["quality_report"], approval: "on_failure" },
    ],
  },
};
