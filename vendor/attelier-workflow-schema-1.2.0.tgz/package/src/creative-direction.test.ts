import assert from "node:assert/strict";
import test from "node:test";
import {
  assertCreativeDecisionDraftValid,
  assertReferenceBlueprintDraftValid,
  shouldInterruptForCreativeDecision,
  type CreativeDecisionDraft,
  type ReferenceBlueprintDraft,
} from "./creative-direction.js";

const referenceDraft = (): ReferenceBlueprintDraft => ({
  schemaVersion: "atelier.reference-blueprint.v1",
  source: {
    provider: "youtube",
    sourceUrl: "https://www.youtube.com/watch?v=example",
    embedUrl: "https://www.youtube.com/embed/example",
    title: "Reference",
    durationSeconds: 30,
    rights: {
      declaration: "public_reference_only",
      analysisAllowed: true,
      trainingAllowed: false,
      reuseAllowed: false,
      note: "Analyze structure only; do not reuse source media.",
    },
  },
  objective: "Explain a product through proof.",
  audienceTakeaway: "The product works in a real environment.",
  synopsis: "Hook, demonstration, result and call to action.",
  transcript: { origin: "automatic_captions", language: "en", text: "Example transcript" },
  chapters: [{ id: "chapter-1", title: "Hook", startSeconds: 0, endSeconds: 30, purpose: "Earn attention", evidenceIds: ["frame-1"] }],
  beats: [{ id: "beat-1", chapterId: "chapter-1", startSeconds: 0, endSeconds: 30, narrativeFunction: "Hook", picture: "Presenter and gameplay", sound: "Narration over music", editorialTechnique: "Fast proof-led cuts", evidenceIds: ["frame-1"] }],
  style: { visualGrammar: ["presenter plus proof"], pacing: "Fast", typography: "Sparse", sound: "Voice-led", color: "Source-led", transitions: "Mostly cuts" },
  transferablePatterns: ["Open with the outcome before explaining mechanics."],
  avoidCopying: ["Do not reproduce dialogue, shot order or branded frames."],
  coverage: [{ id: "coverage-1", beatId: "beat-1", purpose: "Proof", description: "Real product footage", preferredSource: "project_media", minimumDurationSeconds: 4, status: "missing", candidateAssetIds: [] }],
  evidence: [{ id: "frame-1", kind: "frame", startSeconds: 3, description: "Presenter over gameplay." }],
  analysis: { model: "fixture", analyzerVersion: "test", sampledFrameCount: 1, limitations: [] },
});

const decisionDraft = (): CreativeDecisionDraft => ({
  schemaVersion: "atelier.creative-decision.v1",
  projectId: "project-1",
  projectRevision: 2,
  kind: "script",
  question: "Which opening should lead the film?",
  context: "Both are truthful; the choice changes the emotional promise.",
  candidates: [
    { id: "world", label: "The world wakes up", description: "Wonder-led", preview: { kind: "text", text: "Your world should feel alive." } },
    { id: "alone", label: "Never play alone", description: "Problem-led", preview: { kind: "text", text: "Still building alone?" } },
  ],
  policy: { subjective: true, impact: "high", uncertainty: 0.6, reversibility: "moderate", reason: "This sets the whole film's promise.", allowAgentJudgment: true },
  resumeState: "drafting",
});

test("Reference Blueprint validates evidence-linked timing and explicit rights", () => {
  assert.doesNotThrow(() => assertReferenceBlueprintDraftValid(referenceDraft()));
  const invalid = referenceDraft();
  invalid.source.rights.analysisAllowed = false;
  assert.throws(() => assertReferenceBlueprintDraftValid(invalid), /analysisAllowed/);
});

test("Reference Blueprint rejects ungrounded timing, empty chapter evidence and implied public-reference rights", () => {
  const lateEvidence = referenceDraft();
  lateEvidence.evidence[0]!.endSeconds = 31;
  assert.throws(() => assertReferenceBlueprintDraftValid(lateEvidence), /source-relative timestamps/);

  const ungroundedChapter = referenceDraft();
  ungroundedChapter.chapters[0]!.evidenceIds = [];
  assert.throws(() => assertReferenceBlueprintDraftValid(ungroundedChapter), /traceable evidence/);

  const impliedReuse = referenceDraft();
  impliedReuse.source.rights.reuseAllowed = true;
  assert.throws(() => assertReferenceBlueprintDraftValid(impliedReuse), /never authorize/);
});

test("Creative Decision validates comparable candidates and interrupts for material taste", () => {
  const draft = decisionDraft();
  assert.doesNotThrow(() => assertCreativeDecisionDraftValid(draft));
  assert.equal(shouldInterruptForCreativeDecision(draft).interrupt, true);
});

test("low-impact objective decisions do not interrupt the creator", () => {
  const draft = decisionDraft();
  draft.policy = { ...draft.policy, subjective: false, impact: "low", uncertainty: 0.1 };
  assert.equal(shouldInterruptForCreativeDecision(draft).interrupt, false);
});
