import assert from "node:assert/strict";
import test from "node:test";
import { evaluateEasing, type Keyframe } from "./index.js";

test("retained easing ranges match the original curve and remain finite near its ends", () => {
  const curves: Record<Keyframe["easing"], (p: number) => number> = {
    linear: p => p, hold: () => 0, easeIn: p => p * p,
    easeOut: p => 1 - (1 - p) ** 2, easeInOut: p => p * p * (3 - 2 * p),
  };
  for (const easing of Object.keys(curves) as Keyframe["easing"][]) {
    for (const easingRange of [[0, 1], [0, 0.3], [0.31, 0.87], [0.76, 1]] as [number, number][]) {
      const [a, b] = easingRange;
      for (let step = 0; step <= 100; step++) {
        const p = step / 100, curve = curves[easing];
        const expected = easing === "hold" ? 0 : (curve(a + (b - a) * p) - curve(a)) / (curve(b) - curve(a));
        assert.ok(Math.abs(evaluateEasing(p, { easing, easingRange }) - expected) < 1e-12);
      }
    }
    for (const easingRange of [[0, 1e-12], [1 - 1e-12, 1]] as [number, number][]) {
      const mid = evaluateEasing(0.5, { easing, easingRange });
      assert.ok(Number.isFinite(mid) && mid >= 0 && mid <= 1);
    }
  }
  for (const easingRange of [[0, 0], [1, 0], [-0.1, 1], [0, 1.1], [0, NaN]] as [number, number][]) {
    assert.throws(() => evaluateEasing(0.5, { easing: "linear", easingRange }), /Invalid easing range/);
  }
});
