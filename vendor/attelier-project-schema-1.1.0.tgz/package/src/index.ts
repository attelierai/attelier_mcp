export const TICKS_PER_SECOND = 120_000;

export type RenderFormat = "mp4" | "webm" | "mov" | "audio" | "image_sequence";

export type MediaTime = string & { readonly __mediaTime: unique symbol };

export type FrameRate = {
  numerator: number;
  denominator: number;
};

export type TimeRange = {
  start: MediaTime;
  duration: MediaTime;
};

export const ATTELIER_STORYBOARD_SCHEMA_VERSION = "atelier.storyboard.v1" as const;

export type StoryboardShotStatus =
  | "planned"
  | "ready"
  | "in_progress"
  | "selected"
  | "blocked";

export type StoryboardShot = {
  id: string;
  order: number;
  title: string;
  purpose?: string;
  visualDescription: string;
  narration?: string;
  duration: MediaTime;
  sourceRange?: TimeRange;
  assetIds: string[];
  selectedAssetId?: string;
  timelineElementIds: string[];
  status: StoryboardShotStatus;
  notes?: string;
};

export type HeroFrameState = {
  status: "missing" | "candidate" | "selected";
  shotId?: string;
  assetId?: string;
  at?: MediaTime;
  thumbnailKey?: string;
  updatedAt: number | null;
};

export type Storyboard = {
  schemaVersion: typeof ATTELIER_STORYBOARD_SCHEMA_VERSION;
  projectId: string;
  sequenceId: string;
  version: number;
  title?: string;
  shots: StoryboardShot[];
  heroFrame: HeroFrameState;
  status: "draft" | "awaiting_approval" | "approved" | "superseded";
  updatedAt: number | null;
  updatedBy: string | null;
};

export type StoryboardPatch = Partial<
  Pick<Storyboard, "title" | "shots" | "heroFrame" | "status">
>;

const storyboardNonEmpty = (value: unknown): value is string =>
  typeof value === "string" && value.trim().length > 0;
const storyboardMediaTime = (value: unknown): value is MediaTime =>
  typeof value === "string" && /^(?:0|[1-9]\d*)$/.test(value);
const storyboardUnique = (values: string[]): boolean =>
  new Set(values).size === values.length;
const storyboardBounded = (value: unknown, maximum: number): boolean =>
  value === undefined ||
  (typeof value === "string" && value.trim().length > 0 && value.length <= maximum);
const storyboardStableId = (value: unknown): value is string =>
  storyboardNonEmpty(value) && value.length <= 200;

export const assertStoryboardValid = (storyboard: Storyboard): void => {
  if (storyboard.schemaVersion !== ATTELIER_STORYBOARD_SCHEMA_VERSION) {
    throw new Error("Unsupported Storyboard schema version.");
  }
  if (!storyboardStableId(storyboard.projectId) || !storyboardStableId(storyboard.sequenceId)) {
    throw new Error("Storyboard projectId and sequenceId are required.");
  }
  if (!Number.isSafeInteger(storyboard.version) || storyboard.version < 0) {
    throw new Error("Storyboard version must be a non-negative integer.");
  }
  if (
    !storyboardBounded(storyboard.title, 300) ||
    !["draft", "awaiting_approval", "approved", "superseded"].includes(
      storyboard.status,
    )
  ) {
    throw new Error("Storyboard title or status is invalid.");
  }
  if (
    storyboard.updatedBy !== null &&
    !storyboardStableId(storyboard.updatedBy)
  ) {
    throw new Error("Storyboard updatedBy is invalid.");
  }
  if (!Array.isArray(storyboard.shots) || storyboard.shots.length > 24) {
    throw new Error("Storyboard must contain at most 24 shots.");
  }
  const ids = storyboard.shots.map((shot) => shot.id);
  if (
    !storyboardUnique(ids) ||
    storyboard.shots.some(
      (shot, index) =>
        !storyboardStableId(shot.id) ||
        !Number.isSafeInteger(shot.order) ||
        shot.order !== index ||
        !storyboardNonEmpty(shot.title) ||
        shot.title.length > 300 ||
        !storyboardBounded(shot.purpose, 1_000) ||
        !storyboardNonEmpty(shot.visualDescription) ||
        shot.visualDescription.length > 4_000 ||
        !storyboardBounded(shot.narration, 8_000) ||
        !storyboardBounded(shot.notes, 4_000) ||
        !storyboardMediaTime(shot.duration) ||
        shot.duration === "0" ||
        !Array.isArray(shot.assetIds) ||
        shot.assetIds.length > 32 ||
        !storyboardUnique(shot.assetIds) ||
        shot.assetIds.some((id) => !storyboardStableId(id)) ||
        (shot.selectedAssetId !== undefined &&
          !shot.assetIds.includes(shot.selectedAssetId)) ||
        !Array.isArray(shot.timelineElementIds) ||
        shot.timelineElementIds.length > 32 ||
        !storyboardUnique(shot.timelineElementIds) ||
        shot.timelineElementIds.some((id) => !storyboardStableId(id)) ||
        !["planned", "ready", "in_progress", "selected", "blocked"].includes(
          shot.status,
        ) ||
        (shot.sourceRange !== undefined &&
          (!storyboardMediaTime(shot.sourceRange.start) ||
            !storyboardMediaTime(shot.sourceRange.duration) ||
            shot.sourceRange.duration === "0")),
    )
  ) {
    throw new Error(
      "Storyboard shots require ordered IDs, visual descriptions, positive durations and valid bindings.",
    );
  }
  const hero = storyboard.heroFrame;
  if (
    !hero ||
    !["missing", "candidate", "selected"].includes(hero.status) ||
    (hero.updatedAt !== null &&
      (!Number.isSafeInteger(hero.updatedAt) || hero.updatedAt < 0)) ||
    !storyboardBounded(hero.thumbnailKey, 500)
  ) {
    throw new Error("Storyboard Hero Frame state is invalid.");
  }
  if (
    hero.status === "missing" &&
    (hero.shotId || hero.assetId || hero.at || hero.thumbnailKey)
  ) {
    throw new Error("A missing Hero Frame cannot reference media.");
  }
  if (hero.status !== "missing") {
    if (!hero.shotId || !ids.includes(hero.shotId) || !hero.assetId) {
      throw new Error(
        "A Hero Frame candidate or selection requires a known shot and asset.",
      );
    }
    const shot = storyboard.shots.find(({ id }) => id === hero.shotId)!;
    if (
      !shot.assetIds.includes(hero.assetId) &&
      shot.selectedAssetId !== hero.assetId
    ) {
      throw new Error("Hero Frame asset must belong to its shot.");
    }
    if (hero.at !== undefined && !storyboardMediaTime(hero.at)) {
      throw new Error("Hero Frame time must be a non-negative media time.");
    }
  }
};

export const normalizeStoryboard = (
  value: unknown,
  projectId: string,
  sequenceId: string,
  version = 0,
): Storyboard => {
  const candidate =
    value && typeof value === "object" && !Array.isArray(value)
      ? (value as Partial<Storyboard>)
      : {};
  const shots = Array.isArray(candidate.shots) ? candidate.shots : [];
  const storyboard: Storyboard = {
    schemaVersion: ATTELIER_STORYBOARD_SCHEMA_VERSION,
    projectId,
    sequenceId,
    version,
    ...(storyboardNonEmpty(candidate.title)
      ? { title: candidate.title.trim() }
      : {}),
    shots: shots.map((shot, index) => ({
      ...(shot as StoryboardShot),
      order: index,
    })),
    heroFrame: candidate.heroFrame ?? { status: "missing", updatedAt: null },
    status: candidate.status ?? "draft",
    updatedAt: candidate.updatedAt ?? null,
    updatedBy: candidate.updatedBy ?? null,
  };
  assertStoryboardValid(storyboard);
  return storyboard;
};

export type TrackKind = "video" | "audio" | "text" | "graphic" | "caption" | "effect";
export type ElementKind = "video" | "audio" | "image" | "text" | "graphic" | "caption";

/**
 * Where an asset's bytes can be found. `remote` is always the ORIGINAL and is
 * the only location a render may read. `proxy` and `poster` are preview-only
 * derivatives produced by the API (H.264 720p, and a JPEG still): they exist so
 * a browser never has to decode a 10-bit HEVC master to draw a viewer frame.
 */
export type AssetLocation =
  | { kind: "opfs"; key: string }
  | { kind: "remote"; url: string }
  | { kind: "proxy"; url: string }
  | { kind: "poster"; url: string }
  | { kind: "memory"; objectUrl: string };

export type AssetProvenance = {
  origin: "uploaded" | "generated" | "stock" | "derived" | "recorded";
  provider: string;
  model?: string;
  modelVersion?: string;
  prompt?: string;
  negativePrompt?: string;
  seed?: number;
  settings?: Record<string, unknown>;
  referenceAssetIds?: string[];
  parentAssetIds?: string[];
  cost?: { currency: "USD"; estimated: number; actual: number };
  rights?: { license: string; sourceUrl?: string; publishable: boolean };
  policyDecisions?: string[];
  createdAt: number;
};

export type Asset = {
  id: string;
  name: string;
  mediaType: "video" | "audio" | "image" | "font" | "subtitle" | "data";
  role: "original" | "proxy" | "generated" | "derived" | "stock" | "recorded";
  contentHash?: string;
  mimeType?: string;
  byteSize?: number;
  duration?: MediaTime;
  width?: number;
  height?: number;
  frameRate?: number;
  sampleRate?: number;
  channels?: number;
  thumbnailKey?: string;
  waveformKey?: string;
  proxyKey?: string;
  storage: AssetLocation[];
  provenance?: AssetProvenance;
};

/** Canonical project property used by text/caption elements to reference the
 * exact font bytes used by both preview and render. `style.fontFamily` remains
 * a human-readable label; it is never sufficient evidence of font parity. */
export const FONT_ASSET_PROPERTY = "style.fontAssetId" as const;

const FONT_MIME_TYPES = new Set([
  "font/ttf",
  "font/otf",
  "application/x-font-ttf",
  "application/x-font-opentype",
]);

export const isSupportedProjectFont = (input: { name: string; type?: string }): boolean => {
  const mimeType = input.type?.toLowerCase().split(";", 1)[0]?.trim() ?? "";
  return FONT_MIME_TYPES.has(mimeType) || /\.(ttf|otf)$/i.test(input.name);
};

export const referencedFontAssetId = (
  properties: Readonly<Record<string, unknown>>,
): string | undefined => {
  const value = properties[FONT_ASSET_PROPERTY];
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : undefined;
};

export const fontAssetDisplayName = (asset: Pick<Asset, "name">): string =>
  asset.name.replace(/\.(ttf|otf)$/i, "").trim() || asset.name;

export type Keyframe = {
  id: string;
  at: MediaTime;
  value: unknown;
  easing: "linear" | "easeIn" | "easeOut" | "easeInOut" | "hold";
  /** Retained domain of the outgoing easing curve; omitted means [0, 1]. */
  easingRange?: [number, number];
};

/** Normalized polynomial for a retained easing domain, c1*t + c2*t² + c3*t³. */
export const easingCoefficients = (
  easing: Keyframe["easing"], range: Keyframe["easingRange"] = [0, 1],
): [number, number, number] => {
  const [a, b] = range;
  const d = b - a;
  if (!Number.isFinite(a) || !Number.isFinite(b) || a < 0 || b > 1 || a >= b) {
    throw new Error("Invalid easing range");
  }
  if (easing === "hold") return [0, 0, 0];
  if (easing === "linear") return [1, 0, 0];
  const coefficients: [number, number, number] = easing === "easeIn"
    ? [2 * a, d, 0]
    : easing === "easeOut"
      ? [2 * (1 - a), -d, 0]
      : [6 * a * (1 - a), (3 - 6 * a) * d, -2 * d * d];
  const denominator = coefficients[0] + coefficients[1] + coefficients[2];
  return coefficients.map((value) => value / denominator) as [number, number, number];
};

export const evaluateEasing = (progress: number, frame: Pick<Keyframe, "easing" | "easingRange">): number => {
  const p = Math.max(0, Math.min(1, progress));
  const [c1, c2, c3] = easingCoefficients(frame.easing, frame.easingRange);
  return p * (c1 + p * (c2 + p * c3));
};

export type AnimationChannel = {
  path: string;
  keyframes: Keyframe[];
};

export type TimelineElement = {
  id: string;
  name: string;
  kind: ElementKind;
  assetId?: string;
  timelineRange: TimeRange;
  sourceRange?: TimeRange;
  properties: Record<string, unknown>;
  keyframes: AnimationChannel[];
};

export type TransitionKind = "cross-dissolve" | "dip-to-black" | "dip-to-white";
export type TransitionEdge = "in" | "out";

export type ElementTransition = {
  kind: TransitionKind;
  durationSeconds: number;
  peerElementId?: string;
};

/**
 * Read an authored transition from the flat property map used by project
 * operations. Invalid/partial values are ignored so old projects and plugins
 * cannot destabilise preview or render.
 */
export const readElementTransition = (
  element: TimelineElement,
  edge: TransitionEdge,
): ElementTransition | undefined => {
  const kind = element.properties[`transition.${edge}.type`];
  const duration = element.properties[`transition.${edge}.durationSeconds`];
  if (
    (kind !== "cross-dissolve" && kind !== "dip-to-black" && kind !== "dip-to-white") ||
    typeof duration !== "number" ||
    !Number.isFinite(duration) ||
    duration <= 0
  ) {
    return undefined;
  }
  const peer = element.properties[
    edge === "in" ? "transition.in.fromElementId" : "transition.out.toElementId"
  ];
  return {
    kind,
    durationSeconds: Math.min(duration, ticksToSeconds(element.timelineRange.duration) / 2),
    ...(typeof peer === "string" && peer.length > 0 ? { peerElementId: peer } : {}),
  };
};

/** Numeric transition opacity used by the browser preview and test fixtures. */
export const transitionOpacityAt = (
  element: TimelineElement,
  absoluteSeconds: number,
): number => {
  const start = ticksToSeconds(element.timelineRange.start);
  const duration = ticksToSeconds(element.timelineRange.duration);
  const end = start + duration;
  const incoming = readElementTransition(element, "in");
  const outgoing = readElementTransition(element, "out");
  let opacity = 1;
  if (incoming) {
    const plateHold = Number(element.properties["transition.in.overlapSeconds"]) > 0
      ? incoming.durationSeconds / 2
      : 0;
    opacity *= Math.max(0, Math.min(1, (absoluteSeconds - start - plateHold) / (incoming.durationSeconds - plateHold)));
  }
  // A cross-dissolve keeps the outgoing layer opaque underneath the incoming
  // fade. Fading both layers would reveal black at the midpoint. Dip-to-black
  // deliberately fades both edges against the black base.
  if (outgoing?.kind === "dip-to-black" || outgoing?.kind === "dip-to-white") {
    const plateHold = Number(element.properties["transition.out.overlapSeconds"]) > 0
      ? outgoing.durationSeconds / 2
      : 0;
    opacity *= Math.max(0, Math.min(1, (end - plateHold - absoluteSeconds) / (outgoing.durationSeconds - plateHold)));
  }
  return opacity;
};

/** Full-frame plate revealed by a dip transition at one absolute time. */
export const transitionPlateColorAt = (
  element: TimelineElement,
  absoluteSeconds: number,
): "black" | "white" | undefined => {
  const start = ticksToSeconds(element.timelineRange.start);
  const end = start + ticksToSeconds(element.timelineRange.duration);
  const incoming = readElementTransition(element, "in");
  const outgoing = readElementTransition(element, "out");
  const colorFor = (kind: TransitionKind): "black" | "white" | undefined =>
    kind === "dip-to-black" ? "black" : kind === "dip-to-white" ? "white" : undefined;
  if (incoming && absoluteSeconds >= start && absoluteSeconds <= start + incoming.durationSeconds) {
    const color = colorFor(incoming.kind);
    const plateHold = Number(element.properties["transition.in.overlapSeconds"]) > 0
      ? incoming.durationSeconds / 2
      : 0;
    if (color && absoluteSeconds >= start + plateHold) return color;
  }
  const outgoingPlateHold = Number(element.properties["transition.out.overlapSeconds"]) > 0
    ? (outgoing?.durationSeconds ?? 0) / 2
    : 0;
  if (outgoing && absoluteSeconds >= end - outgoing.durationSeconds && absoluteSeconds <= end - outgoingPlateHold) {
    return colorFor(outgoing.kind);
  }
  return undefined;
};

export type Track = {
  id: string;
  name: string;
  kind: TrackKind;
  order: number;
  locked: boolean;
  muted: boolean;
  hidden: boolean;
  elements: TimelineElement[];
};

/** A sequence-local editorial marker. `at` is an absolute timeline time. */
export type TimelineMarker = {
  id: string;
  name: string;
  at: MediaTime;
  color?: string;
};

/** Short form retained for integrations that call these simply “markers”. */
export type Marker = TimelineMarker;

/**
 * Elements that must retain their editorial relationship (for example linked
 * production audio and picture). Membership is local to one sequence.
 */
export type LinkGroup = {
  id: string;
  elementIds: string[];
};

export type Sequence = {
  id: string;
  name: string;
  canvas: { width: number; height: number };
  frameRate: FrameRate;
  tracks: Track[];
  /** Omitted by v1/v2 documents and materialised as an empty array by v3. */
  markers?: TimelineMarker[];
  /** Omitted by v1/v2 documents and materialised as an empty array by v3. */
  linkGroups?: LinkGroup[];
};

export type Project = {
  schemaVersion: number;
  id: string;
  name: string;
  revision: number;
  activeSequenceId: string;
  assets: Asset[];
  sequences: Sequence[];
  appliedTransactionIds: string[];
};

export type Precondition =
  | { type: "elementExists"; elementId: string }
  | { type: "elementMissing"; elementId: string }
  | { type: "trackExists"; trackId: string }
  | { type: "assetExists"; assetId: string }
  | { type: "assetMissing"; assetId: string };

export type ProjectOperation =
  | { type: "addAsset"; asset: Asset }
  | { type: "removeAsset"; assetId: string }
  | { type: "replaceAsset"; assetId: string; asset: Asset }
  | { type: "insertElement"; trackId: string; element: TimelineElement }
  | {
      type: "insertOverwrite";
      trackId: string;
      element: TimelineElement;
      mode: "insert" | "overwrite";
      /** Required only when overwrite must split a pre-existing element. */
      generatedIdPrefix?: string;
    }
  | { type: "deleteElement"; elementId: string }
  | { type: "rippleDeleteElement"; elementId: string }
  | {
      type: "rippleDeleteRange";
      sequenceId: string;
      start: MediaTime;
      end: MediaTime;
      generatedIdPrefix: string;
    }
  | { type: "replaceElement"; elementId: string; element: TimelineElement }
  | { type: "moveElement"; elementId: string; start: MediaTime }
  | {
      type: "trimElement";
      elementId: string;
      timelineRange: TimeRange;
      sourceRange?: TimeRange;
    }
  | { type: "splitElement"; elementId: string; at: MediaTime; rightElementId: string }
  | { type: "setProperty"; elementId: string; path: string; value: unknown }
  | { type: "removeProperty"; elementId: string; path: string }
  | { type: "addKeyframe"; elementId: string; path: string; keyframe: Keyframe }
  | { type: "updateKeyframe"; elementId: string; path: string; keyframe: Keyframe }
  | { type: "removeKeyframe"; elementId: string; path: string; keyframeId: string }
  | { type: "setSequenceCanvas"; sequenceId: string; canvas: Sequence["canvas"] }
  | { type: "setSequenceFrameRate"; sequenceId: string; frameRate: FrameRate }
  | { type: "addMarker"; sequenceId: string; marker: TimelineMarker }
  | { type: "deleteMarker"; sequenceId: string; markerId: string }
  | {
      type: "replaceMarker";
      sequenceId: string;
      markerId: string;
      marker: TimelineMarker;
    }
  | { type: "replaceSequenceMarkers"; sequenceId: string; markers: TimelineMarker[] }
  | { type: "addLinkGroup"; sequenceId: string; linkGroup: LinkGroup }
  | { type: "replaceLinkGroup"; sequenceId: string; linkGroupId: string; linkGroup: LinkGroup }
  | { type: "deleteLinkGroup"; sequenceId: string; linkGroupId: string }
  | { type: "replaceLinkGroups"; sequenceId: string; linkGroups: LinkGroup[] }
  | { type: "addTrack"; sequenceId: string; track: Track }
  | { type: "removeTrack"; trackId: string }
  | { type: "replaceTrackElements"; trackId: string; elements: TimelineElement[] };

export type ProjectTransaction = {
  id: string;
  baseRevision: number;
  idempotencyKey: string;
  source: "ui" | "agent" | "workflow" | "api" | "plugin";
  authorId: string;
  goal?: string;
  preconditions: Precondition[];
  operations: ProjectOperation[];
};

export type TransactionResult = {
  project: Project;
  revision: number;
  inverseOperations: ProjectOperation[];
  affectedScopes: string[];
  alreadyApplied: boolean;
};

export const secondsToTicks = (seconds: number): MediaTime =>
  String(Math.round(seconds * TICKS_PER_SECOND)) as MediaTime;

export const ticksToSeconds = (ticks: MediaTime): number => Number(ticks) / TICKS_PER_SECOND;
