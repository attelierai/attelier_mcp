import assert from "node:assert/strict";
import test from "node:test";
import { assertStoryboardValid, normalizeStoryboard, type Storyboard } from "./index.js";

const shot = { id: "hook", order: 0, title: "Hook", visualDescription: "Product close-up", duration: "120000" as never, assetIds: ["asset-1"], timelineElementIds: ["element-1"], status: "planned" as const };
const base = (): Storyboard => ({ schemaVersion: "atelier.storyboard.v1", projectId: "p", sequenceId: "main", version: 0, shots: [shot], heroFrame: { status: "selected", shotId: "hook", assetId: "asset-1", at: "0" as never, updatedAt: 1 }, status: "draft", updatedAt: null, updatedBy: null });

test("normalizes a storyboard with stable shot order and default missing Hero Frame", () => {
  const value = normalizeStoryboard({ shots: [{ ...shot, order: 99 }] }, "p", "main");
  assert.equal(value.shots[0]?.order, 0);
  assert.deepEqual(value.heroFrame, { status: "missing", updatedAt: null });
});

test("rejects duplicate IDs, invalid durations and unbound Hero Frames", () => {
  assert.throws(() => assertStoryboardValid({ ...base(), shots: [{ ...shot, id: "x" }, { ...shot, id: "x", order: 1 }] }), /ordered IDs/);
  assert.throws(() => assertStoryboardValid({ ...base(), shots: [{ ...shot, duration: "0" as never }] }), /ordered IDs/);
  assert.throws(() => assertStoryboardValid({ ...base(), heroFrame: { status: "selected", shotId: "hook", assetId: "other", updatedAt: 1 } }), /belong to its shot/);
  assert.throws(() => assertStoryboardValid({ ...base(), status: "unknown" as never }), /title or status/);
});
