import type {
  MediaTime,
  Project,
  ProjectOperation,
  TimeRange,
} from "@attelier/project-schema";

export type TranscriptWord = {
  id: string;
  text: string;
  start: MediaTime;
  end: MediaTime;
  speakerId: string;
  confidence: number;
  isFiller: boolean;
};

export type TranscriptSegment = {
  id: string;
  text: string;
  /** Source-language line retained by localized stems so dialogue-aware
   * reviews can compare an authored brief without consulting muted media. */
  sourceText?: string;
  start: MediaTime;
  end: MediaTime;
  speakerId: string;
  wordIds: string[];
};

export type TranscriptSpeaker = {
  id: string;
  label: string;
};

export type TranscriptArtifact = {
  id: string;
  version: number;
  projectId: string;
  assetId: string;
  language: string;
  /** Whisper's own confidence in the detected language, when it was detected
   * rather than forced. A low value is a reason to distrust the words. */
  languageProbability?: number;
  /** A successful empty decode is distinct from an unavailable/failed job. */
  status?: "speech" | "uncertain" | "no_speech" | "no_audio";
  captionsReady?: boolean;
  provider: string;
  model: string;
  isMock: boolean;
  createdAt: number;
  speakers: TranscriptSpeaker[];
  words: TranscriptWord[];
  segments: TranscriptSegment[];
};

export type AudioAnalysisArtifact = {
  id: string;
  version: number;
  projectId: string;
  assetId: string;
  provider: string;
  createdAt: number;
  sampleRate: number;
  durationSeconds: number;
  integratedLufs?: number;
  truePeakDb?: number;
  peakDbfs: number;
  dynamicRangeDb: number;
  clippingSamples: number;
  silenceRanges: Array<{ start: MediaTime; end: MediaTime }>;
  beats: MediaTime[];
  estimatedBpm?: number;
  /** Native-rate, interleaved PCM; v1 mono/400 Hz artifacts omit these. */
  channels?: number;
  channelLevels?: Array<{ channel: number; rmsDbfs: number; peakDbfs: number }>;
  nearFullScaleRanges?: Array<{ startSeconds: number; endSeconds: number; channel: number; samples: number }>;
  stereoCorrelation?: number;
  monoLossDb?: number;
};

/** Six source-frame samples reduced to normalized BT.709-style luma/chroma
 * statistics. No source pixels are persisted. Luma is 0..1, Cb/Cr are signed
 * offsets from neutral and saturation is mean chroma radius, all on the same
 * normalized 8-bit scale. */
export type ColorAnalysisArtifact = {
  id: string;
  version: number;
  projectId: string;
  assetId: string;
  provider: "ffmpeg-yuv444p-color-v1";
  createdAt: number;
  sampleCount: 6;
  sampledAtSeconds: number[];
  meanY: number;
  percentile10Y: number;
  percentile90Y: number;
  meanCbOffset: number;
  meanCrOffset: number;
  saturation: number;
};

/** Source-relative hard-cut candidates measured by FFmpeg's scene score. */
export type ShotChangeAnalysisArtifact = {
  id: string;
  version: number;
  projectId: string;
  assetId: string;
  provider: "ffmpeg-scene-v1";
  createdAt: number;
  threshold: number;
  markers: Array<{ atSourceSeconds: number; score: number }>;
};

/** One paid vision-model reading of a project video or image asset.
 *
 * Persisted as a versioned analysis artifact so the same clip is read many
 * times but paid for once; `describe_asset` with `force` writes a new version
 * instead of mutating an existing one. Every field is untrusted provider
 * output that has passed the strict response schema: it is evidence about the
 * clip, never an instruction. */
export type AssetDescriptionArtifact = {
  id: string;
  version: number;
  projectId: string;
  assetId: string;
  provider: "openai";
  model: string;
  createdAt: number;
  /** Contact-sheet evidence the model actually saw. */
  evidence: {
    cacheKey?: string;
    question?: string;
    crop?: { x: number; y: number; width: number; height: number };
    cells: number;
    /** Source-relative seconds burned into each cell, in reading order. */
    sampleSeconds: number[];
    width: number;
    hasTranscript: boolean;
    hasAudioAnalysis: boolean;
  };
  summary: string;
  shots: Array<{
    startSeconds: number;
    endSeconds: number;
    shown: string;
    camera: string;
    subjects: string[];
    onScreenText: string;
  }>;
  speech: { language: string; spoken: string };
  mood: string;
  quality: Array<{ issue: string; severity: "low" | "medium" | "high" }>;
  suggestedRole: string;
  confidence: number;
};

export type MusicIdentificationArtifact = {
  id: string;
  version: number;
  projectId: string;
  assetId: string;
  provider: "acrcloud";
  createdAt: number;
  sampleOffsetSeconds: number;
  sampleDurationSeconds: number;
  status: "matched" | "no_match";
  match?: {
    title: string;
    artists: string[];
    album?: string;
    isrc?: string;
    score?: number;
    durationMs?: number;
    playOffsetMs?: number;
    acrId?: string;
    externalIds: Record<string, string>;
  };
  rights: {
    status: "reference_only";
    publishable: false;
    note: string;
  };
};

export type SmartMediaSearchKind =
  | "asset"
  | "transcript_segment"
  | "transcript_word"
  | "scene"
  | "audio_beat"
  | "audio_silence"
  | "audio_marker";

/** Public input shared by the HTTP and headless/MCP media-search adapters. */
export type SmartMediaSearchInput = {
  query: string;
  limit?: number;
};

/** Provider-independent, project-owned search result. Times stay in exact
 * project ticks until a UI explicitly converts them for display. */
export type SmartMediaSearchResult = {
  id: string;
  kind: SmartMediaSearchKind;
  assetId: string;
  assetName: string;
  start: MediaTime;
  end: MediaTime;
  text: string;
  score: number;
  details: Record<string, string | number | boolean>;
};

export type SmartMediaSearchResponse = {
  query: string;
  limit: number;
  searchedAt: number;
  results: SmartMediaSearchResult[];
  truncated: boolean;
};

export type VideoReconstructionShot = {
  id: string;
  index: number;
  /** Structural role inferred from measured pixels, not creative intent. */
  segmentKind?: "scene" | "graphic-card" | "unknown";
  label?: string;
  sourceRange: TimeRange;
  boundaryBefore: {
    kind: "source-start" | "hard-cut" | "transition";
    confidence: number;
    /** Absolute source interval occupied by a measured transition. */
    transition?: {
      /** Closest editable treatment, inferred from decoded pixels. */
      kind: "fade-to-black" | "dip-to-black" | "black-reveal";
      start: MediaTime;
      end: MediaTime;
      fadeOutDuration: MediaTime;
      blackHoldDuration: MediaTime;
      fadeInDuration: MediaTime;
      curve: "linear" | "ease-in" | "ease-out" | "smoothstep";
      confidence: number;
    };
  };
  /** Approximate entrance animation measured on an otherwise static graphic. */
  animation?: {
    kind: "graphic-reveal";
    start: MediaTime;
    end: MediaTime;
    confidence: number;
  };
};

/**
 * Evidence-backed approximation of the edit hidden inside a flattened video.
 * The source slices are measured; original layers, assets and effect parameters
 * are explicitly not claimed as recovered.
 */
export type VideoReconstructionArtifact = {
  schemaVersion: "atelier.video-reconstruction.v1";
  id: string;
  version: number;
  projectId: string;
  assetId: string;
  provider: "ffmpeg-scene-detect-local";
  model: "scene-score-v1" | "scene-boundary-v2" | "scene-structure-v3" | "scene-structure-v4";
  createdAt: number;
  source: {
    duration: MediaTime;
    width?: number;
    height?: number;
    frameRate?: number;
    hasEmbeddedAudio: boolean;
  };
  shots: VideoReconstructionShot[];
  recoverability: {
    cuts: "measured";
    sourceAudio: "embedded-source-preserved";
    textLayers: "not-recovered";
    originalAssets: "not-recovered";
    effects: "not-recovered" | "inferred";
  };
  limitations: string[];
};

export type VideoReconstructionPlan = {
  label: string;
  sequenceId: string;
  trackId: string;
  shotCount: number;
  operations: ProjectOperation[];
};

export const buildVideoReconstructionOperations = (
  project: Project,
  artifact: VideoReconstructionArtifact,
  idPrefix = `reconstruction-${artifact.id}`,
): VideoReconstructionPlan => {
  if (artifact.projectId !== project.id) {
    throw new Error("The reconstruction artifact belongs to a different project.");
  }
  const asset = project.assets.find(({ id }) => id === artifact.assetId);
  if (!asset || asset.mediaType !== "video") {
    throw new Error("The reconstruction source is not an available video asset.");
  }
  const sequence = project.sequences.find(({ id }) => id === project.activeSequenceId);
  if (!sequence) throw new Error(`Active sequence ${project.activeSequenceId} is missing.`);
  if (artifact.shots.length === 0) throw new Error("The reconstruction contains no usable shots.");

  const reconstructionProperties = (shot: VideoReconstructionShot): Record<string, unknown> => {
    const transition = shot.boundaryBefore.transition;
    return {
      "transform.fit": "contain",
      "reconstruction.schemaVersion": artifact.schemaVersion,
      "reconstruction.artifactId": artifact.id,
      "reconstruction.shotId": shot.id,
      "reconstruction.boundaryKind": shot.boundaryBefore.kind,
      "reconstruction.boundaryConfidence": shot.boundaryBefore.confidence,
      "reconstruction.segmentKind": shot.segmentKind ?? "unknown",
      ...(transition ? {
        "reconstruction.transitionBefore.type": transition.kind,
        "reconstruction.transitionBefore.sourceStart": transition.start,
        "reconstruction.transitionBefore.sourceEnd": transition.end,
        "reconstruction.transitionBefore.fadeOutDuration": transition.fadeOutDuration,
        "reconstruction.transitionBefore.blackHoldDuration": transition.blackHoldDuration,
        "reconstruction.transitionBefore.fadeInDuration": transition.fadeInDuration,
        "reconstruction.transitionBefore.curve": transition.curve,
        "reconstruction.transitionBefore.confidence": transition.confidence,
      } : {}),
      ...(shot.animation ? {
        "reconstruction.animation.type": shot.animation.kind,
        "reconstruction.animation.sourceStart": shot.animation.start,
        "reconstruction.animation.sourceEnd": shot.animation.end,
        "reconstruction.animation.confidence": shot.animation.confidence,
      } : {}),
      "reconstruction.inferred": true,
    };
  };

  let lastSourceEnd = 0;
  for (const [index, shot] of artifact.shots.entries()) {
    const start = Number(shot.sourceRange.start);
    const duration = Number(shot.sourceRange.duration);
    if (!Number.isFinite(start) || !Number.isFinite(duration) || start < 0 || duration <= 0) {
      throw new Error(`Reconstruction shot ${index + 1} has an invalid source range.`);
    }
    if (index > 0 && start !== lastSourceEnd) {
      throw new Error(`Reconstruction shot ${index + 1} is not contiguous with the previous shot.`);
    }
    lastSourceEnd = start + duration;
  }
  if (lastSourceEnd !== Number(artifact.source.duration)) {
    throw new Error("The reconstructed shots do not cover the complete source duration.");
  }

  const existingElements = sequence.tracks.flatMap((track) =>
    track.elements.map((element) => ({ track, element })));
  if (existingElements.length > 0) {
    const reconstructed = existingElements
      .filter(({ element }) => element.kind === "video" && element.assetId === asset.id && element.properties["reconstruction.inferred"] === true)
      .sort((left, right) => Number(left.element.timelineRange.start) - Number(right.element.timelineRange.start));
    const exactVisualRecovery = reconstructed.length === artifact.shots.length &&
      existingElements.filter(({ element }) => element.kind === "video" || element.kind === "image" || element.kind === "text").length === reconstructed.length &&
      reconstructed.every(({ element }, index) => {
        const shot = artifact.shots[index]!;
        return element.sourceRange?.start === shot.sourceRange.start &&
          element.sourceRange.duration === shot.sourceRange.duration;
      });
    if (!exactVisualRecovery) {
      throw new Error("Video reconstruction requires an empty timeline or an exact source-linked reconstruction; Attelier will not overwrite a later edit.");
    }
    const stalePrefixes = ["reconstruction.transitionBefore.", "reconstruction.animation."];
    const operations = reconstructed.map(({ element }, index): ProjectOperation => {
      const properties = Object.fromEntries(Object.entries(element.properties).filter(([path]) =>
        !stalePrefixes.some((prefix) => path.startsWith(prefix))));
      return {
        type: "replaceElement",
        elementId: element.id,
        element: {
          ...element,
          properties: { ...properties, ...reconstructionProperties(artifact.shots[index]!) },
        },
      };
    });
    return {
      label: `Refresh inferred reconstruction metadata for ${artifact.shots.length} source-linked segment${artifact.shots.length === 1 ? "" : "s"}`,
      sequenceId: sequence.id,
      trackId: reconstructed[0]!.track.id,
      shotCount: artifact.shots.length,
      operations,
    };
  }

  const reusableTrack = sequence.tracks.find(({ kind, locked }) => kind === "video" && !locked);
  const trackId = reusableTrack?.id ?? `${idPrefix}-track`;
  const operations: ProjectOperation[] = [];
  if (!reusableTrack) {
    operations.push({
      type: "addTrack",
      sequenceId: sequence.id,
      track: {
        id: trackId,
        name: "Reconstructed video",
        kind: "video",
        order: Math.max(-1, ...sequence.tracks.map(({ order }) => order)) + 1,
        locked: false,
        muted: false,
        hidden: false,
        elements: [],
      },
    });
  }
  if (
    asset.width && asset.height &&
    (sequence.canvas.width !== asset.width || sequence.canvas.height !== asset.height)
  ) {
    operations.push({
      type: "setSequenceCanvas",
      sequenceId: sequence.id,
      canvas: { width: asset.width, height: asset.height },
    });
  }

  let timelineStart = 0;
  for (const shot of artifact.shots) {
    operations.push({
      type: "insertElement",
      trackId,
      element: {
        id: `${idPrefix}-shot-${shot.index + 1}`,
        name: shot.label ?? `Recovered segment ${shot.index + 1}`,
        kind: "video",
        assetId: asset.id,
        timelineRange: {
          start: String(timelineStart) as MediaTime,
          duration: shot.sourceRange.duration,
        },
        sourceRange: shot.sourceRange,
        properties: reconstructionProperties(shot),
        keyframes: [],
      },
    });
    timelineStart += Number(shot.sourceRange.duration);
  }

  return {
    label: `Reconstruct ${artifact.shots.length} measured shot${artifact.shots.length === 1 ? "" : "s"} from ${asset.name}`,
    sequenceId: sequence.id,
    trackId,
    shotCount: artifact.shots.length,
    operations,
  };
};

export type AnalysisJob = {
  id: string;
  projectId: string;
  assetId: string;
  capability: "transcribe" | "analyze_audio" | "analyze_color" | "analyze_shots" | "identify_music" | "reconstruct_video";
  status: "queued" | "running" | "complete" | "failed";
  progress: number;
  artifactId?: string;
  error?: string;
  createdAt: number;
  updatedAt: number;
};

export type EvidenceStage = { state: "pending" | "running" | "complete" | "failed" | "skipped"; jobId?: string; error?: string };
export type EvidenceReference = {
  id: string; kind: "frame" | "listening" | "transcript" | "measurement" | "detector" | "context";
  artifactId: string; startSeconds: number; endSeconds: number; detail: string;
  modality?: "visual" | "audio" | "context";
};
export type EvidenceClaim = {
  text: string; kind: "observation" | "interpretation" | "recommendation" | "uncertainty";
  evidenceIds: string[];
};
export type SourceShot = {
  id: string; startSeconds: number; endSeconds: number; detectorId: string | null;
  samples: number[]; observedSamples: number[];
};
export type AudioObservation = {
  id: string; startSeconds: number; endSeconds: number;
  kind: "voice" | "music" | "ambience" | "effect" | "silence" | "uncertain";
  description: string; confidence: number; segmentIds: string[];
};
export type ListeningSegment = {
  id: string; startSeconds: number; endSeconds: number; channels: number;
  state: "pending" | "running" | "complete" | "failed"; summary?: string; error?: string;
  observations: AudioObservation[];
  quality?: AudioListeningQuality;
};
export type AudioQualityDimension = "intelligibility" | "noise" | "distortion" | "balance" | "continuity";
export type AudioListeningQuality = {
  version: "audio-listening-v1";
  checks: Array<{ dimension: AudioQualityDimension; status: "clear" | "issue" | "uncertain" | "not_applicable"; description: string; confidence: number }>;
  findings: Array<{ id: string; dimension: AudioQualityDimension; startSeconds: number; endSeconds: number; description: string; confidence: number; severity: "high" | "medium" | "low" }>;
};
export type SourceAudioQuality = {
  version: "source-audio-quality-v1" | "source-audio-quality-v2";
  status: "no_issues_detected" | "issues_detected" | "uncertain" | "silent" | "no_audio";
  summary: string;
  coverage: { measured: boolean; listenedSeconds: number; durationSeconds: number; complete: boolean };
  transcription: { provider?: string; model?: string; status: string; reliableWords: number; uncertainWords: number };
  findings: Array<{ claim: EvidenceClaim; startSeconds: number; endSeconds: number; source: "measurement" | "listening"; severity: "high" | "medium" | "low"; confidence: number }>;
  uncertainties: EvidenceClaim[];
};
export type SpeechQualityArtifact = {
  state: "complete" | "skipped" | "failed";
  reason?: string;
  model: "DNSMOS-P835";
  modelHash?: string;
  windows: Array<{ startSeconds: number; endSeconds: number; signal: number; background: number; overall: number; repeated: boolean }>;
};
/** Literal OCR hypotheses from original pixels, independent of the vision
 * model. Confidence is the OCR score, not a guarantee of correct spelling. */
export type SourceTextReading = {
  atSeconds: number; width: number; height: number;
  words: Array<{ text: string; confidence: number; x: number; y: number; width: number; height: number }>;
};
export type VideoUnderstanding = {
  version: string; evidenceKey: string; summary: EvidenceClaim[];
  scenes: Array<{ id: string; startSeconds: number; endSeconds: number; shotIds: string[]; visual: EvidenceClaim; audio: EvidenceClaim }>;
  uncertainties: EvidenceClaim[];
};
export type VideoDiagnosis = {
  id: string; evidenceKey: string; briefVersion: number; briefKey: string; model: string; createdAt: number;
  currency?: "current" | "superseded";
  contextReferences?: EvidenceReference[];
  strengths: EvidenceClaim[];
  problems: Array<{ claim: EvidenceClaim; category: "technical" | "clarity" | "continuity" | "aesthetic"; importance: "high" | "medium" | "low"; objectiveRelation: string }>;
  improvements: Array<{ claim: EvidenceClaim; reason: string; expectedResult: string; condition: string | null }>;
  uncertainties: EvidenceClaim[];
};
export type PostproductionJob = {
  id: string; projectId: string; assetId: string; status: "queued" | "running" | "complete" | "partial" | "cancelled" | "interrupted";
  progress: number; createdAt: number; updatedAt: number; maxCostUsd: number; costUsd: number;
  finishedAt?: number;
  owner: string; requestKey?: string; error?: string; evidenceId?: string; summary?: string;
};
export type PostproductionEvidence = {
  id: string; projectId: string; assetId: string; cacheKey: string; analyzer: string;
  status: "running" | "complete" | "partial"; progress: number; updatedAt: number;
  stages: Record<string, EvidenceStage>;
  audioModel?: string;
  audioQuality?: SourceAudioQuality;
  speechQuality?: SpeechQualityArtifact;
  audioListening?: { summary: string; findings: Array<{ severity: "critical" | "major" | "minor"; issue: string; fix: string; timestampSeconds?: number }> };
  samples: number[]; observedSamples: number[]; omittedSamples: number[];
  observations: AssetDescriptionArtifact[];
  limitations: string[]; costUsd: number;
  sourceHash?: string; durationSeconds?: number;
  shots?: SourceShot[]; listeningSegments?: ListeningSegment[]; audioObservations?: AudioObservation[];
  references?: EvidenceReference[]; understanding?: VideoUnderstanding; diagnosis?: VideoDiagnosis;
  sourceText?: { configuration: string; engine: string; readings: SourceTextReading[] };
  coverageGaps?: Array<{ startSeconds: number; endSeconds: number; reason: string }>;
  job?: PostproductionJob;
};
