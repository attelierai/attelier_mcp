export const ATTELIER_HUMAN_QUALITY_VERSION = "1.0.0";

export const HUMAN_QUALITY_LEVELS = ["asset", "treatment", "edit", "use-case"] as const;
export type HumanQualityLevel = typeof HUMAN_QUALITY_LEVELS[number];

export const HUMAN_QUALITY_DOMAINS = [
  "generated-video", "generated-image", "voice", "music", "sound-effect",
  "editing", "transition", "effect", "color", "reframe", "audio-mix",
  "script", "commercial-video", "talking-head", "long-to-short", "localization",
] as const;
export type HumanQualityDomain = typeof HUMAN_QUALITY_DOMAINS[number];

export const HUMAN_PUBLISHABILITY = ["ready", "minor-changes", "major-changes", "reject"] as const;
export type HumanPublishability = typeof HUMAN_PUBLISHABILITY[number];

export type HumanQualityDefect = {
  id: string;
  label: string;
  owner: "script" | "asset-selection" | "provider-model" | "editing" | "transition-effect" |
    "voice" | "music" | "audio-mix" | "graphics" | "brand" | "renderer" | "unknown";
  appliesTo: readonly HumanQualityDomain[] | "all";
};

/**
 * Stable labels shared by Toloka, Attelier review, feedback clustering and future
 * preference/reward-model datasets. Labels describe observable failures; they
 * do not ask crowd workers to guess internal implementation details.
 */
export const HUMAN_QUALITY_DEFECTS = [
  { id: "unclear-message", label: "The message or story is unclear", owner: "script", appliesTo: ["script", "editing", "commercial-video", "talking-head", "long-to-short", "localization"] },
  { id: "weak-script", label: "The script is generic, awkward or unconvincing", owner: "script", appliesTo: ["script", "commercial-video", "talking-head", "localization"] },
  { id: "irrelevant-visual", label: "A visual is irrelevant or does not support the message", owner: "asset-selection", appliesTo: ["editing", "commercial-video", "talking-head", "long-to-short"] },
  { id: "weak-shot", label: "A selected shot is weak, generic or poorly framed", owner: "asset-selection", appliesTo: ["generated-video", "generated-image", "editing", "commercial-video"] },
  { id: "generation-artifact", label: "Generated media has visible AI artifacts or instability", owner: "provider-model", appliesTo: ["generated-video", "generated-image", "commercial-video"] },
  { id: "visual-inconsistency", label: "Shots do not belong to the same visual world", owner: "editing", appliesTo: ["editing", "commercial-video", "long-to-short"] },
  { id: "bad-pacing", label: "The pacing feels slow, rushed or mechanical", owner: "editing", appliesTo: ["editing", "commercial-video", "talking-head", "long-to-short", "localization"] },
  { id: "bad-cut", label: "A cut happens at the wrong moment or breaks continuity", owner: "editing", appliesTo: ["editing", "commercial-video", "talking-head", "long-to-short"] },
  { id: "bad-transition", label: "A transition is distracting, unnecessary or poorly timed", owner: "transition-effect", appliesTo: ["transition", "editing", "commercial-video"] },
  { id: "bad-effect", label: "An effect is distracting, excessive or technically poor", owner: "transition-effect", appliesTo: ["effect", "editing", "commercial-video"] },
  { id: "voice-mismatch", label: "The voice does not fit the message, brand or audience", owner: "voice", appliesTo: ["voice", "commercial-video", "localization"] },
  { id: "voice-unnatural", label: "The voice sounds artificial, flat or badly directed", owner: "voice", appliesTo: ["voice", "commercial-video", "localization"] },
  { id: "music-mismatch", label: "The music does not fit the tone or energy", owner: "music", appliesTo: ["music", "editing", "commercial-video"] },
  { id: "bad-audio-mix", label: "Voice, music or effects compete or feel badly balanced", owner: "audio-mix", appliesTo: ["audio-mix", "editing", "commercial-video", "talking-head", "long-to-short", "localization"] },
  { id: "bad-text-graphics", label: "Titles, captions or graphics are weak or hard to read", owner: "graphics", appliesTo: ["editing", "commercial-video", "talking-head", "long-to-short", "localization"] },
  { id: "weak-brand-fit", label: "The result feels generic or inconsistent with the brand", owner: "brand", appliesTo: ["commercial-video"] },
  { id: "generic-ai-feel", label: "The result feels obviously AI-generated or template-like", owner: "provider-model", appliesTo: ["generated-video", "generated-image", "voice", "music", "editing", "commercial-video"] },
  { id: "technical-error", label: "There is a render, sync, crop, silence or playback error", owner: "renderer", appliesTo: "all" },
  { id: "none", label: "No important problem", owner: "unknown", appliesTo: "all" },
] as const satisfies readonly HumanQualityDefect[];

export type HumanQualityDefectId = typeof HUMAN_QUALITY_DEFECTS[number]["id"];

export const HUMAN_QUALITY_DIMENSIONS = [
  { id: "intent-fit", label: "Intent fit", low: "Misses the requested outcome.", high: "Precisely fulfils the requested outcome." },
  { id: "coherence", label: "Audiovisual coherence", low: "The parts conflict or feel assembled at random.", high: "Image, edit, voice, music and text form one piece." },
  { id: "intentionality", label: "Editorial intentionality", low: "Choices feel accidental or mechanical.", high: "Every choice supports a clear purpose." },
  { id: "naturalness", label: "Naturalness", low: "Distracting artificial or template-like qualities.", high: "Natural and credible for its intended context." },
  { id: "craft", label: "Craft", low: "Several distracting execution problems.", high: "Polished execution without distracting weaknesses." },
  { id: "publish-ready", label: "Publish readiness", low: "Reject or structural rework required.", high: "Publishable as delivered." },
] as const;

export const defectById = (id: string): HumanQualityDefect | undefined =>
  HUMAN_QUALITY_DEFECTS.find((defect) => defect.id === id);

export const defectsForDomain = (domain: HumanQualityDomain): readonly HumanQualityDefect[] =>
  HUMAN_QUALITY_DEFECTS.filter(({ appliesTo }) =>
    appliesTo === "all" || (appliesTo as readonly HumanQualityDomain[]).includes(domain));
