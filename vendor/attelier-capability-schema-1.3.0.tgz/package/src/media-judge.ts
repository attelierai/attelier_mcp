export const MEDIA_JUDGE_DIMENSIONS = [
  "composition",
  "captions",
  "editing",
  "voice",
  "audio-mix",
  "audiovisual-coherence",
] as const;

export type MediaJudgeDimension = typeof MEDIA_JUDGE_DIMENSIONS[number];
export type MediaJudgeModality = "frames" | "audio" | "video-with-audio";
export type PairwiseVerdict = "a-better" | "same" | "b-better" | "inconclusive";

export type MediaJudgeEvidence = {
  sampleId: string;
  /** Timestamp in seconds for frame/audio/video evidence. */
  timestampSeconds?: number;
  observation: string;
};

export type MediaJudgeFinding = {
  dimension: MediaJudgeDimension;
  verdict: PairwiseVerdict;
  confidence: number;
  evidence: MediaJudgeEvidence[];
  limitation?: string;
};

export type MediaJudgeReport = {
  schemaVersion: "media-judge-v1";
  modality: MediaJudgeModality;
  blindedSampleIds: [string, string];
  findings: MediaJudgeFinding[];
  overallVerdict: PairwiseVerdict;
  confidence: number;
  abstained: boolean;
};

const OBSERVABLE: Record<MediaJudgeModality, ReadonlySet<MediaJudgeDimension>> = {
  frames: new Set(["composition", "captions"]),
  audio: new Set(["voice", "audio-mix"]),
  "video-with-audio": new Set(MEDIA_JUDGE_DIMENSIONS),
};

export type MediaJudgeValidation =
  | { valid: true; report: MediaJudgeReport }
  | { valid: false; errors: string[] };

/**
 * Rejects confident claims that are unsupported by the judge's actual modality.
 * Low-confidence reports become explicit abstentions instead of noisy rewards.
 */
export const validateMediaJudgeReport = (report: MediaJudgeReport): MediaJudgeValidation => {
  const errors: string[] = [];
  if (report.schemaVersion !== "media-judge-v1") errors.push("Unsupported schemaVersion.");
  if (report.blindedSampleIds.length !== 2 || report.blindedSampleIds[0] === report.blindedSampleIds[1]) {
    errors.push("Exactly two distinct blinded sample IDs are required.");
  }
  if (!Number.isFinite(report.confidence) || report.confidence < 0 || report.confidence > 1) {
    errors.push("Overall confidence must be between 0 and 1.");
  }
  for (const finding of report.findings) {
    if (!OBSERVABLE[report.modality].has(finding.dimension)) {
      errors.push(`${report.modality} cannot assess ${finding.dimension}.`);
    }
    if (!Number.isFinite(finding.confidence) || finding.confidence < 0 || finding.confidence > 1) {
      errors.push(`${finding.dimension} confidence must be between 0 and 1.`);
    }
    if (finding.verdict !== "inconclusive" && finding.evidence.length === 0) {
      errors.push(`${finding.dimension} requires evidence for a directional verdict.`);
    }
  }
  if (errors.length > 0) return { valid: false, errors };
  if (report.confidence < 0.6 || report.findings.length === 0) {
    return {
      valid: true,
      report: { ...report, overallVerdict: "inconclusive", abstained: true },
    };
  }
  return { valid: true, report };
};
