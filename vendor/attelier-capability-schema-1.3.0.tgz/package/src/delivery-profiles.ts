export const ATTELIER_AUDIO_DELIVERY_PROFILE_VERSION = "1.0.0";

export type AudioDeliveryProfileId = "web" | "broadcast" | "podcast";

export type AudioDeliveryProfile = {
  id: AudioDeliveryProfileId;
  name: string;
  targetLufsI: number;
  maxTruePeakDbtp: number;
  loudnessRangeLu: number;
  bitrateKbps: number;
};

export const AUDIO_DELIVERY_PROFILES: Record<AudioDeliveryProfileId, AudioDeliveryProfile> = {
  web: { id: "web", name: "Web / social", targetLufsI: -14, maxTruePeakDbtp: -1.5, loudnessRangeLu: 11, bitrateKbps: 192 },
  broadcast: { id: "broadcast", name: "Broadcast", targetLufsI: -23, maxTruePeakDbtp: -1, loudnessRangeLu: 7, bitrateKbps: 256 },
  podcast: { id: "podcast", name: "Podcast / spoken word", targetLufsI: -16, maxTruePeakDbtp: -1, loudnessRangeLu: 11, bitrateKbps: 192 },
};
