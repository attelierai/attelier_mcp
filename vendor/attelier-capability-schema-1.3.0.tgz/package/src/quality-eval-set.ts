import type { Project, TimelineElement, Track } from "@attelier/project-schema";
import { evaluateProjectQuality, type QualityProfileId } from "./project-quality.js";

/**
 * Offline quality eval set (evaluation layer 1, deterministic and free).
 *
 * A curated bench of "gold" projects — some intentionally clean, some carrying a
 * known flaw — each with a baseline of what the deterministic grader MUST say
 * about it. Running the set yields a single Quality Index plus a regression list,
 * so we can tell whether a change to the grader (or to what the agent produces)
 * moved quality up or down between versions — WITHOUT any human votes or a paid
 * model call. This is the "measure improvement across versions" harness the eval
 * plan calls for; the VLM panel (layer 2, /api/critique) sits on top of it.
 */

type Ticks = TimelineElement["timelineRange"]["start"];
const ticks = (value: number): Ticks => String(value) as unknown as Ticks;

const track = (over: Partial<Track> & Pick<Track, "id" | "kind" | "order" | "elements">): Track => ({
  name: over.id,
  locked: false,
  muted: false,
  hidden: false,
  ...over,
});

const image = (id: string, durationTicks: number, over: Partial<TimelineElement> = {}): TimelineElement => ({
  id,
  name: id,
  kind: "image",
  timelineRange: { start: ticks(0), duration: ticks(durationTicks) },
  properties: {},
  keyframes: [],
  ...over,
});

const kenBurns = () => [{
  path: "transform.scale",
  keyframes: [
    { id: "a", at: ticks(0), value: 1, easing: "linear" as const },
    { id: "b", at: ticks(600000), value: 1.05, easing: "linear" as const },
  ],
}];

const readableText = (id: string, role: string, content: string, y = 0.5): TimelineElement => ({
  id,
  name: content,
  kind: "text",
  timelineRange: { start: ticks(0), duration: ticks(600000) },
  // Within the safe area (x∈[0.06,0.88], y∈[0.13,0.78]) and bound to the
  // readable-overlay contract so a clean ad trips no safe-area/text findings.
  properties: { "text.content": content, "text.role": role, "effect.text.id": "atelier.text.readable-overlay", "transform.position": [0.5, y] },
  keyframes: [],
});

const audio = (id: string, role: string, durationTicks: number): TimelineElement => ({
  id,
  name: id,
  kind: "audio",
  timelineRange: { start: ticks(0), duration: ticks(durationTicks) },
  sourceRange: { start: ticks(0), duration: ticks(durationTicks) },
  properties: { "audio.role": role, "audio.normalizeLufs": -14 },
  keyframes: [],
});

const project = (id: string, tracks: Track[], canvas = { width: 1080, height: 1920 }): Project => ({
  schemaVersion: 2,
  id,
  name: id,
  revision: 1,
  activeSequenceId: "main",
  assets: [],
  appliedTransactionIds: [],
  sequences: [{ id: "main", name: "Main", canvas, frameRate: { numerator: 30, denominator: 1 }, tracks }],
});

export type GoldExpectation = {
  passGates?: boolean;
  minScore?: number;
  mustFlag?: string[];
  mustNotFlag?: string[];
};

export type GoldCase = {
  id: string;
  description: string;
  profile: QualityProfileId;
  kind: "clean" | "flawed";
  project: Project;
  expect: GoldExpectation;
  humanEvidence?: {
    source: string;
    itemId: string;
    timecodes: string[];
    defect: string;
  };
};

// A fully-formed vertical product ad: moving hero, editable headline + CTA bound
// to the readable-overlay contract, no baked copy. The clean reference.
const cleanProductAd = (): Project =>
  project("clean-product-ad", [
    track({ id: "visual", kind: "video", order: 0, elements: [image("hero", 600000, { keyframes: kenBurns() })] }),
    // Headline and CTA live on separate tracks (full-duration copy on one track
    // would read as an accidental overlap) at distinct safe-area heights.
    track({ id: "headline-track", kind: "text", order: 1, elements: [readableText("headline", "headline", "New drop", 0.2)] }),
    track({ id: "cta-track", kind: "text", order: 2, elements: [readableText("cta", "cta", "Shop now", 0.72)] }),
    track({ id: "music", kind: "audio", order: 3, elements: [audio("bed", "music", 600000)] }),
  ]);

export const GOLD_PROJECTS: GoldCase[] = [
  {
    id: "clean-product-ad",
    description: "Vertical ad with motion, editable headline + CTA, no baked copy — should pass cleanly.",
    profile: "product-ad-v1",
    kind: "clean",
    project: cleanProductAd(),
    expect: { passGates: true, minScore: 90, mustNotFlag: ["motion.static.hero", "brand.no-cta", "brand.no-message", "text.no-readable-overlay.cta"] },
  },
  {
    id: "static-ad-no-copy",
    description: "A still product ad with no motion and no copy — the grader must flag all three.",
    profile: "product-ad-v1",
    kind: "flawed",
    project: project("static-ad", [
      track({ id: "visual", kind: "video", order: 0, elements: [image("still", 600000)] }),
    ]),
    expect: { mustFlag: ["motion.static.still", "brand.no-cta", "brand.no-message"] },
  },
  {
    id: "empty-project",
    description: "No tracks at all — must fail the technical gate regardless of any creative merit.",
    profile: "general-video-v1",
    kind: "flawed",
    project: project("empty", []),
    expect: { passGates: false, mustFlag: [] },
  },
  {
    id: "music-outlasts-picture",
    description: "A music bed that runs past the last visual frame — a critical export defect.",
    profile: "general-video-v1",
    kind: "flawed",
    project: project("outlasts", [
      track({ id: "visual", kind: "video", order: 0, elements: [image("shot", 600000, { keyframes: kenBurns() })] }),
      track({ id: "music", kind: "audio", order: 1, elements: [audio("bed", "music", 1200000)] }),
    ]),
    expect: { passGates: false, mustFlag: ["audio.outlasts-picture.bed"] },
  },
  {
    id: "visual-gap",
    description: "A hole in the visual timeline between two shots — nothing on screen mid-video.",
    profile: "general-video-v1",
    kind: "flawed",
    project: project("gap", [
      track({ id: "visual", kind: "video", order: 0, elements: [
        image("first", 600000, { keyframes: kenBurns() }),
        image("later", 240000, { timelineRange: { start: ticks(720000), duration: ticks(240000) }, keyframes: kenBurns() }),
      ] }),
    ]),
    expect: { passGates: false, mustFlag: ["technical.visual-gap.later"] },
  },
  {
    id: "baked-generated-copy",
    description: "Generated hero with provider-authored text baked in instead of editable copy.",
    profile: "product-ad-v1",
    kind: "flawed",
    project: (() => {
      const base = project("baked", [
        track({ id: "visual", kind: "video", order: 0, elements: [image("hero", 600000, { assetId: "gen", keyframes: kenBurns() })] }),
        track({ id: "copy", kind: "text", order: 1, elements: [readableText("cta", "cta", "Buy")] }),
      ]);
      base.assets = [{
        id: "gen", name: "Generated", mediaType: "image", role: "generated",
        contentHash: "sha256:a", mimeType: "image/png", byteSize: 1,
        storage: [{ kind: "remote", url: "/gen.png" }],
        provenance: { origin: "generated", provider: "fixture", createdAt: 1, settings: { includeText: true, styleSeed: "s", palette: ["#000"] } },
      }] as Project["assets"];
      return base;
    })(),
    expect: { mustFlag: ["brand.generated-copy-baked"] },
  },
  {
    id: "horizontal-for-social",
    description: "A landscape canvas delivered against the vertical social profile.",
    profile: "social-video-v1",
    kind: "flawed",
    project: project("horizontal", [
      track({ id: "visual", kind: "video", order: 0, elements: [image("shot", 600000, { keyframes: kenBurns() })] }),
    ], { width: 1920, height: 1080 }),
    expect: { mustFlag: ["technical.not-vertical"] },
  },
  {
    id: "n2-meditation-voice-copy-and-tail",
    description: "Toloka N2 regression: a voice asset is hard-truncated and says different copy from the linked title.",
    profile: "product-ad-v1",
    kind: "flawed",
    project: (() => {
      const current = project("n2-meditation-voice", [
        track({ id: "visual", kind: "video", order: 0, elements: [image("calm-shot", 600000, {
          properties: { "product.shotId": "hook" }, keyframes: kenBurns(),
        })] }),
        track({ id: "copy", kind: "text", order: 1, elements: [readableText("calm-copy", "headline", "Entra en tu calma", 0.2)] }),
        track({ id: "voice", kind: "audio", order: 2, elements: [audio("calm-voice", "voiceover", 240000)] }),
      ]);
      const copy = current.sequences[0]!.tracks[1]!.elements[0]!;
      copy.properties["product.shotId"] = "hook";
      copy.properties["text.voiceMatchRequired"] = true;
      const voice = current.sequences[0]!.tracks[2]!.elements[0]!;
      voice.assetId = "calm-voice-asset";
      voice.properties["voice.shotId"] = "hook";
      voice.properties["voice.transcript"] = "Encuentra tu calma";
      voice.properties["voice.copyMatchRequired"] = true;
      current.assets = [{
        id: "calm-voice-asset", name: "Calm voice", mediaType: "audio", role: "generated",
        duration: ticks(360000), storage: [{ kind: "remote", url: "/calm.wav" }],
      }];
      return current;
    })(),
    expect: { mustFlag: ["audio.voice-truncated.calm-voice", "brand.voice-copy-mismatch.calm-voice"] },
    humanEvidence: {
      source: "toloka-human-quality-v1.3",
      itemId: "n2-meditation-app-v1",
      timecodes: ["00:02", "00:09", "00:10"],
      defect: "voice truncation and narration/on-screen copy mismatch",
    },
  },
  {
    id: "n2-cafe-unsupported-pastry-claim",
    description: "Toloka N2 regression: narration/copy claims pastry but no linked visual beat supplies that evidence.",
    profile: "product-ad-v1",
    kind: "flawed",
    project: (() => {
      const current = project("n2-cafe-coverage", [
        track({ id: "visual", kind: "video", order: 0, elements: [image("coffee-shot", 600000, {
          properties: { "product.shotId": "coffee" }, keyframes: kenBurns(),
        })] }),
        track({ id: "copy", kind: "text", order: 1, elements: [readableText("pastry-proof", "proof", "Repostería del día", 0.64)] }),
        track({ id: "cta", kind: "text", order: 2, elements: [readableText("cafe-cta", "cta", "Visítanos", 0.72)] }),
      ]);
      current.sequences[0]!.tracks[1]!.elements[0]!.properties["product.shotId"] = "pastry";
      current.sequences[0]!.tracks[2]!.elements[0]!.properties["product.shotId"] = "coffee";
      return current;
    })(),
    expect: { mustFlag: ["brand.claim-without-shot.pastry-proof"] },
    humanEvidence: {
      source: "toloka-human-quality-v1.3",
      itemId: "n2-local-cafe-v1",
      timecodes: ["00:08"],
      defect: "unsupported pastry narration and obscured subject",
    },
  },
  {
    id: "n2-running-subject-and-type-safe-area",
    description: "Toloka N2 regression: the product is too small/cropped and oversized CTA bounds leave the vertical safe area.",
    profile: "product-ad-v1",
    kind: "flawed",
    project: (() => {
      const current = project("n2-running-composition", [
        track({ id: "visual", kind: "video", order: 0, elements: [image("shoe-shot", 600000, {
          properties: {
            "product.shotId": "cta",
            "composition.subjectKind": "product",
            "composition.subjectBounds": [0.92, 0.72, 1.08, 0.9],
          },
          keyframes: kenBurns(),
        })] }),
        track({ id: "cta", kind: "text", order: 1, elements: [readableText("shoe-cta", "cta", "SUPERA TODOS TUS LÍMITES AHORA", 0.76)] }),
      ]);
      const cta = current.sequences[0]!.tracks[1]!.elements[0]!;
      cta.properties["product.shotId"] = "cta";
      cta.properties["style.fontSize"] = 160;
      return current;
    })(),
    expect: { mustFlag: ["composition.subject-unsafe.shoe-shot", "text.bounds-outside-safe-area.shoe-cta"] },
    humanEvidence: {
      source: "toloka-human-quality-v1.3",
      itemId: "n2-running-shoes-v1",
      timecodes: ["general"],
      defect: "weak product emphasis and oversized inconsistent typography",
    },
  },
];

export type GoldCaseResult = {
  id: string;
  kind: GoldCase["kind"];
  score: number;
  passedGates: boolean;
  flagged: string[];
  failures: string[];
  signal: number; // 0..1 contribution to the Quality Index
};

export type QualityEvalReport = {
  cases: GoldCaseResult[];
  index: number; // 0..100 — the single number to track across versions
  regressions: string[]; // case ids that missed their baseline
};

const evaluateCase = (goldCase: GoldCase): GoldCaseResult => {
  const report = evaluateProjectQuality(goldCase.project, goldCase.profile);
  const flagged = report.issues.map((issue) => issue.id);
  const flaggedSet = new Set(flagged);
  const failures: string[] = [];

  const { passGates, minScore, mustFlag = [], mustNotFlag = [] } = goldCase.expect;
  if (passGates !== undefined && report.passedGates !== passGates) {
    failures.push(`passedGates=${report.passedGates}, expected ${passGates}`);
  }
  if (minScore !== undefined && report.score < minScore) {
    failures.push(`score ${report.score} < min ${minScore}`);
  }
  const missing = mustFlag.filter((id) => !flaggedSet.has(id));
  if (missing.length > 0) failures.push(`missing flags: ${missing.join(", ")}`);
  const unexpected = mustNotFlag.filter((id) => flaggedSet.has(id));
  if (unexpected.length > 0) failures.push(`unexpected flags: ${unexpected.join(", ")}`);

  // Clean cases contribute their normalized score; flawed cases contribute
  // detection recall over the flaws they were built to expose (an empty mustFlag
  // scores on gate correctness). This keeps the index sensitive to both "did we
  // keep good work high" and "did we still catch the known problems".
  let signal: number;
  if (goldCase.kind === "clean") {
    signal = report.score / 100;
  } else if (mustFlag.length > 0) {
    signal = (mustFlag.length - missing.length) / mustFlag.length;
  } else {
    signal = report.passedGates === passGates ? 1 : 0;
  }

  return { id: goldCase.id, kind: goldCase.kind, score: report.score, passedGates: report.passedGates, flagged, failures, signal };
};

export const runQualityEvalSet = (cases: GoldCase[] = GOLD_PROJECTS): QualityEvalReport => {
  const results = cases.map(evaluateCase);
  const index = results.length === 0 ? 0 : Math.round((results.reduce((sum, result) => sum + result.signal, 0) / results.length) * 100);
  const regressions = results.filter((result) => result.failures.length > 0).map((result) => result.id);
  return { cases: results, index, regressions };
};

// Human-readable one-liner per case + the headline index, for the CLI/report.
export const formatQualityEvalReport = (report: QualityEvalReport): string => {
  const lines = report.cases.map((result) => {
    const status = result.failures.length === 0 ? "PASS" : "FAIL";
    const detail = result.failures.length === 0
      ? `score ${result.score}${result.passedGates ? "" : " (gate blocked)"}`
      : result.failures.join("; ");
    return `  [${status}] ${result.id} — ${detail}`;
  });
  return [
    `Attelier Quality Index: ${report.index}/100  (${report.cases.length - report.regressions.length}/${report.cases.length} cases at baseline)`,
    ...lines,
    report.regressions.length > 0 ? `Regressions: ${report.regressions.join(", ")}` : "No regressions.",
  ].join("\n");
};
