import type { AnimationChannel, Project, ProjectOperation, TimelineElement } from "@attelier/project-schema";
import { secondsToTicks } from "@attelier/project-schema";
import type { QualityIssue } from "./project-quality.js";

const activeSequence = (project: Project) =>
  project.sequences.find(({ id }) => id === project.activeSequenceId);

const locateElement = (project: Project, elementId: string): TimelineElement | undefined => {
  for (const sequence of project.sequences) {
    for (const track of sequence.tracks) {
      const element = track.elements.find(({ id }) => id === elementId);
      if (element) return element;
    }
  }
  return undefined;
};

const kenBurnsChannels = (element: TimelineElement): AnimationChannel[] => [
  ...element.keyframes.filter(({ path }) => path !== "transform.scale"),
  {
    path: "transform.scale",
    keyframes: [
      { id: `kf-${element.id}-ken-burns-start`, at: secondsToTicks(0), value: 1, easing: "easeInOut" },
      { id: `kf-${element.id}-ken-burns-end`, at: element.timelineRange.duration, value: 1.08, easing: "easeInOut" },
    ],
  },
];

/** Compile an evaluator suggestion into canonical operations; never mutates the project. */
export const buildQualityFixOperations = (
  project: Project,
  issue: QualityIssue,
): ProjectOperation[] => {
  const sequence = activeSequence(project);
  if (!sequence || !issue.autoFix) return [];
  if (issue.autoFix === "set-canvas-9:16") {
    return [{ type: "setSequenceCanvas", sequenceId: sequence.id, canvas: { width: 1080, height: 1920 } }];
  }
  if (issue.autoFix === "move-to-safe-area" && issue.elementId) {
    const element = locateElement(project, issue.elementId);
    return element ? [{
      type: "setProperty",
      elementId: issue.elementId,
      path: "transform.position",
      value: [0.5, element.kind === "caption" ? 0.72 : 0.62],
    }] : [];
  }
  if (issue.autoFix === "ken-burns" && issue.elementId) {
    const current = locateElement(project, issue.elementId);
    if (!current) return [];
    const replacement = structuredClone(current);
    replacement.keyframes = kenBurnsChannels(replacement);
    return [{ type: "replaceElement", elementId: issue.elementId, element: replacement }];
  }
  if (issue.autoFix === "enable-ducking") {
    return sequence.tracks.flatMap((track) => track.elements
      .filter((element) => element.properties["audio.role"] === "music")
      .map((element) => ({ type: "setProperty", elementId: element.id, path: "audio.ducking", value: true }) satisfies ProjectOperation));
  }
  if (issue.autoFix === "set-social-loudness") {
    const target = sequence.tracks.flatMap((track) => track.elements)
      .find((element) => element.kind === "audio" || element.kind === "video");
    return target ? [{ type: "setProperty", elementId: target.id, path: "audio.normalizeLufs", value: -14 }] : [];
  }
  if (issue.autoFix === "trim-support-to-visual-end" && issue.elementId) {
    const element = locateElement(project, issue.elementId);
    if (!element) return [];
    const visualEnd = Math.max(0, ...sequence.tracks
      .filter((track) => track.kind === "video" && !track.hidden && !track.muted)
      .flatMap((track) => track.elements)
      .filter((candidate) => candidate.kind === "video" || candidate.kind === "image")
      .map((candidate) => Number(candidate.timelineRange.start) + Number(candidate.timelineRange.duration)));
    const start = Number(element.timelineRange.start);
    if (visualEnd <= start || visualEnd >= start + Number(element.timelineRange.duration)) return [];
    const duration = String(visualEnd - start) as TimelineElement["timelineRange"]["duration"];
    return [{
      type: "trimElement",
      elementId: element.id,
      timelineRange: { ...element.timelineRange, duration },
      ...(element.sourceRange ? { sourceRange: { ...element.sourceRange, duration } } : {}),
    }];
  }
  if (issue.autoFix === "apply-look") {
    return sequence.tracks.flatMap((track) => track.elements
      .filter((element) => element.kind === "video" || element.kind === "image")
      .map((element) => ({ type: "setProperty", elementId: element.id, path: "color.look", value: "cinematic" }) satisfies ProjectOperation));
  }
  if (issue.autoFix === "match-color-to-first") {
    const visuals = sequence.tracks.flatMap((track) => track.elements)
      .filter((element) => element.kind === "video" || element.kind === "image")
      .sort((left, right) => Number(left.timelineRange.start) - Number(right.timelineRange.start));
    const reference = visuals[0];
    if (!reference) return [];
    return visuals.slice(1).flatMap((element): ProjectOperation[] => [
      { type: "setProperty", elementId: element.id, path: "color.match.mode", value: "reference-frame" },
      { type: "setProperty", elementId: element.id, path: "color.match.referenceElementId", value: reference.id },
    ]);
  }
  return [];
};
