import assert from "node:assert/strict";
import test from "node:test";
import { triageAutomaticQuality } from "./quality-triage.js";

test("objective failure blocks a render", () => {
  const result = triageAutomaticQuality({ technicalPassed: false, deterministicPassed: true, deterministicScore: 98, criticalIssues: 1, majorIssues: 0 });
  assert.equal(result.status, "blocked");
  assert.equal(result.canClaimPublishable, false);
});

test("perfect deterministic score remains only proxy-clear without perceptual evidence", () => {
  const result = triageAutomaticQuality({ technicalPassed: true, deterministicPassed: true, deterministicScore: 100, criticalIssues: 0, majorIssues: 0 });
  assert.equal(result.status, "proxy-clear");
  assert.match(result.claimCeiling, /subjective quality remains unknown/i);
});

test("an agreeing automated panel only makes a render audit-worthy", () => {
  const result = triageAutomaticQuality({ technicalPassed: true, deterministicPassed: true, deterministicScore: 98, criticalIssues: 0, majorIssues: 0, perceptualJudgeCount: 2, perceptualInvalidators: 0, perceptualPublishReadyVotes: 2 });
  assert.equal(result.status, "audit-worthy");
  assert.equal(result.requiresHumanPromotionEvidence, true);
  assert.equal(result.canClaimPublishable, false);
});
