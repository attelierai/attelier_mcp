import assert from "node:assert/strict";
import test from "node:test";
import { assessMotionTreatment } from "./motion-treatment.js";

test("motion treatment preflight allows unknown footage only with explicit proof limitations", () => {
  const result = assessMotionTreatment({ kind: "both" });
  assert.equal(result.status, "allowed");
  assert.equal(result.requiresEncodedProof, true);
  assert.equal(result.limitations.length, 2);
  assert.deepEqual(result.reasonCodes, []);
});

test("motion treatment preflight protects intentional camera motion", () => {
  const result = assessMotionTreatment({
    kind: "stabilization",
    properties: { "motion.intent": "intentional" },
  });
  assert.equal(result.status, "needs-action");
  assert.deepEqual(result.reasonCodes, ["intentional-motion-protected"]);
});

test("motion treatment preflight rejects blur for insufficient motion or essential detail", () => {
  const result = assessMotionTreatment({
    kind: "motion-blur",
    properties: { "motion.level": "low", "content.essentialDetail": true },
  });
  assert.equal(result.status, "needs-action");
  assert.deepEqual(result.reasonCodes, ["insufficient-motion", "essential-detail-protected"]);
});

test("static or low motion blocks either temporal treatment", () => {
  assert.equal(assessMotionTreatment({
    kind: "stabilization",
    properties: { "motion.level": "static", "content.essentialDetail": true },
  }).status, "needs-action");
  assert.equal(assessMotionTreatment({
    kind: "motion-blur",
    properties: { "motion.intent": "intentional", "motion.level": "high" },
  }).status, "allowed");
});

test("measured insufficient motion evidence fails closed and annotations cannot be overridden", () => {
  const insufficient = assessMotionTreatment({ kind: "both", analysisStatus: "insufficient", motionLevel: "high" });
  assert.equal(insufficient.status, "needs-action");
  assert.deepEqual(insufficient.reasonCodes, ["motion-analysis-insufficient"]);
  const protectedIntent = assessMotionTreatment({
    kind: "stabilization",
    properties: { "motion.intent": "intentional" },
    motionIntent: "unintentional",
  });
  assert.deepEqual(protectedIntent.reasonCodes, ["intentional-motion-protected"]);
});
