import { CRAFT_RULE_IDS } from "@attelier/capability-schema/craft-guide";

export const ATTELIER_EFFECT_CATALOG_VERSION = "1.4.0";

export type EffectKind = "deterministic" | "ai-transformation" | "ai-generation";
export type EffectParameter = {
  id: string;
  type: "number" | "boolean" | "enum" | "string";
  unit?: string;
  required: boolean;
  default?: number | boolean | string;
  safeRange?: { min: number; max: number };
  values?: string[];
};

export type EffectContract = {
  effectId: string;
  version: 1;
  name: string;
  kind: EffectKind;
  intent: string;
  preconditions: string[];
  parameters: EffectParameter[];
  invariants: string[];
  previewRenderParity: { required: boolean; tolerance: string };
  cost: "local" | "provider-quoted";
  reversible: boolean;
  provenance: "project-revision" | "provider-lineage-and-project-revision";
  useWhen: string[];
  avoidWhen: string[];
  incompatibleWith: string[];
  degradation: string;
  craftRuleIds: string[];
  fixtures: { positive: string[]; negative: string[]; edge: string[] };
  metrics: string[];
  criticalFailures: string[];
};

export const EFFECT_CATALOG: readonly EffectContract[] = [
  {
    effectId: "atelier.transition.cross-dissolve", version: 1, name: "Cross dissolve", kind: "deterministic",
    intent: "Blend adjacent shots across a real overlap to soften a motivated visual change.",
    preconditions: ["Two adjacent visual clips", "Both clips have sufficient source handles", "A positive overlap can be authored"],
    parameters: [{ id: "duration", type: "number", unit: "seconds", required: true, default: 0.25, safeRange: { min: 0.13, max: 0.4 } }, { id: "curve", type: "enum", required: true, default: "equal-power", values: ["linear", "equal-power", "ease-in-out"] }, { id: "audioTreatment", type: "enum", required: true, default: "crossfade", values: ["crossfade", "preserve", "mute"] }],
    invariants: ["Effective overlap equals duration within one frame", "No accidental black frame", "Timeline duration reflects overlap", "Audio treatment is explicit"],
    previewRenderParity: { required: true, tolerance: "mix opacity ±0.03 at 25%, 50% and 75%; timing ±1 frame" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["A motivated change of time, mood or compatible imagery benefits from softness"], avoidWhen: ["A clean cut communicates better", "Source handles are missing"], incompatibleWith: ["atelier.transition.dip-to-black on the same boundary", "atelier.transition.dip-to-white on the same boundary"],
    degradation: "Reject the effect and preserve a clean cut when handles cannot satisfy the requested duration.", craftRuleIds: ["craft.transitions.sparse", "craft.editing.cuts"],
    fixtures: { positive: ["effect.cross-dissolve.adjacent.v1"], negative: ["effect.cross-dissolve.no-handles.v1"], edge: ["effect.cross-dissolve.minimum-duration.v1"] }, metrics: ["effective_overlap", "mix_curve_error", "black_frame_count", "audio_continuity"], criticalFailures: ["black_frame", "invalid_handle", "preview_render_timing_mismatch"],
  },
  {
    effectId: "atelier.transition.dip-to-black", version: 1, name: "Dip to black", kind: "deterministic",
    intent: "Mark a deliberate structural or temporal break through a controlled dip.", preconditions: ["A visual boundary or clip edge", "Positive duration"],
    parameters: [{ id: "duration", type: "number", unit: "seconds", required: true, default: 0.3, safeRange: { min: 0.13, max: 0.8 } }, { id: "hold", type: "number", unit: "seconds", required: true, default: 0, safeRange: { min: 0, max: 0.2 } }, { id: "audioTreatment", type: "enum", required: true, default: "fade", values: ["fade", "preserve", "mute"] }],
    invariants: ["Black appears only inside the authored interval", "Both fade halves are monotonic", "Audio treatment is explicit"], previewRenderParity: { required: true, tolerance: "luma curve ±0.03; timing ±1 frame" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["A chapter, time or emotional break needs punctuation"], avoidWhen: ["Used as a default at every cut"], incompatibleWith: ["atelier.transition.cross-dissolve on the same boundary", "atelier.transition.dip-to-white on the same boundary"], degradation: "Use a clean cut if the requested duration cannot fit.", craftRuleIds: ["craft.transitions.sparse"],
    fixtures: { positive: ["effect.dip-to-black.chapter.v1"], negative: ["effect.dip-to-black.accidental-black.v1"], edge: ["effect.dip-to-black.short-clip.v1"] }, metrics: ["luma_curve_error", "black_interval_error", "audio_continuity"], criticalFailures: ["black_outside_interval", "render_duration_drift"],
  },
  {
    effectId: "atelier.transition.dip-to-white", version: 1, name: "Dip to white", kind: "deterministic",
    intent: "Punctuate a bright reveal, flash, memory or high-key chapter change through a controlled white plate.", preconditions: ["A visual boundary or clip edge", "Positive duration", "A bright transition is motivated by the edit"],
    parameters: [{ id: "duration", type: "number", unit: "seconds", required: true, default: 0.25, safeRange: { min: 0.13, max: 0.6 } }, { id: "hold", type: "number", unit: "seconds", required: true, default: 0, safeRange: { min: 0, max: 0.1 } }, { id: "audioTreatment", type: "enum", required: true, default: "fade", values: ["fade", "preserve", "mute"] }],
    invariants: ["White appears only inside the authored interval", "Both fade halves are monotonic", "The plate is neutral white", "Audio treatment is explicit"], previewRenderParity: { required: true, tolerance: "luma curve ±0.03; timing ±1 frame; plate RGB ±3/255" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["A bright reveal, flash, memory or high-key scene change benefits from punctuation"], avoidWhen: ["The footage contains sensitive highlight detail", "Used as a generic replacement for clean cuts"], incompatibleWith: ["atelier.transition.cross-dissolve on the same boundary", "atelier.transition.dip-to-black on the same boundary"], degradation: "Use a clean cut if the requested duration cannot fit or white would be visually unsafe.", craftRuleIds: ["craft.transitions.sparse"],
    fixtures: { positive: ["effect.dip-to-white.reveal.v1"], negative: ["effect.dip-to-white.accidental-flash.v1"], edge: ["effect.dip-to-white.short-clip.v1"] }, metrics: ["luma_curve_error", "white_interval_error", "plate_rgb_error", "audio_continuity"], criticalFailures: ["white_outside_interval", "non_neutral_plate", "render_duration_drift"],
  },
  {
    effectId: "atelier.text.readable-overlay", version: 1, name: "Readable title or caption", kind: "deterministic",
    intent: "Present essential copy with sufficient hierarchy, contrast, timing and platform safety.", preconditions: ["Non-empty text", "Known canvas and delivery profile", "Positive screen duration"],
    parameters: [{ id: "role", type: "enum", required: true, values: ["headline", "caption", "cta", "label"] }, { id: "fontSize", type: "number", unit: "px@1080-short-edge", required: true, default: 72, safeRange: { min: 48, max: 160 } }, { id: "fadeSeconds", type: "number", unit: "seconds", required: true, default: 0.25, safeRange: { min: 0, max: 0.4 } }, { id: "outline", type: "boolean", required: true, default: true }],
    invariants: ["Essential text stays inside the selected safe area", "Reading speed and contrast are measurable", "Fade cannot exceed half the element duration"], previewRenderParity: { required: true, tolerance: "layout ±2 px at delivery resolution; opacity ±0.03" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["Authored copy, captions, CTA or labels are required"], avoidWhen: ["Copy is not approved", "The same information is already clear and additional text harms composition"], incompatibleWith: [], degradation: "Reduce copy or choose a simpler layout; never silently shrink essential text below the profile floor.", craftRuleIds: ["craft.composition.safe-area", "craft.typography.readable", "craft.captions.accessible", "craft.brand.truthful"],
    fixtures: { positive: ["effect.text.cta-safe.v1"], negative: ["effect.text.low-contrast.v1", "effect.text.outside-safe-area.v1"], edge: ["effect.text.long-approved-claim.v1"] }, metrics: ["words_per_second", "contrast_ratio", "safe_area_intersection", "line_count", "layout_delta"], criticalFailures: ["essential_text_unreadable", "wrong_claim"],
  },
  {
    effectId: "atelier.motion.ken-burns", version: 1, name: "Ken Burns / slow zoom", kind: "deterministic",
    intent: "Add subtle, motivated movement to a still while preserving subject framing.", preconditions: ["Visual still with known dimensions", "Positive duration", "A valid crop across the full path"],
    parameters: [{ id: "startScale", type: "number", required: true, default: 1, safeRange: { min: 1, max: 1.15 } }, { id: "endScale", type: "number", required: true, default: 1.08, safeRange: { min: 1, max: 1.2 } }, { id: "easing", type: "enum", required: true, default: "ease-in-out", values: ["linear", "ease-in-out"] }, { id: "focusX", type: "number", required: true, default: 0.5, safeRange: { min: 0, max: 1 } }, { id: "focusY", type: "number", required: true, default: 0.5, safeRange: { min: 0, max: 1 } }],
    invariants: ["No empty canvas is revealed", "Scale and position remain continuous", "Protected subject remains in frame"], previewRenderParity: { required: true, tolerance: "transform ±2 px and scale ±0.005 at sampled frames" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["A still needs subtle energy or attention guidance"], avoidWhen: ["Every shot already moves", "No reliable subject crop is available"], incompatibleWith: ["atelier.motion.punch-zoom over the full same interval"], degradation: "Use a static still when the full path cannot preserve composition.", craftRuleIds: ["craft.motion.subtle"],
    fixtures: { positive: ["effect.ken-burns.center-subject.v1"], negative: ["effect.ken-burns.crop-subject.v1"], edge: ["effect.ken-burns.short-still.v1"] }, metrics: ["velocity_discontinuity", "subject_coverage", "empty_canvas_pixels", "preview_render_transform_delta"], criticalFailures: ["empty_canvas", "subject_lost"],
  },
  {
    effectId: "atelier.motion.stabilization", version: 1, name: "Camera stabilization", kind: "deterministic",
    intent: "Reduce unintended camera shake while preserving deliberate movement and avoiding unstable borders.", preconditions: ["Video source with measurable inter-frame motion", "Positive duration", "Explicit strength"],
    parameters: [{ id: "strength", type: "number", required: true, default: 0.5, safeRange: { min: 0, max: 1 } }, { id: "edgeMode", type: "enum", required: true, default: "mirror", values: ["mirror"] }],
    invariants: ["Output duration and cadence remain unchanged", "Search radius stays bounded", "Borders contain no black reveal", "Intentional motion is not silently removed"], previewRenderParity: { required: false, tolerance: "Browser preview reports render-only treatment; encoded QC must verify cadence, borders and residual shake" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["Handheld jitter distracts from the subject or message"], avoidWhen: ["Camera shake is intentional", "The clip is static or already stabilized"], incompatibleWith: ["A deliberately authored camera-shake treatment on the same clip"], degradation: "Keep the source motion and return needs-action when stabilization confidence or border safety cannot be verified.", craftRuleIds: ["craft.motion.subtle", "craft.continuity.visual"],
    fixtures: { positive: ["effect.stabilization.handheld.v1"], negative: ["effect.stabilization.intentional-pan.v1"], edge: ["effect.stabilization.low-texture.v1"] }, metrics: ["residual_global_motion", "border_failure_frames", "cadence_error", "duration_error_ticks"], criticalFailures: ["black_border_reveal", "duration_drift", "severe_motion_warp"],
  },
  {
    effectId: "atelier.motion.motion-blur", version: 1, name: "Motion blur", kind: "deterministic",
    intent: "Blend a bounded temporal window to soften staccato movement or an authored retime without obscuring essential detail.", preconditions: ["Video source", "Visible motion", "A bounded two-to-five-frame mix"],
    parameters: [{ id: "frames", type: "number", unit: "frames", required: true, default: 2, safeRange: { min: 2, max: 5 } }],
    invariants: ["Output duration and frame rate remain unchanged", "Temporal window never exceeds five frames", "Text, faces and product detail remain readable"], previewRenderParity: { required: false, tolerance: "Browser preview reports render-only treatment; decoded output must retain duration/cadence and show the authored temporal mix" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["A fast move or retime looks visibly staccato"], avoidWhen: ["The shot contains essential small text or already has natural motion blur", "Blur is being used to hide a bad generation"], incompatibleWith: [], degradation: "Use the unblurred clip when motion is insufficient or essential detail would fall below its quality threshold.", craftRuleIds: ["craft.motion.subtle", "craft.brand.truthful"],
    fixtures: { positive: ["effect.motion-blur.fast-pan.v1"], negative: ["effect.motion-blur.product-text.v1"], edge: ["effect.motion-blur.low-motion.v1"] }, metrics: ["temporal_mix_delta", "detail_retention", "cadence_error", "duration_error_ticks"], criticalFailures: ["essential_detail_unreadable", "duration_drift", "frame_cadence_changed"],
  },
  {
    effectId: "atelier.retime.speed", version: 1, name: "Speed / retime", kind: "deterministic",
    intent: "Change pacing while preserving the intended source window and audiovisual sync.", preconditions: ["Timed source media", "Positive playback rate", "Valid source window"],
    parameters: [{ id: "rate", type: "number", required: true, default: 1, safeRange: { min: 0.25, max: 4 } }, { id: "preservePitch", type: "boolean", required: true, default: true }, { id: "frameBlend", type: "boolean", required: true, default: false }],
    invariants: ["Timeline duration equals source duration divided by rate", "Source window stays in bounds", "Audio/video remain synchronized", "Pitch policy is explicit"], previewRenderParity: { required: true, tolerance: "duration ±1 tick; sampled source time ±1 frame" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["Pacing or duration requires a motivated speed change"], avoidWhen: ["Speech becomes unnatural", "The change hides a content problem better solved by cutting"], incompatibleWith: [], degradation: "Reject rates that exceed supported interpolation or source bounds.", craftRuleIds: ["craft.pacing.intentional", "craft.editing.cuts"],
    fixtures: { positive: ["effect.retime.video-audio.v1"], negative: ["effect.retime.out-of-bounds.v1"], edge: ["effect.retime.fractional-rate.v1"] }, metrics: ["duration_error_ticks", "source_window_error", "av_sync_ms", "pitch_delta"], criticalFailures: ["source_out_of_bounds", "audio_video_desync"],
  },
  {
    effectId: "atelier.audio.professional-mix", version: 1, name: "Dialogue cleanup and mix", kind: "deterministic",
    intent: "Create an intelligible, smooth mix with role-aware cleanup, ducking, fades and delivery loudness.", preconditions: ["Audio roles are assigned", "Delivery profile is known", "At least one audible stem"],
    parameters: [{ id: "targetLufsI", type: "number", unit: "LUFS-I", required: true, default: -14, safeRange: { min: -24, max: -10 } }, { id: "maxTruePeakDbtp", type: "number", unit: "dBTP", required: true, default: -1.5, safeRange: { min: -3, max: -1 } }, { id: "duckingDb", type: "number", unit: "dB", required: true, default: 8, safeRange: { min: 4, max: 12 } }, { id: "cleanup", type: "boolean", required: true, default: true }],
    invariants: ["No clipping", "Dialogue remains intelligible", "No un-authored hard cuts", "Master target belongs to delivery profile rather than individual-stem competition"], previewRenderParity: { required: true, tolerance: "gain envelope ±1 dB; fades ±10 ms" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["Dialogue, music or SFX must coexist in a final mix"], avoidWhen: ["Role metadata is unknown and automatic treatment could damage intentional audio"], incompatibleWith: [], degradation: "Request role assignment or preserve the source mix; do not guess destructive cleanup.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"],
    fixtures: { positive: ["effect.audio.dialogue-music.v1"], negative: ["effect.audio.clipped-master.v1", "effect.audio.hard-cut.v1"], edge: ["effect.audio.intentional-silence.v1"] }, metrics: ["lufs_i", "true_peak_dbtp", "clipping_samples", "dialogue_music_ratio", "hard_audio_cuts"], criticalFailures: ["clipping", "unintelligible_dialogue"],
  },
  {
    effectId: "atelier.color.match-and-look", version: 1, name: "Color match and creative look", kind: "deterministic",
    intent: "Neutralize clip differences before applying a consistent creative finish.", preconditions: ["Visual clip has analyzable frames", "Reference frame or explicit neutral target", "Declared color space"],
    parameters: [{ id: "mode", type: "enum", required: true, default: "reference-frame", values: ["reference-frame", "scope-assistant"] }, { id: "referenceFrame", type: "string", required: false }, { id: "analysisVersion", type: "string", required: false }, { id: "matchStrength", type: "number", required: true, default: 1, safeRange: { min: 0, max: 1 } }, { id: "look", type: "enum", required: true, default: "neutral", values: ["neutral", "cinematic", "warm", "cold", "vibrant", "muted", "bw"] }],
    invariants: ["Match occurs before creative look", "Channels do not clip beyond tolerance", "Protected skin/product colors remain within tolerance"], previewRenderParity: { required: true, tolerance: "mean ΔE2000 ≤3 on reference patches" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["Multiple sources or generators need visual continuity"], avoidWhen: ["A deliberate color discontinuity is authored"], incompatibleWith: [], degradation: "Apply the look only after warning that per-clip matching is unavailable.", craftRuleIds: ["craft.color.match-before-look", "craft.continuity.visual"],
    fixtures: { positive: ["effect.color.multi-source.v1"], negative: ["effect.color.clipped-channel.v1"], edge: ["effect.color.no-neutral.v1"] }, metrics: ["reference_color_distance_delta", "channel_clipping", "protected_tone_delta", "preview_render_delta_e"], criticalFailures: ["severe_channel_clipping", "product_color_changed"],
  },
  {
    effectId: "atelier.region.blur", version: 1, name: "Editable region blur", kind: "deterministic",
    intent: "Obscure a bounded image or video region with a local reversible blur whose centre can be tracked over time.", preconditions: ["Visual clip", "Explicit normalized rectangle", "Blur strength within the supported local range"],
    parameters: [{ id: "x", type: "number", required: true, safeRange: { min: 0, max: 1 } }, { id: "y", type: "number", required: true, safeRange: { min: 0, max: 1 } }, { id: "width", type: "number", required: true, safeRange: { min: 0.02, max: 1 } }, { id: "height", type: "number", required: true, safeRange: { min: 0.02, max: 1 } }, { id: "strength", type: "number", required: true, default: 18, safeRange: { min: 1, max: 40 } }],
    invariants: ["The rectangle stays inside source bounds", "Pixels outside the mask are preserved", "Tracking changes only the mask centre", "The edit remains reversible project state"], previewRenderParity: { required: true, tolerance: "normalized mask geometry +/-0.001; timing +/-1 frame" }, cost: "local", reversible: true, provenance: "project-revision",
    useWhen: ["A face, plate, screen or sensitive detail must be obscured without replacing the source asset"], avoidWhen: ["The region cannot be located reliably", "A replacement or cleanup is actually required"], incompatibleWith: ["atelier.region.inpaint on the same source derivative"], degradation: "Keep the source unchanged and request a clearer region or tracking correction; never widen the privacy mask silently.", craftRuleIds: ["craft.safety.consent", "craft.continuity.visual"],
    fixtures: { positive: ["effect.region-blur.tracked-face.v1"], negative: ["effect.region-blur.outside-mask-change.v1"], edge: ["effect.region-blur.frame-edge.v1"] }, metrics: ["mask_position_delta", "outside_region_delta", "privacy_obscuration"], criticalFailures: ["sensitive_region_visible", "outside_region_material_change", "mask_out_of_bounds"],
  },
  {
    effectId: "atelier.composite.subject-cutout", version: 1, name: "Background removal and composition", kind: "ai-transformation",
    intent: "Isolate a subject and integrate it into a new scene without visible edge or lighting errors.", preconditions: ["Owned or licensed source asset", "Sufficient subject resolution", "Provider quote and policy pass"],
    parameters: [{ id: "edgeRefinement", type: "number", required: true, default: 0.5, safeRange: { min: 0, max: 1 } }, { id: "decontaminate", type: "boolean", required: true, default: true }, { id: "shadow", type: "boolean", required: true, default: true }],
    invariants: ["Output retains alpha", "Subject identity and geometry are preserved", "Composition records source and provider lineage"], previewRenderParity: { required: true, tolerance: "alpha edge mismatch ≤1 px at output resolution" }, cost: "provider-quoted", reversible: true, provenance: "provider-lineage-and-project-revision",
    useWhen: ["A subject must be recomposed against an approved background"], avoidWhen: ["Hair, transparency or motion exceeds the validated provider envelope"], incompatibleWith: [], degradation: "Keep the original background and report the unsupported edge case rather than returning a visibly broken matte.", craftRuleIds: ["craft.continuity.visual", "craft.color.match-before-look", "craft.brand.truthful"],
    fixtures: { positive: ["effect.cutout.product-clean.v1"], negative: ["effect.cutout.hair-halo.v1"], edge: ["effect.cutout.transparent-object.v1"] }, metrics: ["mask_iou", "edge_halo", "alpha_flicker", "identity_fidelity", "lighting_consistency"], criticalFailures: ["subject_part_removed", "identity_changed", "missing_provenance"],
  },
  {
    effectId: "atelier.region.inpaint", version: 1, name: "Region blur / inpaint", kind: "ai-transformation",
    intent: "Modify only an approved region while preserving temporal and spatial context outside it.", preconditions: ["Explicit mask", "Owned or licensed source", "Provider quote and policy pass"],
    parameters: [{ id: "mode", type: "enum", required: true, values: ["blur", "remove", "replace"] }, { id: "strength", type: "number", required: true, default: 0.75, safeRange: { min: 0.1, max: 1 } }, { id: "prompt", type: "string", required: false }],
    invariants: ["Pixels outside the protected mask remain within tolerance", "Mask lineage is retained", "Replacement does not invent prohibited claims or identity"], previewRenderParity: { required: true, tolerance: "outside-mask pixel delta ≤1%; mask boundary timing ±1 frame" }, cost: "provider-quoted", reversible: true, provenance: "provider-lineage-and-project-revision",
    useWhen: ["A bounded object, defect or sensitive region needs treatment"], avoidWhen: ["The requested change is global", "The mask is ambiguous or absent"], incompatibleWith: [], degradation: "Request a better mask or use deterministic blur; never expand the edit outside the approved region.", craftRuleIds: ["craft.brand.truthful", "craft.safety.consent"],
    fixtures: { positive: ["effect.inpaint.product-surface.v1"], negative: ["effect.inpaint.outside-mask-change.v1"], edge: ["effect.inpaint.mask-boundary.v1"] }, metrics: ["mask_compliance", "outside_region_delta", "boundary_artifact", "temporal_flicker", "context_consistency"], criticalFailures: ["outside_region_material_change", "prohibited_content", "missing_mask"],
  },
  {
    effectId: "atelier.generate.image-to-video", version: 1, name: "Image to video", kind: "ai-generation",
    intent: "Create useful motion from a reference image while preserving its subject, product and brand identity.", preconditions: ["Owned or licensed reference image", "Motion brief", "Provider quote and policy pass", "Target aspect and duration"],
    parameters: [{ id: "motionPrompt", type: "string", required: true }, { id: "duration", type: "number", unit: "seconds", required: true, default: 5, safeRange: { min: 2, max: 10 } }, { id: "guidance", type: "number", required: true, default: 0.7, safeRange: { min: 0, max: 1 } }, { id: "seed", type: "number", required: true }],
    invariants: ["Reference identity and approved product details remain stable", "Output has genuine usable motion", "Seed, provider, model and parameters are retained"], previewRenderParity: { required: true, tolerance: "Generated asset is immutable; preview and render decode the same content hash" }, cost: "provider-quoted", reversible: true, provenance: "provider-lineage-and-project-revision",
    useWhen: ["A still needs motivated motion that deterministic animation cannot provide"], avoidWhen: ["A deterministic pan/zoom satisfies the brief", "Exact identity preservation is unsupported"], incompatibleWith: [], degradation: "Use deterministic motion or return needs-action; never substitute a static output for a motion promise.", craftRuleIds: ["craft.motion.subtle", "craft.continuity.visual", "craft.brand.truthful"],
    fixtures: { positive: ["effect.i2v.product-turntable.v1"], negative: ["effect.i2v.logo-drift.v1"], edge: ["effect.i2v.low-texture.v1"] }, metrics: ["reference_fidelity", "temporal_flicker", "identity_drift", "motion_utility", "endpoint_usability"], criticalFailures: ["wrong_product", "identity_drift", "static_output", "missing_lineage"],
  },
  {
    effectId: "atelier.identity.lip-sync", version: 1, name: "Consent-gated lip sync", kind: "ai-transformation",
    intent: "Synchronize an authorized face performance to approved audio while preserving identity and facial stability.", preconditions: ["Active scoped consent", "Owned or licensed face video", "Approved audio", "Provider quote and policy pass"],
    parameters: [{ id: "syncStrength", type: "number", required: true, default: 0.75, safeRange: { min: 0.25, max: 1 } }, { id: "preserveIdentity", type: "boolean", required: true, default: true }],
    invariants: ["Consent is active for purpose and identity", "Audio duration and video output stay synchronized", "Identity and non-mouth regions remain stable", "Provenance links every derivative"], previewRenderParity: { required: true, tolerance: "Generated asset is immutable; preview and render decode the same content hash" }, cost: "provider-quoted", reversible: true, provenance: "provider-lineage-and-project-revision",
    useWhen: ["An authorized localization or performance needs mouth synchronization"], avoidWhen: ["Consent is absent, expired or ambiguous", "The purpose is deceptive impersonation"], incompatibleWith: [], degradation: "Block execution and request valid consent; never fall back to an untracked identity edit.", craftRuleIds: ["craft.safety.consent", "craft.continuity.visual"],
    fixtures: { positive: ["effect.lipsync.authorized-speaker.v1"], negative: ["effect.lipsync.no-consent.v1", "effect.lipsync.face-warp.v1"], edge: ["effect.lipsync.profile-face.v1"] }, metrics: ["av_sync_ms", "identity_fidelity", "face_region_stability", "artifact_rate", "consent_validity"], criticalFailures: ["invalid_consent", "identity_changed", "severe_face_deformation", "missing_lineage"],
  },
] as const;

export const EFFECT_IDS = EFFECT_CATALOG.map(({ effectId }) => effectId);

export type EffectId = typeof EFFECT_CATALOG[number]["effectId"];
export type EffectRef = { id: EffectId; version: 1 };

/** Resolve effect lineage from the canonical catalog instead of duplicating versions. */
export const effectRef = (id: EffectId): EffectRef => {
  const contract = EFFECT_CATALOG.find(({ effectId }) => effectId === id);
  if (!contract) throw new Error(`Unknown effect contract ${id}.`);
  return { id, version: contract.version };
};

export const validateEffectCatalog = (): string[] => {
  const issues: string[] = [];
  const effectIds = new Set<string>();
  const fixtureIds = new Set<string>();
  const craftRules = new Set(CRAFT_RULE_IDS);
  for (const effect of EFFECT_CATALOG) {
    if (effectIds.has(effect.effectId)) issues.push(`duplicate effect ${effect.effectId}`);
    effectIds.add(effect.effectId);
    if (effect.parameters.length === 0 || effect.invariants.length === 0 || effect.metrics.length === 0 || effect.criticalFailures.length === 0) issues.push(`${effect.effectId} has an incomplete contract`);
    if (!effect.degradation) issues.push(`${effect.effectId} has no honest degradation`);
    for (const ruleId of effect.craftRuleIds) if (!craftRules.has(ruleId)) issues.push(`${effect.effectId} references unknown craft rule ${ruleId}`);
    for (const fixtureId of [...effect.fixtures.positive, ...effect.fixtures.negative, ...effect.fixtures.edge]) {
      if (fixtureIds.has(fixtureId)) issues.push(`duplicate effect fixture ${fixtureId}`);
      fixtureIds.add(fixtureId);
    }
  }
  return issues;
};
