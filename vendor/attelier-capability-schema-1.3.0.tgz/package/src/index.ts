/** Legacy operational USD conversion. Retail generation prices come from the account ledger. */
export const CREDITS_PER_USD = 100;
export const usdToCredits = (usd: number): number =>
  Number.isFinite(usd) && usd > 0 ? Math.round(usd * CREDITS_PER_USD * 10) / 10 : 0;
export const creditsToUsd = (credits: number): number =>
  Number.isFinite(credits) && credits > 0 ? Math.round((credits / CREDITS_PER_USD) * 1_000_000) / 1_000_000 : 0;

/**
 * The capabilities the Models allow-list governs: everything a person can pick
 * in Create, and everything Atte may route for them. Workflow-only capabilities
 * (translation, stock acquisition, b-roll search, project localization) are not
 * a choice the modal offers, so the allow-list never speaks for them.
 */
export const POLICY_MANAGED_CAPABILITIES: readonly string[] = [
  "text_to_image", "image_to_image", "product_shot",
  "text_to_video", "image_to_video", "reference_to_video",
  "voice_generation", "music_generation", "sound_effect_generation",
  "upscale", "background_removal", "region_inpaint", "lip_sync",
];

export const isPolicyManagedCapability = (capability: string): boolean =>
  POLICY_MANAGED_CAPABILITIES.includes(capability);

export type CapabilityPricingUnit = "image" | "megapixel" | "second" | "video" | "character";

export type CapabilityRuntime = "browser" | "local_cpu" | "local_gpu" | "managed_gpu" | "api";
export type CapabilityStability = "experimental" | "beta" | "production";

export type CapabilityProviderDescriptor = {
  id: string;
  capability: string;
  provider: string;
  /** Who actually runs and bills the model behind `provider` (e.g. fal.ai or higgsfield.ai
   *  behind the Attelier API): where the cost is routed. */
  upstreamProvider?: string;
  model: string;
  modelVersion: string;
  runtime: CapabilityRuntime;
  stability: CapabilityStability;
  available: boolean;
  /** Safe, user-facing reason a configured provider cannot currently run. */
  availabilityReason?: string;
  rightsPolicy: string;
  dataPolicy: string;
  fallbackProviderIds: string[];
  /** Create-surface eligibility. Absent means eligible; `false` keeps the
   * provider callable by non-Create workflows while hiding it from Create. */
  createEligible?: boolean;
  /** Server-owned routing eligibility. Manual-only candidates cannot silently become defaults. */
  routingTiers?: Array<"draft" | "final" | "best" | "manual">;
  /** Dimensions required for a fair candidate comparison; no model is labelled universally best. */
  benchmarkDimensions?: string[];
  /** Auditable provider input contract; the server still performs the authoritative validation. */
  parameterSchema?: Record<string, {
    type: "string" | "number" | "boolean" | "string[]";
    required?: boolean;
    enum?: ReadonlyArray<string | number | boolean>;
    minimum?: number;
    maximum?: number;
    default?: string | number | boolean;
  }>;
  /** Account-owned retail tariff, independent of provider cost. Included benefits apply at quote time. */
  creditPricing?: {unit:"request"|"second"|"megapixel"|"character";credits:number;version:number};
  /** Internal operational cost hint. The exact reservation comes from quote_capability. */
  pricing?: {
    currency?: "USD";
    quoteRequired?: true;
    exampleEstimateUsd?: number;
    exactAtQuote?: true;
    unit?: CapabilityPricingUnit;
    usdPerUnit?: number;
    /** ISO date the unit rate was read from the provider's public price page. */
    verifiedAt?: string;
    source?: string;
  };
  /** Never imply capacity that the provider/account adapter cannot observe. */
  rateLimit?:
    | { status: "known"; requests?: number; windowSeconds?: number; concurrency?: number }
    | { status: "unknown"; reason: string };
};

export type CapabilityRoutingTier = "draft" | "final" | "best" | "manual";

export type CapabilityRoutingDecision = {
  policy: "balanced" | "quality" | "cost" | "manual";
  selectedId: string;
  candidateIds: string[];
  reason: string;
  registryVersion: string;
  fallback: boolean;
};

export type GenerationBilling = {credits:number;included:boolean;model:string;period:string;tariffVersion:number};

export type CapabilityQuote = {
  id: string;
  capability: string;
  providerId: string;
  provider: string;
  model: string;
  modelVersion: string;
  runtime: CapabilityRuntime;
  stability: CapabilityStability;
  rightsPolicy: string;
  dataPolicy: string;
  currency: "USD";
  amount: number;
  /** Authoritative retail credits; not derived from provider cost for inference models. */
  credits: number;
  billing?: GenerationBilling;
  reservationRequired: boolean;
  approvalRequired: boolean;
  approvedAt?: number;
  status: "quoted" | "reserved" | "consumed" | "expired";
  routingExplanation: string;
  /** Present on the initial quote. Later reads retain the exact provider but
   * may not have historical ranking evidence in schema-v1 storage. */
  routingDecision?: CapabilityRoutingDecision;
  expiresAt: number;
  createdAt: number;
};

export type CapabilityProviderMetric = {
  providerId: string;
  capability: string;
  jobs: number;
  successRate: number;
  averageLatencyMs: number;
  quotedCost: number;
  actualCost: number;
};

export type CapabilityReservation = {
  id: string;
  quoteId: string;
  currency: "USD";
  amount: number;
  status: "reserved" | "consumed" | "released";
  createdAt: number;
};

export type CapabilityJob<T = unknown> = {
  id: string;
  traceId?: string;
  projectId?: string;
  capability: string;
  providerId: string;
  quoteId: string;
  reservationId?: string;
  status: "queued" | "running" | "complete" | "failed" | "cancelled";
  lifecycleStatus: "queued" | "running" | "importing" | "succeeded" | "failed" | "cancelled";
  progress: number;
  estimatedCost: number;
  actualCost?: number;
  /** Account-owned generation price; legacy local jobs use operational conversion. */
  billing?: GenerationBilling;
  estimatedCredits: number;
  actualCredits?: number;
  attempt: number;
  maxAttempts: number;
  retryHistory: Array<{ attempt: number; status: string; error?: string; startedAt: number; completedAt?: number }>;
  input: Record<string, unknown>;
  output?: T;
  error?: string;
  deliveryBlocked?: boolean;
  deliveryBlockReason?: string;
  lifecycle: {
    queuedAt: number;
    startedAt?: number;
    importingAt?: number;
    completedAt?: number;
    elapsedMs: number;
    expectedRangeMs?: { p50: number; p90: number; samples: number };
    queuePosition?: number;
  };
  pricing: { quotedUsd: number; actualUsd?: number; status: "reserved" | "pending_reconciliation" | "actual" };
  createdAt: number;
  updatedAt: number;
};

export type BrollSearchInput = {
  projectId: string;
  query: string;
  excludeAssetIds?: string[];
};

export type BrollCandidate = {
  id: string;
  source: "workspace" | "licensed_stock";
  title: string;
  score: number;
  reason: string;
  assetId?: string;
  thumbnailUrl?: string;
  provenance: {
    provider: string;
    sourceUrl?: string;
    license: string;
    licenseSnapshot: string;
  };
};

export type BrollSearchOutput = {
  query: string;
  candidates: BrollCandidate[];
  routingExplanation: string;
};
