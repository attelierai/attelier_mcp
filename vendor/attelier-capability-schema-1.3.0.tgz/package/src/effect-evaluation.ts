import { EFFECT_CATALOG } from "@attelier/capability-schema/effect-catalog";

export const ATTELIER_EFFECT_EVALUATOR_VERSION = "1.4.0";

export type EffectMetricValue = number | boolean;
export type EffectMetricComparator = "lte" | "gte" | "eq";

export type EffectMetricGate = {
  metric: string;
  comparator: EffectMetricComparator;
  threshold: EffectMetricValue;
  unit?: string;
  description: string;
};

export type EffectGateSpec = {
  effectId: string;
  effectVersion: number;
  evaluatorVersion: string;
  gates: readonly EffectMetricGate[];
};

export type EffectParitySignal = number | boolean | string;
export type EffectParityCheckSpec = {
  signal: string;
  comparator: "abs-delta-lte" | "equal";
  threshold?: number;
  unit?: string;
  description: string;
};

export type EffectParitySpec = {
  effectId: string;
  effectVersion: number;
  evaluatorVersion: string;
  checks: readonly EffectParityCheckSpec[];
};

const spec = (effectId: string, gates: readonly EffectMetricGate[]): EffectGateSpec => ({
  effectId,
  effectVersion: 1,
  evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION,
  gates,
});

const lte = (metric: string, threshold: number, unit: string, description: string): EffectMetricGate => ({ metric, comparator: "lte", threshold, unit, description });
const gte = (metric: string, threshold: number, unit: string, description: string): EffectMetricGate => ({ metric, comparator: "gte", threshold, unit, description });
const yes = (metric: string, description: string): EffectMetricGate => ({ metric, comparator: "eq", threshold: true, description });
const delta = (signal: string, threshold: number, unit: string, description: string): EffectParityCheckSpec => ({ signal, comparator: "abs-delta-lte", threshold, unit, description });
const equal = (signal: string, description: string): EffectParityCheckSpec => ({ signal, comparator: "equal", description });

export const EFFECT_GATE_SPECS: readonly EffectGateSpec[] = [
  spec("atelier.transition.cross-dissolve", [
    yes("effective_overlap", "The authored overlap matches the requested transition."),
    lte("mix_curve_error", 0.03, "normalized opacity", "Preview/render samples follow the authored mix curve."),
    lte("black_frame_count", 0, "frames", "No accidental black frame is introduced."),
    yes("audio_continuity", "The declared audio treatment has no discontinuity."),
  ]),
  spec("atelier.transition.dip-to-black", [
    lte("luma_curve_error", 0.03, "normalized luma", "The rendered luma follows the authored dip."),
    lte("black_interval_error", 1, "frames", "Black is confined to the authored interval."),
    yes("audio_continuity", "The declared audio treatment has no discontinuity."),
  ]),
  spec("atelier.transition.dip-to-white", [
    lte("luma_curve_error", 0.03, "normalized luma", "The rendered luma follows the authored bright dip."),
    lte("white_interval_error", 1, "frames", "White is confined to the authored interval."),
    lte("plate_rgb_error", 3 / 255, "normalized RGB", "The revealed plate remains neutral white."),
    yes("audio_continuity", "The declared audio treatment has no discontinuity."),
  ]),
  spec("atelier.text.readable-overlay", [
    lte("words_per_second", 3.5, "words/second", "Essential text has sufficient reading time."),
    gte("contrast_ratio", 4.5, "ratio", "Essential text reaches the minimum contrast target."),
    gte("safe_area_intersection", 1, "coverage ratio", "The full essential text bounds remain inside the selected safe area."),
    lte("line_count", 3, "lines", "The overlay stays within the profile density limit."),
    lte("layout_delta", 2, "pixels", "Preview and render layout remain aligned."),
  ]),
  spec("atelier.motion.ken-burns", [
    lte("velocity_discontinuity", 0.1, "normalized velocity", "The motion path has no visible jump."),
    gte("subject_coverage", 0.9, "coverage ratio", "The protected subject remains framed."),
    lte("empty_canvas_pixels", 0, "pixels", "The transform never reveals empty canvas."),
    lte("preview_render_transform_delta", 2, "pixels", "Preview and render transforms remain aligned."),
  ]),
  spec("atelier.motion.stabilization", [
    lte("residual_global_motion", 0.08, "normalized motion", "Unintended global jitter falls below the delivery threshold."),
    lte("border_failure_frames", 0, "frames", "Stabilization introduces no black border frames."),
    lte("cadence_error", 0, "frames", "Frame cadence remains unchanged."),
    lte("duration_error_ticks", 1, "ticks", "Duration remains exact."),
  ]),
  spec("atelier.motion.motion-blur", [
    gte("temporal_mix_delta", 0.01, "normalized frame delta", "The encoded clip contains the authored temporal mix."),
    gte("detail_retention", 0.8, "similarity", "Essential spatial detail remains above the retention floor."),
    lte("cadence_error", 0, "frames", "Frame cadence remains unchanged."),
    lte("duration_error_ticks", 1, "ticks", "Duration remains exact."),
  ]),
  spec("atelier.retime.speed", [
    lte("duration_error_ticks", 1, "ticks", "Retime duration follows the canonical time model."),
    lte("source_window_error", 0, "ticks", "The sampled source window remains in bounds."),
    lte("av_sync_ms", 40, "milliseconds", "Audio and video remain synchronized."),
    lte("pitch_delta", 0.03, "relative ratio", "Pitch preservation remains within tolerance."),
  ]),
  spec("atelier.audio.professional-mix", [
    lte("lufs_i", 1, "absolute target error LU", "Integrated loudness is within one LU of the delivery target."),
    lte("true_peak_dbtp", -1, "dBTP", "True peak stays below the delivery ceiling."),
    lte("clipping_samples", 0, "samples", "The final mix has no clipped samples."),
    gte("dialogue_music_ratio", 4, "dB", "Dialogue remains sufficiently above music while speaking."),
    lte("hard_audio_cuts", 0, "cuts", "No un-authored hard audio cut is introduced."),
  ]),
  spec("atelier.color.match-and-look", [
    lte("reference_color_distance_delta", 0, "distance delta", "Matching does not increase distance from the reference."),
    lte("channel_clipping", 0.001, "pixel ratio", "Channel clipping remains below tolerance."),
    lte("protected_tone_delta", 3, "Delta E 2000", "Protected skin or product tones remain stable."),
    lte("preview_render_delta_e", 3, "Delta E 2000", "Preview and render color stay within tolerance."),
  ]),
  spec("atelier.region.blur", [
    lte("mask_position_delta", 0.001, "normalized position", "The encoded mask follows the authored or tracked centre."),
    lte("outside_region_delta", 0.01, "changed pixel ratio", "Pixels outside the mask remain stable."),
    gte("privacy_obscuration", 0.9, "obscuration ratio", "The sensitive detail is sufficiently obscured."),
  ]),
  spec("atelier.composite.subject-cutout", [
    gte("mask_iou", 0.9, "IoU", "The matte covers the approved subject."),
    lte("edge_halo", 0.05, "edge pixel ratio", "Visible edge contamination stays below tolerance."),
    lte("alpha_flicker", 0.05, "normalized temporal delta", "Alpha remains temporally stable."),
    gte("identity_fidelity", 0.95, "similarity", "Subject identity and geometry are preserved."),
    gte("lighting_consistency", 0.8, "similarity", "The composite lighting remains plausible."),
  ]),
  spec("atelier.region.inpaint", [
    gte("mask_compliance", 0.9, "coverage ratio", "The requested change stays inside the approved mask."),
    lte("outside_region_delta", 0.01, "changed pixel ratio", "Protected pixels outside the mask remain stable."),
    lte("boundary_artifact", 0.1, "normalized edge score", "The mask boundary integrates cleanly."),
    lte("temporal_flicker", 0.05, "normalized temporal delta", "The edited region remains temporally stable."),
    gte("context_consistency", 0.85, "similarity", "The replacement remains consistent with its context."),
  ]),
  spec("atelier.generate.image-to-video", [
    gte("reference_fidelity", 0.9, "similarity", "The reference product or subject remains recognizable."),
    lte("temporal_flicker", 0.08, "normalized temporal delta", "Generated motion remains temporally stable."),
    lte("identity_drift", 0.1, "normalized drift", "Identity and approved product details remain stable."),
    gte("motion_utility", 0.5, "utility score", "The output contains usable motion rather than a static substitute."),
    gte("endpoint_usability", 0.75, "usable endpoint ratio", "The head and tail provide usable edit handles."),
  ]),
  spec("atelier.identity.lip-sync", [
    lte("av_sync_ms", 80, "milliseconds", "Mouth motion remains synchronized to the approved audio."),
    gte("identity_fidelity", 0.95, "similarity", "The authorized identity remains stable."),
    gte("face_region_stability", 0.9, "similarity", "Non-mouth facial regions remain stable."),
    lte("artifact_rate", 0.05, "affected frame ratio", "Severe face deformation remains below tolerance."),
    yes("consent_validity", "Consent is active and scoped to this purpose."),
  ]),
] as const;

export const EFFECT_PARITY_SPECS: readonly EffectParitySpec[] = [
  { effectId: "atelier.transition.cross-dissolve", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("envelopeOpacity", 0.03, "normalized opacity", "The sampled blend envelope matches."), delta("timingFrames", 1, "frames", "The transition starts and ends on the same frames.")] },
  { effectId: "atelier.transition.dip-to-black", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("envelopeOpacity", 0.03, "normalized opacity", "The sampled dip envelope matches."), delta("timingFrames", 1, "frames", "The black interval timing matches."), delta("plateNeutrality", 3 / 255, "normalized RGB", "The black plate remains neutral.")] },
  { effectId: "atelier.transition.dip-to-white", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("envelopeOpacity", 0.03, "normalized opacity", "The sampled bright-dip envelope matches."), delta("timingFrames", 1, "frames", "The white interval timing matches."), delta("plateNeutrality", 3 / 255, "normalized RGB", "The white plate remains neutral.")] },
  { effectId: "atelier.text.readable-overlay", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("layoutX", 2, "pixels", "Horizontal text placement stays aligned."), delta("layoutY", 2, "pixels", "Vertical text placement stays aligned."), delta("fontSize", 1, "pixels", "The effective font size stays aligned."), delta("fadeMs", 10, "milliseconds", "Text fade timing stays aligned.")] },
  { effectId: "atelier.motion.ken-burns", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("positionX", 2, "pixels", "Horizontal position stays aligned."), delta("positionY", 2, "pixels", "Vertical position stays aligned."), delta("scale", 0.005, "scale", "Scale stays aligned.")] },
  { effectId: "atelier.motion.stabilization", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [equal("renderOnlyTreatment", "The browser reports that stabilization is evaluated on encoded output rather than pretending to preview it.")] },
  { effectId: "atelier.motion.motion-blur", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [equal("renderOnlyTreatment", "The browser reports that temporal blur is evaluated on encoded output rather than pretending to preview it.")] },
  { effectId: "atelier.retime.speed", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("sourceTimeFrames", 1, "frames", "Preview and render sample the same source frame."), delta("durationTicks", 1, "ticks", "Retime duration stays exact.")] },
  { effectId: "atelier.audio.professional-mix", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("gainDb", 1, "dB", "Gain envelopes stay aligned."), delta("fadeInMs", 10, "milliseconds", "Fade-in timing stays aligned."), delta("fadeOutMs", 10, "milliseconds", "Fade-out timing stays aligned.")] },
  { effectId: "atelier.color.match-and-look", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("brightness", 0.01, "normalized brightness", "Matched brightness stays aligned."), delta("saturation", 0.01, "ratio", "Matched saturation stays aligned."), delta("redBalance", 0.01, "normalized channel balance", "Red balance stays aligned."), delta("blueBalance", 0.01, "normalized channel balance", "Blue balance stays aligned."), equal("look", "The same creative look is selected on both surfaces.")] },
  { effectId: "atelier.region.blur", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [delta("centerX", 0.001, "normalized position", "Tracked horizontal mask position stays aligned."), delta("centerY", 0.001, "normalized position", "Tracked vertical mask position stays aligned."), delta("width", 0.001, "normalized size", "Mask width stays aligned."), delta("height", 0.001, "normalized size", "Mask height stays aligned."), delta("strength", 0.01, "blur sigma", "Blur strength stays aligned.")] },
  { effectId: "atelier.composite.subject-cutout", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [equal("contentHash", "Preview and render decode the same immutable asset.")] },
  { effectId: "atelier.region.inpaint", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [equal("contentHash", "Preview and render decode the same immutable asset.")] },
  { effectId: "atelier.generate.image-to-video", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [equal("contentHash", "Preview and render decode the same immutable asset.")] },
  { effectId: "atelier.identity.lip-sync", effectVersion: 1, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, checks: [equal("contentHash", "Preview and render decode the same immutable asset.")] },
] as const;

const stableValue = (value: unknown): unknown => {
  if (Array.isArray(value)) return value.map(stableValue);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>)
      .filter(([, item]) => item !== undefined)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, item]) => [key, stableValue(item)]));
  }
  return value;
};

/** A deterministic identity for the exact authored effect parameters sampled on both surfaces. */
export const createEffectIntentKey = (effectId: string, effectVersion: number, parameters: Record<string, unknown>): string => {
  const contract = EFFECT_CATALOG.find((effect) => effect.effectId === effectId);
  if (!contract || contract.version !== effectVersion) throw new Error(`Unknown effect intent ${effectId}@${effectVersion}.`);
  return `${effectId}@${effectVersion}:${JSON.stringify(stableValue(parameters))}`;
};

export type EffectParityInput = {
  effectId: string;
  effectVersion: number;
  preview: { intentKey: string; signals: Record<string, EffectParitySignal> };
  render: { intentKey: string; signals: Record<string, EffectParitySignal> };
};

export type EffectParityResult = {
  effectId: string;
  effectVersion: number;
  evaluatorVersion: string;
  status: "pass" | "fail" | "incomplete";
  sameIntent: boolean;
  checks: Array<EffectParityCheckSpec & { preview?: EffectParitySignal; render?: EffectParitySignal; delta?: number; passed?: boolean }>;
  missingSignals: string[];
};

export const evaluatePreviewRenderParity = (input: EffectParityInput): EffectParityResult => {
  if (!input || typeof input !== "object" || typeof input.effectId !== "string" || !Number.isInteger(input.effectVersion)) {
    throw new Error("A versioned effectId is required.");
  }
  for (const [surface, sample] of [["preview", input.preview], ["render", input.render]] as const) {
    if (!sample || typeof sample !== "object" || typeof sample.intentKey !== "string" || !sample.intentKey || !sample.signals || typeof sample.signals !== "object" || Array.isArray(sample.signals)) {
      throw new Error(`${surface} requires intentKey and signals.`);
    }
    if (Object.values(sample.signals).some((value) => !["number", "boolean", "string"].includes(typeof value) || (typeof value === "number" && !Number.isFinite(value)))) {
      throw new Error(`${surface} signals must be finite numbers, booleans or strings.`);
    }
  }
  const contract = EFFECT_CATALOG.find(({ effectId }) => effectId === input.effectId);
  const spec = EFFECT_PARITY_SPECS.find(({ effectId }) => effectId === input.effectId);
  if (!contract || !spec) throw new Error(`Unknown effect parity contract ${input.effectId}.`);
  if (input.effectVersion !== contract.version || input.effectVersion !== spec.effectVersion) throw new Error(`Effect ${input.effectId} requires version ${contract.version}.`);
  const sameIntent = input.preview.intentKey === input.render.intentKey;
  const checks: EffectParityResult["checks"] = spec.checks.map((check) => {
    const preview = input.preview.signals[check.signal];
    const render = input.render.signals[check.signal];
    if (preview === undefined || render === undefined) return {
      ...check,
      ...(preview === undefined ? {} : { preview }),
      ...(render === undefined ? {} : { render }),
    };
    if (check.comparator === "equal") return { ...check, preview, render, passed: preview === render };
    const comparable = typeof preview === "number" && Number.isFinite(preview) && typeof render === "number" && Number.isFinite(render);
    const measuredDelta = comparable ? Math.abs(preview - render) : undefined;
    return { ...check, preview, render, ...(measuredDelta === undefined ? {} : { delta: measuredDelta }), passed: measuredDelta !== undefined && measuredDelta <= (check.threshold ?? -1) };
  });
  const missingSignals = checks.filter(({ preview, render }) => preview === undefined || render === undefined).map(({ signal }) => signal);
  const status = !sameIntent || checks.some(({ passed }) => passed === false)
    ? "fail"
    : missingSignals.length > 0 ? "incomplete" : "pass";
  return { effectId: input.effectId, effectVersion: input.effectVersion, evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION, status, sameIntent, checks, missingSignals };
};

export type EffectGateInput = {
  effectId: string;
  effectVersion: number;
  metrics: Record<string, EffectMetricValue>;
  observedCriticalFailures?: string[];
};

export type EffectGateResult = {
  effectId: string;
  effectVersion: number;
  evaluatorVersion: string;
  status: "pass" | "fail" | "incomplete";
  objectiveContractOnly: true;
  perceptualJudgment: "not_evaluated";
  checks: Array<EffectMetricGate & { actual?: EffectMetricValue; passed?: boolean }>;
  missingMetrics: string[];
  criticalFailures: string[];
};

const passes = (gate: EffectMetricGate, actual: EffectMetricValue): boolean => {
  if (typeof gate.threshold !== typeof actual) return false;
  if (gate.comparator === "eq") return actual === gate.threshold;
  if (typeof actual !== "number" || typeof gate.threshold !== "number" || !Number.isFinite(actual)) return false;
  return gate.comparator === "lte" ? actual <= gate.threshold : actual >= gate.threshold;
};

export const evaluateEffectContract = (input: EffectGateInput): EffectGateResult => {
  if (!input || typeof input !== "object" || typeof input.effectId !== "string" || !Number.isInteger(input.effectVersion)) {
    throw new Error("A versioned effectId is required.");
  }
  if (!input.metrics || typeof input.metrics !== "object" || Array.isArray(input.metrics) || Object.values(input.metrics).some((value) => typeof value !== "number" && typeof value !== "boolean")) {
    throw new Error("Effect metrics must contain only numeric or boolean signals.");
  }
  if (input.observedCriticalFailures !== undefined && (!Array.isArray(input.observedCriticalFailures) || input.observedCriticalFailures.some((value) => typeof value !== "string"))) {
    throw new Error("observedCriticalFailures must be a string array.");
  }
  const contract = EFFECT_CATALOG.find(({ effectId }) => effectId === input.effectId);
  const gateSpec = EFFECT_GATE_SPECS.find(({ effectId }) => effectId === input.effectId);
  if (!contract || !gateSpec) throw new Error(`Unknown effect contract ${input.effectId}.`);
  if (input.effectVersion !== contract.version || input.effectVersion !== gateSpec.effectVersion) {
    throw new Error(`Effect ${input.effectId} requires version ${contract.version}.`);
  }
  const invalidFailures = (input.observedCriticalFailures ?? []).filter((failure) => !contract.criticalFailures.includes(failure));
  if (invalidFailures.length > 0) throw new Error(`Unknown critical failure for ${input.effectId}: ${invalidFailures.join(", ")}.`);
  const checks: EffectGateResult["checks"] = gateSpec.gates.map((gate) => {
    const actual = input.metrics[gate.metric];
    return actual === undefined ? { ...gate } : { ...gate, actual, passed: passes(gate, actual) };
  });
  const missingMetrics = checks.filter(({ actual }) => actual === undefined).map(({ metric }) => metric);
  const criticalFailures = [...new Set(input.observedCriticalFailures ?? [])];
  const status = criticalFailures.length > 0 || checks.some(({ passed }) => passed === false)
    ? "fail"
    : missingMetrics.length > 0 ? "incomplete" : "pass";
  return {
    effectId: input.effectId,
    effectVersion: input.effectVersion,
    evaluatorVersion: ATTELIER_EFFECT_EVALUATOR_VERSION,
    status,
    objectiveContractOnly: true,
    perceptualJudgment: "not_evaluated",
    checks,
    missingMetrics,
    criticalFailures,
  };
};

export const validateEffectGateSpecs = (): string[] => {
  const issues: string[] = [];
  for (const effect of EFFECT_CATALOG) {
    const gateSpec = EFFECT_GATE_SPECS.find(({ effectId }) => effectId === effect.effectId);
    if (!gateSpec) {
      issues.push(`${effect.effectId} has no objective gate spec`);
      continue;
    }
    if (gateSpec.effectVersion !== effect.version) issues.push(`${effect.effectId} gate version drifted`);
    if (gateSpec.gates.length === 0) issues.push(`${effect.effectId} has no objective metric gates`);
    const paritySpec = EFFECT_PARITY_SPECS.find(({ effectId }) => effectId === effect.effectId);
    if (!paritySpec) issues.push(`${effect.effectId} has no preview/render parity spec`);
    else {
      if (paritySpec.effectVersion !== effect.version) issues.push(`${effect.effectId} parity version drifted`);
      if (paritySpec.checks.length === 0) issues.push(`${effect.effectId} has no preview/render parity checks`);
    }
    for (const gate of gateSpec.gates) {
      if (!effect.metrics.includes(gate.metric)) issues.push(`${effect.effectId} gate references unknown metric ${gate.metric}`);
    }
  }
  for (const gateSpec of EFFECT_GATE_SPECS) {
    if (!EFFECT_CATALOG.some(({ effectId }) => effectId === gateSpec.effectId)) issues.push(`${gateSpec.effectId} gate has no effect contract`);
  }
  for (const paritySpec of EFFECT_PARITY_SPECS) {
    if (!EFFECT_CATALOG.some(({ effectId }) => effectId === paritySpec.effectId)) issues.push(`${paritySpec.effectId} parity spec has no effect contract`);
  }
  return issues;
};
