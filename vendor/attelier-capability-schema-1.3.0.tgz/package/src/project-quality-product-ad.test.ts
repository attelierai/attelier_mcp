import assert from "node:assert/strict";
import test from "node:test";
import type { Asset, Project, TimelineElement, Track } from "@attelier/project-schema";
import { evaluateProjectQuality } from "./project-quality.js";

const ticks = (seconds: number) => String(seconds * 120_000) as TimelineElement["timelineRange"]["start"];
const asset = (id: string, width: number, height: number, publishable = true): Asset => ({
  id,
  name: id,
  mediaType: id === "voice" ? "audio" : "image",
  role: "original",
  width: id === "voice" ? undefined : width,
  height: id === "voice" ? undefined : height,
  duration: id === "voice" ? ticks(4) : undefined,
  storage: [],
  provenance: { origin: "uploaded", provider: "fixture", rights: { license: "fixture", publishable }, createdAt: 1 },
});
const element = (id: string, kind: TimelineElement["kind"], assetId: string | undefined, start: number, duration: number, properties: Record<string, unknown> = {}): TimelineElement => ({
  id,
  name: id,
  kind,
  ...(assetId ? { assetId } : {}),
  timelineRange: { start: ticks(start), duration: ticks(duration) },
  ...(kind === "audio" ? { sourceRange: { start: ticks(0), duration: ticks(duration) } } : {}),
  properties,
  keyframes: kind === "image" ? [{ path: "transform.scale", keyframes: [{ id: `${id}-a`, at: ticks(0), value: 1, easing: "linear" }, { id: `${id}-b`, at: ticks(duration), value: 1.04, easing: "linear" }] }] : [],
});
const track = (id: string, kind: Track["kind"], elements: TimelineElement[], order: number): Track => ({ id, name: id, kind, elements, order, locked: false, muted: false, hidden: false });
const project = (visuals: TimelineElement[], assets: Asset[], voicePublishable = true): Project => ({
  schemaVersion: 2,
  id: "quality",
  name: "quality",
  revision: 1,
  activeSequenceId: "main",
  assets: [...assets, asset("voice", 0, 0, voicePublishable)],
  appliedTransactionIds: [],
  sequences: [{ id: "main", name: "main", canvas: { width: 1080, height: 1920 }, frameRate: { numerator: 30, denominator: 1 }, tracks: [
    track("visual", "video", visuals, 0),
    track("text", "text", [element("cta", "text", undefined, 0, 4, { "text.content": "TRY BUFFER", "text.role": "cta", "effect.text.id": "atelier.text.readable-overlay", "transform.position": [0.5, 0.7] })], 1),
    track("audio", "audio", [element("voice-el", "audio", "voice", 0, 4, { "audio.role": "voiceover", "audio.normalizeLufs": -14 })], 2),
  ] }],
});

test("product-ad quality fails a landscape contain shot with mostly empty canvas", () => {
  const hero = asset("hero", 1200, 630);
  const report = evaluateProjectQuality(project([element("hero-el", "image", "hero", 0, 4)], [hero]), "product-ad-v1");
  assert.ok(report.issues.some(({ id, severity }) => id === "safe-area.empty-canvas.hero-el" && severity === "critical"));
});

test("product-ad quality accepts an explicit cover for a sufficiently large visual", () => {
  const hero = asset("hero", 1200, 630);
  const report = evaluateProjectQuality(project([element("hero-el", "image", "hero", 0, 4, { "transform.fit": "cover" })], [hero]), "product-ad-v1");
  assert.ok(!report.issues.some(({ id }) => id === "safe-area.empty-canvas.hero-el"));
});

test("product-ad quality accepts a contained proof panel over a covering designed background", () => {
  const background = asset("background", 1080, 1920);
  const proof = asset("proof", 1900, 950);
  const report = evaluateProjectQuality(project([
    element("background-el", "image", "background", 0, 4, { "transform.fit": "cover" }),
    element("proof-el", "image", "proof", 0, 4, { "transform.fit": "contain", "transform.scale": 0.9 }),
  ], [background, proof]), "product-ad-v1");
  assert.ok(!report.issues.some(({ id }) => id === "safe-area.empty-canvas.proof-el"));
});

test("product-ad quality rejects tiny full-frame assets, flash shots and preview-only voice", () => {
  const icon = asset("icon", 32, 32);
  const report = evaluateProjectQuality(project([element("icon-el", "image", "icon", 0, 0.85, { "transform.fit": "cover" })], [icon], false), "product-ad-v1");
  const ids = new Set(report.issues.map(({ id }) => id));
  assert.ok(ids.has("technical.visual-resolution.icon-el"));
  assert.ok(ids.has("motion.flash-shot.icon-el"));
  assert.ok(ids.has("audio.voice-not-publishable.voice-el"));
  assert.equal(report.passedGates, false);
});
