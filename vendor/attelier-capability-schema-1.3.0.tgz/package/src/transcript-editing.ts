import type {
  TranscriptArtifact,
  TranscriptSegment,
  TranscriptWord,
} from "@attelier/analysis-schema";
import type {
  MediaTime,
  Project,
  ProjectOperation,
  TimelineElement,
  Track,
} from "@attelier/project-schema";
import { TICKS_PER_SECOND } from "@attelier/project-schema";

export const ATTELIER_TRANSCRIPT_EDITING_VERSION = "1.0.0";

export type TranscriptCleanupKind = "fillers" | "silences" | "repetitions";

export type TranscriptEditFinding = {
  id: string;
  kind: TranscriptCleanupKind | "manual";
  text: string;
  elementId: string;
  sourceRange: { start: MediaTime; end: MediaTime };
  timelineRange: { start: MediaTime; end: MediaTime };
  confidence?: number;
};

export type TranscriptEditPlan = {
  label: string;
  operations: ProjectOperation[];
  findings: TranscriptEditFinding[];
  metrics: {
    findingCount: number;
    removedDurationTicks: number;
  };
};

export type CaptionPlanOptions = {
  maxWordsPerCaption?: number;
  fontSize?: number;
  position?: "lower-middle" | "lower-third";
  elementId?: string;
};

export type TranscriptCleanupOptions = {
  elementId?: string;
  minimumSilenceSeconds?: number;
  targetSilenceSeconds?: number;
  minimumFillerConfidence?: number;
};

export type TranscriptSearchMatch = {
  id: string;
  text: string;
  speakerId: string;
  wordIds: string[];
  elementId: string;
  sourceRange: { start: MediaTime; end: MediaTime };
  timelineRange: { start: MediaTime; end: MediaTime };
};

const lexicalTokens = (value: string): string[] =>
  value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .match(/[a-z0-9]+/g) ?? [];

const normalizedPhrase = (value: string): string => lexicalTokens(value).join(" ");

/** Reject obviously unrelated ASR before it becomes authoritative on-screen copy. */
export const transcriptMatchesReference = (transcript: string, reference: string): boolean => {
  const expected = lexicalTokens(reference).filter((token) => token.length >= 2);
  if (expected.length < 5) return true;
  const heard = new Set(lexicalTokens(transcript).filter((token) => token.length >= 2));
  const overlap = expected.filter((token) => heard.has(token)).length / expected.length;
  return overlap >= 0.45;
};

const ticks = (value: number): MediaTime => String(Math.round(value)) as MediaTime;
const end = (start: MediaTime, duration: MediaTime): number => Number(start) + Number(duration);

const activeSequence = (project: Project) =>
  project.sequences.find((sequence) => sequence.id === project.activeSequenceId);

const sourceElements = (project: Project, assetId: string): Array<{ track: Track; element: TimelineElement }> => {
  const sequence = activeSequence(project);
  if (!sequence) return [];
  return sequence.tracks.flatMap((track) =>
    track.elements.flatMap((element) =>
      element.assetId === assetId && element.sourceRange ? [{ track, element }] : [],
    ),
  );
};

const containsSourceRange = (
  element: TimelineElement,
  range?: { start: MediaTime; end: MediaTime },
): boolean => {
  if (!range || !element.sourceRange) return Boolean(element.sourceRange);
  return Number(range.start) >= Number(element.sourceRange.start) &&
    Number(range.end) <= end(element.sourceRange.start, element.sourceRange.duration);
};

const sourceElement = (
  project: Project,
  assetId: string,
  range?: { start: MediaTime; end: MediaTime },
  elementId?: string,
): { track: Track; element: TimelineElement } => {
  const candidates = sourceElements(project, assetId).filter(({ element }) =>
    (!elementId || element.id === elementId) && containsSourceRange(element, range),
  );
  if (candidates.length === 1) return candidates[0]!;
  if (candidates.length === 0) {
    throw new Error("Insert the transcribed source on the timeline before editing it, and select a source-backed clip.");
  }
  throw new Error("This source appears more than once on the timeline. Select the exact element before editing its transcript.");
};

const timelineRangeFor = (
  element: TimelineElement,
  sourceRange: { start: MediaTime; end: MediaTime },
): { start: MediaTime; end: MediaTime } => {
  if (!element.sourceRange) throw new Error("Transcript edits require a source-backed timeline element.");
  const timelineStart = Number(element.timelineRange.start) +
    Number(sourceRange.start) -
    Number(element.sourceRange.start);
  const timelineEnd = timelineStart + Number(sourceRange.end) - Number(sourceRange.start);
  const elementEnd = end(element.timelineRange.start, element.timelineRange.duration);
  if (timelineStart < Number(element.timelineRange.start) || timelineEnd > elementEnd || timelineEnd <= timelineStart) {
    throw new Error("Transcript range does not map to a valid timeline range.");
  }
  return { start: ticks(timelineStart), end: ticks(timelineEnd) };
};

const findingFor = (
  element: TimelineElement,
  input: {
    id: string;
    kind: TranscriptEditFinding["kind"];
    text: string;
    start: MediaTime;
    end: MediaTime;
    confidence?: number;
  },
): TranscriptEditFinding => ({
  id: input.id,
  kind: input.kind,
  text: input.text,
  elementId: element.id,
  sourceRange: { start: input.start, end: input.end },
  timelineRange: timelineRangeFor(element, { start: input.start, end: input.end }),
  ...(input.confidence === undefined ? {} : { confidence: input.confidence }),
});

const operationsForFindings = (
  project: Project,
  findings: TranscriptEditFinding[],
  idFactory: () => string,
): ProjectOperation[] =>
  [...findings]
    .sort((left, right) => Number(right.timelineRange.start) - Number(left.timelineRange.start))
    .map((finding) => ({
      type: "rippleDeleteRange" as const,
      sequenceId: project.activeSequenceId,
      start: finding.timelineRange.start,
      end: finding.timelineRange.end,
      generatedIdPrefix: `transcript-${finding.id}-${idFactory()}`,
    }));

const planFromFindings = (
  project: Project,
  label: string,
  findings: TranscriptEditFinding[],
  idFactory: () => string,
): TranscriptEditPlan => ({
  label,
  operations: operationsForFindings(project, findings, idFactory),
  findings,
  metrics: {
    findingCount: findings.length,
    removedDurationTicks: findings.reduce(
      (total, finding) => total + Number(finding.timelineRange.end) - Number(finding.timelineRange.start),
      0,
    ),
  },
});

export const planTranscriptRippleDelete = (
  project: Project,
  assetId: string,
  segment: TranscriptSegment,
  idFactory: () => string = () => crypto.randomUUID(),
  elementId?: string,
): TranscriptEditPlan => {
  const located = sourceElement(
    project,
    assetId,
    { start: segment.start, end: segment.end },
    elementId,
  );
  const finding = findingFor(located.element, {
    id: segment.id,
    kind: "manual",
    text: segment.text,
    start: segment.start,
    end: segment.end,
  });
  return planFromFindings(
    project,
    `Remove transcript sentence: ${segment.text}`,
    [finding],
    idFactory,
  );
};

export const planCaptionTrack = (
  project: Project,
  transcript: TranscriptArtifact,
  idFactory: () => string = () => crypto.randomUUID(),
  options: CaptionPlanOptions = {},
): TranscriptEditPlan => {
  const sequence = activeSequence(project);
  if (!sequence) throw new Error("Project has no active sequence.");
  const located = sourceElement(project, transcript.assetId, undefined, options.elementId);
  const operations: ProjectOperation[] = [];
  let captionTrack = sequence.tracks.find((track) => track.kind === "caption" && !track.locked);
  if (!captionTrack) {
    captionTrack = {
      id: `track-captions-${idFactory()}`,
      name: "Captions",
      kind: "caption",
      order: Math.max(-1, ...sequence.tracks.map((track) => track.order)) + 1,
      locked: false,
      muted: false,
      hidden: false,
      elements: [],
    };
    operations.push({ type: "addTrack", sequenceId: sequence.id, track: captionTrack });
  }
  const element = located.element;
  const sourceRange = element.sourceRange;
  if (!sourceRange) throw new Error("Captions require a source-backed timeline element.");
  const elementStart = Number(element.timelineRange.start);
  const elementFinish = end(element.timelineRange.start, element.timelineRange.duration);
  const existingCaptionOverlap = captionTrack.elements.some((caption) => {
    const captionStart = Number(caption.timelineRange.start);
    const captionFinish = end(caption.timelineRange.start, caption.timelineRange.duration);
    return captionStart < elementFinish && captionFinish > elementStart;
  });
  if (existingCaptionOverlap) {
    throw new Error("This clip already has overlapping captions. Remove or replace them explicitly instead of creating duplicates.");
  }
  const sourceStart = Number(sourceRange.start);
  const sourceEnd = end(sourceRange.start, sourceRange.duration);
  const maxWords = Math.max(2, Math.min(7, Math.round(options.maxWordsPerCaption ?? 5)));
  const wordsById = new Map(transcript.words.map((word) => [word.id, word]));
  const captionSegments = transcript.segments.flatMap((segment) => {
    const words = segment.wordIds
      .map((id) => wordsById.get(id))
      .filter((word): word is TranscriptWord => Boolean(word));
    if (words.length === 0) return [segment];
    const chunks: TranscriptSegment[] = [];
    for (let index = 0; index < words.length; index += maxWords) {
      const chunk = words.slice(index, index + maxWords);
      chunks.push({
        id: `${segment.id}-${Math.floor(index / maxWords) + 1}`,
        text: chunk.map(({ text }) => text).join(" ").trim(),
        start: chunk[0]!.start,
        end: chunk[chunk.length - 1]!.end,
        speakerId: segment.speakerId,
        wordIds: chunk.map(({ id }) => id),
      });
    }
    return chunks;
  });
  let inserted = 0;
  for (const segment of captionSegments) {
    if (Number(segment.start) < sourceStart || Number(segment.end) > sourceEnd) continue;
    const mapped = timelineRangeFor(element, { start: segment.start, end: segment.end });
    operations.push({
      type: "insertElement",
      trackId: captionTrack.id,
      element: {
        id: `caption-${segment.id}-${idFactory()}`,
        name: segment.text,
        kind: "caption",
        timelineRange: {
          start: mapped.start,
          duration: ticks(Number(mapped.end) - Number(mapped.start)),
        },
        properties: {
          "text.content": segment.text,
          "caption.speakerId": segment.speakerId,
          "caption.style": "social-clean",
          "caption.maxWords": maxWords,
          "style.color": "#ffffff",
          "style.fontSize": Math.max(24, Math.min(96, Math.round(options.fontSize ?? 48))),
          "text.boxed": true,
          "transform.position": [0.5, options.position === "lower-third" ? 0.76 : 0.72],
          "effect.text.id": "atelier.text.readable-overlay",
          "effect.text.version": 1,
        },
        keyframes: [],
      },
    });
    inserted += 1;
  }
  if (inserted === 0) throw new Error("No transcript segments map to this timeline clip.");
  return {
    label: `Create ${inserted} synchronized captions`,
    operations,
    findings: [],
    metrics: { findingCount: inserted, removedDurationTicks: 0 },
  };
};

const inSourceWindow = (element: TimelineElement, start: MediaTime, finish: MediaTime): boolean =>
  containsSourceRange(element, { start, end: finish });

export const planTranscriptCleanup = (
  project: Project,
  transcript: TranscriptArtifact,
  kind: TranscriptCleanupKind,
  idFactory: () => string = () => crypto.randomUUID(),
  options: TranscriptCleanupOptions = {},
): TranscriptEditPlan => {
  const located = sourceElement(project, transcript.assetId, undefined, options.elementId);
  const element = located.element;
  const findings: TranscriptEditFinding[] = [];
  if (kind === "fillers") {
    const confidenceFloor = Math.max(0, Math.min(1, options.minimumFillerConfidence ?? 0.5));
    for (const word of transcript.words) {
      if (!word.isFiller || word.confidence < confidenceFloor || !inSourceWindow(element, word.start, word.end)) continue;
      findings.push(findingFor(element, {
        id: word.id,
        kind,
        text: word.text,
        start: word.start,
        end: word.end,
        confidence: word.confidence,
      }));
    }
  } else if (kind === "silences") {
    const minimumSeconds = options.minimumSilenceSeconds ?? 0.8;
    const targetSeconds = options.targetSilenceSeconds ?? 0.35;
    if (!Number.isFinite(minimumSeconds) || !Number.isFinite(targetSeconds) ||
      minimumSeconds <= targetSeconds || targetSeconds < 0.08) {
      throw new Error("Silence cleanup requires minimumSilenceSeconds > targetSilenceSeconds >= 0.08.");
    }
    const minimumTicks = Math.round(minimumSeconds * TICKS_PER_SECOND);
    const targetTicks = Math.round(targetSeconds * TICKS_PER_SECOND);
    const words = [...transcript.words].sort((left, right) => Number(left.start) - Number(right.start));
    for (let index = 0; index < words.length - 1; index += 1) {
      const left = words[index]!;
      const right = words[index + 1]!;
      const gap = Number(right.start) - Number(left.end);
      if (gap < minimumTicks || !inSourceWindow(element, left.end, right.start)) continue;
      const keepBefore = Math.floor(targetTicks / 2);
      const keepAfter = targetTicks - keepBefore;
      const start = ticks(Number(left.end) + keepBefore);
      const finish = ticks(Number(right.start) - keepAfter);
      if (Number(finish) <= Number(start)) continue;
      findings.push(findingFor(element, {
        id: `silence-${left.id}-${right.id}`,
        kind,
        text: "long silence",
        start,
        end: finish,
      }));
    }
  } else {
    const segments = [...transcript.segments].sort((left, right) => Number(left.start) - Number(right.start));
    for (let index = 1; index < segments.length; index += 1) {
      const previous = segments[index - 1]!;
      const current = segments[index]!;
      if (!normalizedPhrase(previous.text) || normalizedPhrase(previous.text) !== normalizedPhrase(current.text)) continue;
      if (!inSourceWindow(element, current.start, current.end)) continue;
      findings.push(findingFor(element, {
        id: current.id,
        kind,
        text: current.text,
        start: current.start,
        end: current.end,
      }));
    }
  }
  if (findings.length === 0) throw new Error(`No ${kind} were detected in this transcript selection.`);
  const verb = kind === "silences" ? "Shorten" : "Remove";
  return planFromFindings(project, `${verb} ${findings.length} detected ${kind}`, findings, idFactory);
};

export const searchTranscript = (
  project: Project,
  transcript: TranscriptArtifact,
  query: string,
  options: { elementId?: string } = {},
): { query: string; matches: TranscriptSearchMatch[] } => {
  const queryTokens = lexicalTokens(query);
  if (queryTokens.length === 0) throw new Error("Transcript search requires at least one letter or number.");
  const words = [...transcript.words].sort((left, right) => Number(left.start) - Number(right.start));
  const sourceMatches: Array<{ id: string; text: string; speakerId: string; wordIds: string[]; start: MediaTime; end: MediaTime }> = [];
  for (let index = 0; index <= words.length - queryTokens.length; index += 1) {
    const window = words.slice(index, index + queryTokens.length);
    if (window.some((word, offset) => normalizedPhrase(word.text) !== queryTokens[offset])) continue;
    sourceMatches.push({
      id: `words-${window[0]!.id}-${window[window.length - 1]!.id}`,
      text: window.map(({ text }) => text).join(" "),
      speakerId: window[0]!.speakerId,
      wordIds: window.map(({ id }) => id),
      start: window[0]!.start,
      end: window[window.length - 1]!.end,
    });
  }
  if (sourceMatches.length === 0) {
    const needle = queryTokens.join(" ");
    for (const segment of transcript.segments) {
      if (!normalizedPhrase(segment.text).includes(needle)) continue;
      sourceMatches.push({
        id: segment.id,
        text: segment.text,
        speakerId: segment.speakerId,
        wordIds: segment.wordIds,
        start: segment.start,
        end: segment.end,
      });
    }
  }
  const candidates = sourceElements(project, transcript.assetId).filter(({ element }) =>
    !options.elementId || element.id === options.elementId,
  );
  if (candidates.length === 0) throw new Error("The transcribed source is not present in the selected timeline element.");
  const matches = sourceMatches.flatMap((match) =>
    candidates.flatMap(({ element }) => {
      if (!containsSourceRange(element, { start: match.start, end: match.end })) return [];
      return [{
        id: `${match.id}:${element.id}`,
        text: match.text,
        speakerId: match.speakerId,
        wordIds: match.wordIds,
        elementId: element.id,
        sourceRange: { start: match.start, end: match.end },
        timelineRange: timelineRangeFor(element, { start: match.start, end: match.end }),
      }];
    }),
  );
  return { query: query.trim(), matches };
};

export const planBrollInsert = (
  project: Project,
  transcript: TranscriptArtifact,
  segment: TranscriptSegment,
  assetId: string,
  idFactory: () => string = () => crypto.randomUUID(),
): TranscriptEditPlan => {
  const sequence = activeSequence(project);
  if (!sequence) throw new Error("Project has no active sequence.");
  const asset = project.assets.find((candidate) => candidate.id === assetId);
  if (!asset || (asset.mediaType !== "video" && asset.mediaType !== "image")) {
    throw new Error("Selected B-roll must be an image or video asset in this project.");
  }
  const located = sourceElement(project, transcript.assetId, { start: segment.start, end: segment.end });
  const mapped = timelineRangeFor(located.element, { start: segment.start, end: segment.end });
  const start = Number(mapped.start);
  const requestedDuration = Number(mapped.end) - start;
  const duration = asset.mediaType === "video" && asset.duration
    ? Math.min(requestedDuration, Number(asset.duration))
    : requestedDuration;
  if (duration <= 0) throw new Error("Selected B-roll has no usable duration.");
  const finish = start + duration;
  const overlaps = (track: Track) =>
    track.elements.some((element) => {
      const elementStart = Number(element.timelineRange.start);
      const elementEnd = end(element.timelineRange.start, element.timelineRange.duration);
      return elementStart < finish && elementEnd > start;
    });
  let track = sequence.tracks.find((candidate) =>
    candidate.kind === "video" &&
    !candidate.locked &&
    candidate.name.startsWith("B-roll") &&
    !overlaps(candidate),
  );
  const operations: ProjectOperation[] = [];
  if (!track) {
    const suffix = sequence.tracks.filter((candidate) => candidate.name.startsWith("B-roll")).length + 1;
    track = {
      id: `track-broll-${idFactory()}`,
      name: suffix === 1 ? "B-roll" : `B-roll ${suffix}`,
      kind: "video",
      order: Math.max(-1, ...sequence.tracks.map((candidate) => candidate.order)) + 1,
      locked: false,
      muted: false,
      hidden: false,
      elements: [],
    };
    operations.push({ type: "addTrack", sequenceId: sequence.id, track });
  }
  operations.push({
    type: "insertElement",
    trackId: track.id,
    element: {
      id: `broll-${segment.id}-${idFactory()}`,
      name: `B-roll · ${asset.name}`,
      kind: asset.mediaType,
      assetId: asset.id,
      timelineRange: { start: ticks(start), duration: ticks(duration) },
      ...(asset.mediaType === "video" ? { sourceRange: { start: ticks(0), duration: ticks(duration) } } : {}),
      properties: {
        "broll.query": segment.text,
        "broll.transcriptSegmentId": segment.id,
        "transform.opacity": 1,
        "transform.scale": 1,
      },
      keyframes: [],
    },
  });
  return {
    label: `Add ${asset.name} as B-roll for “${segment.text}”`,
    operations,
    findings: [],
    metrics: { findingCount: 0, removedDurationTicks: 0 },
  };
};
