import assert from "node:assert/strict";
import test from "node:test";
import { CREDITS_PER_USD, creditsToUsd, usdToCredits } from "./index.js";

test("credits are a one-decimal view of USD at 1 credit = $0.01", () => {
  assert.equal(CREDITS_PER_USD, 100);
  assert.equal(usdToCredits(0.04), 4);
  assert.equal(usdToCredits(0.003), 0.3);
  assert.equal(usdToCredits(0.15), 15);
  // A sub-cent charge still bills a tenth of a credit rather than rounding to zero.
  assert.equal(usdToCredits(0.001), 0.1);
  assert.equal(usdToCredits(0), 0);
  assert.equal(usdToCredits(Number.NaN), 0);
  assert.equal(usdToCredits(-1), 0);
});

test("creditsToUsd is the inverse for representable amounts", () => {
  for (const usd of [0.003, 0.01, 0.04, 0.15, 2]) {
    assert.equal(creditsToUsd(usdToCredits(usd)), usd);
  }
  assert.equal(creditsToUsd(0), 0);
  assert.equal(creditsToUsd(Number.NaN), 0);
});
