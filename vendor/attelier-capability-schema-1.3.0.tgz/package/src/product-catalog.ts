/** Versioned product vocabulary shared by Studio, the API and external agents. */

import { EFFECT_CATALOG, effectRef, type EffectRef } from "@attelier/capability-schema/effect-catalog";
import { AUDIO_DELIVERY_PROFILES, ATTELIER_AUDIO_DELIVERY_PROFILE_VERSION } from "@attelier/capability-schema/delivery-profiles";
import { ATTELIER_COLOR_ASSIST_VERSION } from "@attelier/capability-schema/color-assist";
import { ATTELIER_MOTION_ANALYSIS_VERSION } from "@attelier/capability-schema/motion-analysis";
import { ATTELIER_MOTION_TREATMENT_PREFLIGHT_VERSION } from "@attelier/capability-schema/motion-treatment";
import { ATTELIER_SUBJECT_REFRAME_VERSION } from "@attelier/capability-schema/subject-reframe";

// Minor bump: social repurposing, restoration and bounded generative VFX now
// expose durable, recoverable workflow contracts to terminal and Studio clients.
export const ATTELIER_CATALOG_VERSION = "1.31.0";

export type UseCaseId =
  | "talking-head" | "long-to-shorts" | "product-ad" | "localization"
  | "create-from-brief" | "social-repurposing" | "pure-editing"
  | "restoration" | "generative-vfx" | "authorized-avatar";

export type CapabilityId =
  | "transcription" | "transcript-editing" | "translation" | "text-to-image" | "image-to-image" | "product-shot" | "text-to-video"
  | "image-to-video" | "voice-generation" | "music-generation"
  | "sound-effect-generation" | "lip-sync" | "background-removal"
  | "upscale" | "region-inpaint" | "subject-reframe" | "color-match" | "color-analysis" | "motion-analysis";

export type ToolId =
  | "discover" | "get-project" | "prompt" | "simulate-change-set" | "apply-change-set"
  | "compile-edit" | "editing-recipes"
  | "run-operations" | "preview-frame" | "review-cut" | "evaluate-project" | "evaluate-effect-contract" | "evaluate-effect-parity" | "propose-quality-fix" | "color-assist" | "motion-treatment" | "subject-reframe" | "run-capability" | "get-job" | "cancel-job"
  | "run-workflow" | "get-workflow-run" | "control-workflow"
  | "render" | "get-render" | "cancel-render" | "evaluate-render"
  | "list-consents" | "project-history" | "project-plan" | "project-resources" | "execution-traces" | "agent-sessions" | "workspace-library" | "creative-direction" | "media-analysis" | "transcript-editing";

export type CatalogStatus = "usable" | "beta" | "planned";

export type DiscoveryUseCase = {
  id: UseCaseId;
  examplePrompt?: string;
};

export type DiscoveryEntry = {
  id: string;
  label: string;
  examplePrompt?: string;
  capabilityId?: CapabilityId;
  effect?: EffectRef;
};

export type DiscoveryGroup = {
  id: string;
  title: string;
  entries: DiscoveryEntry[];
};

export type UseCaseDefinition = {
  id: UseCaseId;
  name: string;
  promise: string;
  requiredInputs: string[];
  workflow: string[];
  capabilities: CapabilityId[];
  benchmarkId: string;
  benchmarkExecution: "automated" | "contract" | "planned";
  status: CatalogStatus;
};

export type CapabilityDefinition = {
  id: CapabilityId;
  name: string;
  kind: "analysis" | "generation" | "transformation";
  deterministic: boolean;
  providerGated: boolean;
  /** Capability API identifier. Omitted when the feature is expressed as project operations/workflows. */
  apiCapability?: string;
  benchmarkId: string;
  status: CatalogStatus;
};

export type ToolDefinition = {
  id: ToolId;
  name: string;
  mutatesProject: boolean;
  async: boolean;
  approval: "none" | "change-set" | "cost-or-policy";
  status: CatalogStatus;
  /** Discoverable API entrypoint. Braced segments are caller-supplied path parameters. */
  http?: { method: "GET" | "POST"; path: string };
  /** Bounded MCP primitives that implement this product-level action. */
  mcp?: readonly string[];
  /** Complete durable execution protocol exposed to external agents. */
  agentContract?: {
    scope: "mcp:spend";
    quote: { http: { method: "POST"; path: string }; mcp: string };
    approve: { http: { method: "POST"; path: string }; mcp?: string; when: "budget-policy" };
    start: { http: { method: "POST"; path: string }; mcp: string; idempotencyKey: "required" };
    status: { http: { method: "GET"; path: string }; mcp: string };
    cancel: { http: { method: "POST"; path: string }; mcp: string };
  };
};

export const CAPABILITY_CATALOG: CapabilityDefinition[] = [
  { id: "transcription", name: "Transcription", kind: "analysis", deterministic: false, providerGated: false, benchmarkId: "capability.transcription.v1", status: "usable" },
  { id: "transcript-editing", name: "Transcript-based editing", kind: "transformation", deterministic: true, providerGated: false, benchmarkId: "capability.transcript-editing.v1", status: "usable" },
  { id: "translation", name: "Translation", kind: "analysis", deterministic: false, providerGated: true, apiCapability: "translation", benchmarkId: "capability.translation.v1", status: "beta" },
  { id: "text-to-image", name: "Text to image", kind: "generation", deterministic: false, providerGated: true, apiCapability: "text_to_image", benchmarkId: "capability.text-to-image.v1", status: "usable" },
  { id: "image-to-image", name: "Reference-guided image generation", kind: "transformation", deterministic: false, providerGated: true, apiCapability: "image_to_image", benchmarkId: "capability.image-to-image.v1", status: "beta" },
  { id: "product-shot", name: "Product-preserving lifestyle shot", kind: "transformation", deterministic: false, providerGated: true, apiCapability: "product_shot", benchmarkId: "capability.product-shot.v1", status: "beta" },
  { id: "text-to-video", name: "Text to video", kind: "generation", deterministic: false, providerGated: true, apiCapability: "text_to_video", benchmarkId: "capability.text-to-video.v1", status: "usable" },
  { id: "image-to-video", name: "Image to video", kind: "generation", deterministic: false, providerGated: true, apiCapability: "image_to_video", benchmarkId: "capability.image-to-video.v1", status: "usable" },
  { id: "voice-generation", name: "Voice generation", kind: "generation", deterministic: false, providerGated: true, apiCapability: "voice_generation", benchmarkId: "capability.voice.v1", status: "usable" },
  { id: "music-generation", name: "Music generation", kind: "generation", deterministic: false, providerGated: true, apiCapability: "music_generation", benchmarkId: "capability.music.v1", status: "usable" },
  { id: "sound-effect-generation", name: "Sound-effect generation", kind: "generation", deterministic: false, providerGated: true, apiCapability: "sound_effect_generation", benchmarkId: "capability.sfx.v1", status: "usable" },
  { id: "lip-sync", name: "Lip sync", kind: "transformation", deterministic: false, providerGated: true, apiCapability: "lip_sync", benchmarkId: "capability.lip-sync.v1", status: "beta" },
  { id: "background-removal", name: "Background removal", kind: "transformation", deterministic: false, providerGated: true, apiCapability: "background_removal", benchmarkId: "capability.background-removal.v1", status: "usable" },
  { id: "upscale", name: "Upscale", kind: "transformation", deterministic: false, providerGated: true, apiCapability: "upscale", benchmarkId: "capability.upscale.v1", status: "usable" },
  { id: "region-inpaint", name: "Region inpaint", kind: "transformation", deterministic: false, providerGated: true, apiCapability: "region_inpaint", benchmarkId: "capability.inpaint.v1", status: "beta" },
  { id: "subject-reframe", name: "Subject-aware reframe", kind: "transformation", deterministic: false, providerGated: false, benchmarkId: "capability.subject-reframe.v1", status: "beta" },
  { id: "color-match", name: "Per-clip color match", kind: "transformation", deterministic: true, providerGated: false, benchmarkId: "capability.color-match.v1", status: "usable" },
  { id: "color-analysis", name: "Color scopes and exposure/white-balance analysis", kind: "analysis", deterministic: true, providerGated: false, benchmarkId: "capability.color-analysis.v1", status: "usable" },
  { id: "motion-analysis", name: "Bounded camera-motion analysis", kind: "analysis", deterministic: true, providerGated: false, benchmarkId: "capability.motion-analysis.v1", status: "usable" },
];

export const USE_CASE_CATALOG: UseCaseDefinition[] = [
  { id: "talking-head", name: "Improve a talking-head video", promise: "Turn a raw recording into a clean, paced and publishable edit.", requiredInputs: ["source video", "delivery target"], workflow: ["inspect", "transcribe", "clean transcript", "reframe", "captions", "audio mix", "quality review", "render"], capabilities: ["transcription", "transcript-editing", "subject-reframe", "motion-analysis"], benchmarkId: "workflow.talking-head.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "long-to-shorts", name: "Turn long video into shorts", promise: "Find strong moments and produce editable platform-ready clips.", requiredInputs: ["source video", "target platform", "target count"], workflow: ["inspect", "transcribe", "rank highlights", "create branches", "reframe", "captions", "quality review", "render variants"], capabilities: ["transcription", "subject-reframe"], benchmarkId: "workflow.long-to-shorts.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "product-ad", name: "Create a product advertisement", promise: "Create an editable, branded ad from a brief and product assets.", requiredInputs: ["product", "audience", "platform", "approved claims"], workflow: ["brief", "concepts", "script", "storyboard", "quote", "generate takes", "edit", "audio", "brand", "quality review", "variants", "render"], capabilities: ["product-shot", "image-to-image", "text-to-image", "text-to-video", "image-to-video", "voice-generation", "music-generation", "sound-effect-generation", "background-removal", "color-analysis", "color-match"], benchmarkId: "workflow.product-ad.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "localization", name: "Localize and dub a video", promise: "Translate speech and captions while preserving timing and editability.", requiredInputs: ["source video", "target languages"], workflow: ["transcribe", "translate", "review glossary", "generate voices", "lip sync", "retime captions", "quality review", "render packages"], capabilities: ["transcription", "translation", "voice-generation", "lip-sync"], benchmarkId: "workflow.localization.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "create-from-brief", name: "Create a complete video from a brief", promise: "Turn an objective, audience and constraints into an editable audiovisual project.", requiredInputs: ["objective", "audience", "delivery target", "constraints"], workflow: ["brief", "concepts", "script", "storyboard", "quote", "generate takes", "edit", "audio", "quality review", "render variants"], capabilities: ["text-to-image", "text-to-video", "image-to-video", "voice-generation", "music-generation", "sound-effect-generation", "color-analysis", "color-match"], benchmarkId: "workflow.create-from-brief.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "social-repurposing", name: "Repurpose a video for social channels", promise: "Create editable, platform-aware aspect-ratio and duration variants from one master.", requiredInputs: ["master video", "target platforms"], workflow: ["inspect", "rank highlights", "create branches", "reframe", "captions", "brand", "quality review", "render variants"], capabilities: ["transcription", "subject-reframe"], benchmarkId: "workflow.social-repurposing.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "pure-editing", name: "Edit supplied media", promise: "Perform precise timeline, composition, text, audio and color work without generative media.", requiredInputs: ["source media", "edit instructions"], workflow: ["inspect", "edit", "audio", "brand", "quality review", "render"], capabilities: ["transcription", "transcript-editing", "color-analysis", "motion-analysis", "color-match"], benchmarkId: "workflow.pure-editing.v1", benchmarkExecution: "automated", status: "usable" },
  { id: "restoration", name: "Clean up and restore footage", promise: "Improve damaged, noisy or low-resolution material while keeping the result editable.", requiredInputs: ["source media", "restoration target", "explicit treatments"], workflow: ["inspect", "approve conservative plan", "local cleanup", "optional quoted image upscale", "editable comparison branches", "quality review", "render"], capabilities: ["upscale", "motion-analysis", "color-match"], benchmarkId: "workflow.restoration.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "generative-vfx", name: "Create generative VFX and replacements", promise: "Create editable regional replacements, cutouts, stylized shots and image-to-video inserts while retaining the source layer.", requiredInputs: ["source image", "bounded operation", "effect description", "protected content", "generation justification", "confirmed rights", "mask for regional work"], workflow: ["inspect", "approve shot contract", "quote", "generate one take", "composite as a separate layer", "quality review", "render"], capabilities: ["image-to-image", "image-to-video", "background-removal", "region-inpaint"], benchmarkId: "workflow.generative-vfx.v1", benchmarkExecution: "contract", status: "beta" },
  { id: "authorized-avatar", name: "Create an authorized avatar or identity edit", promise: "Create a consent-gated, traceable and editable avatar, face or voice performance.", requiredInputs: ["verified consent", "approved identity assets", "script", "purpose"], workflow: ["verify consent", "script", "generate voices", "lip sync", "identity review", "quality review", "render", "provenance"], capabilities: ["voice-generation", "lip-sync", "translation"], benchmarkId: "workflow.authorized-avatar.v1", benchmarkExecution: "planned", status: "planned" },
];

export const TOOL_CATALOG: ToolDefinition[] = [
  { id: "discover", name: "Discover Attelier's product and agent surface", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/catalog" }, mcp: ["discover_atelier", "get_craft_guide", "list_effects", "list_agent_skills", "get_agent_skill", "get_evaluation_spec"] },
  { id: "get-project", name: "Inspect the canonical project", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/projects/{projectId}/snapshot" }, mcp: ["list_projects", "inspect_project"] },
  { id: "project-plan", name: "Read and update the versioned idea, script and video beats", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/projects/{projectId}/plan" }, mcp: ["get_project_plan", "update_project_plan"] },
  { id: "project-resources", name: "Read and update the canonical Brand Kit and reusable project elements", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/projects/{projectId}/elements" }, mcp: ["get_brand_kit", "list_project_elements", "upsert_project_element"] },
  { id: "creative-direction", name: "Analyze URL references, inspect blueprints and request durable creator decisions", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/reference-analysis" }, mcp: ["analyze_reference_url", "request_creative_decision"] },
  { id: "media-analysis", name: "Search and inspect server-side media analysis", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "POST", path: "/v1/analysis-jobs" }, mcp: ["start_analysis_job", "get_analysis_job", "describe_asset", "get_asset_description", "get_transcript", "search_transcript", "get_audio_analysis", "get_music_identification", "get_video_reconstruction", "search_project_media"] },
  { id: "transcript-editing", name: "Search and simulate transcript-based edits", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "POST", path: "/v1/agent/plans" }, mcp: ["propose_transcript_edit"] },
  { id: "workspace-library", name: "Search, upload and import user Library media and rights-filtered free music", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "GET", path: "/v1/workspace-assets" }, mcp: ["search_workspace_assets", "search_music_library", "acquire_free_music_track", "get_workspace_asset", "prepare_workspace_asset_import", "prepare_project_asset_placement", "create_upload", "upload_chunk", "complete_upload", "create_workspace_asset_from_upload"] },
  { id: "project-history", name: "Name, compare and safely restore project revisions", mutatesProject: true, async: false, approval: "change-set", status: "usable", http: { method: "GET", path: "/v1/projects/{projectId}/versions" }, mcp: ["list_project_versions", "compare_project_versions", "create_project_version", "restore_project_version"] },
  { id: "list-consents", name: "Inspect identity consent status", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/workspaces/{workspaceId}/consents" } },
  { id: "execution-traces", name: "Trace prompts, edits, jobs, renders, cost and provenance", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/execution-traces" }, mcp: ["create_execution_trace", "list_execution_traces", "get_execution_trace"] },
  { id: "agent-sessions", name: "Create, fork, resume and project durable harness sessions", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/sessions/{sessionId}" }, mcp: ["create_session", "fork_session", "list_sessions", "get_session", "get_session_events", "append_session_event"] },
  { id: "prompt", name: "Route or plan a natural-language request", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "POST", path: "/v1/agent/plans" }, mcp: ["route_creative_prompt", "plan_edit"] },
  { id: "simulate-change-set", name: "Validate and preview operations", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/transactions/simulate" }, mcp: ["simulate_transaction", "compose_social_ad", "set_sequence_frame_rate"] },
  { id: "compile-edit", name: "Compile any deterministic editor tool call into a revision-pinned transaction", mutatesProject: false, async: true, approval: "change-set", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/transactions/simulate" }, mcp: ["compile_edit"] },
  { id: "editing-recipes", name: "Run a documented editing discipline as one prepared transaction", mutatesProject: false, async: true, approval: "change-set", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/transactions/simulate" }, mcp: ["add_lower_third", "clear_timeline", "reorder_clips", "trim_to_speech", "snap_cut_to_words", "level_dialogue", "set_project_profile"] },
  { id: "apply-change-set", name: "Commit an approved change set", mutatesProject: true, async: true, approval: "change-set", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/transactions" }, mcp: ["commit_transaction"] },
  { id: "run-operations", name: "Commit expert project operations", mutatesProject: true, async: true, approval: "change-set", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/transactions" } },
  { id: "preview-frame", name: "See one exact frame or a fast range preview from the real export pipeline", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/frame" }, mcp: ["render_frame", "render_range"] },
  { id: "review-cut", name: "Review the cut deterministically, or pay the vision model to look at rendered frames", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/frame" }, mcp: ["review_cut", "review_frames"] },
  { id: "evaluate-project", name: "Evaluate deterministic project quality", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "GET", path: "/v1/projects/{projectId}/quality" }, mcp: ["evaluate_project"] },
  { id: "evaluate-effect-contract", name: "Evaluate objective effect postconditions", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "POST", path: "/v1/effect-evaluations" } },
  { id: "evaluate-effect-parity", name: "Evaluate preview and render against one pinned effect intent", mutatesProject: false, async: false, approval: "none", status: "usable", http: { method: "POST", path: "/v1/effect-parity-evaluations" }, mcp: ["evaluate_effect_parity"] },
  { id: "propose-quality-fix", name: "Compile and simulate a deterministic quality fix", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/quality-fixes/simulate" }, mcp: ["propose_quality_fix"] },
  { id: "color-assist", name: "Measure color scopes and simulate an exposure/white-balance correction", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/color-assist" }, mcp: ["propose_color_correction"] },
  { id: "motion-treatment", name: "Preflight and simulate bounded stabilization or temporal motion blur", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "POST", path: "/v1/projects/{projectId}/motion-treatment" }, mcp: ["propose_motion_treatment"] },
  { id: "subject-reframe", name: "Measure subject tracking and simulate editable reframe keyframes", mutatesProject: false, async: true, approval: "none", status: "beta", http: { method: "POST", path: "/v1/projects/{projectId}/subject-reframe" }, mcp: ["propose_subject_reframe"] },
  { id: "run-capability", name: "Quote and execute a provider-routed capability", mutatesProject: false, async: true, approval: "cost-or-policy", status: "usable", http: { method: "POST", path: "/v1/capabilities/{apiCapability}/quote" }, mcp: ["quote_capability", "get_capability_quote", "approve_capability_quote", "reserve_capability_quote", "start_capability_job"], agentContract: { scope: "mcp:spend", quote: { http: { method: "POST", path: "/v1/capabilities/{apiCapability}/quote" }, mcp: "quote_capability" }, approve: { http: { method: "POST", path: "/v1/capability-quotes/{quoteId}/approve" }, mcp: "approve_capability_quote", when: "budget-policy" }, start: { http: { method: "POST", path: "/v1/capabilities/{apiCapability}/jobs" }, mcp: "start_capability_job", idempotencyKey: "required" }, status: { http: { method: "GET", path: "/v1/capability-jobs/{jobId}" }, mcp: "get_capability_job" }, cancel: { http: { method: "POST", path: "/v1/capability-jobs/{jobId}/cancel" }, mcp: "cancel_capability_job" } } },
  { id: "get-job", name: "Inspect durable capability job state", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "GET", path: "/v1/capability-jobs/{jobId}" }, mcp: ["get_capability_job"] },
  { id: "cancel-job", name: "Cancel a durable capability job", mutatesProject: false, async: true, approval: "cost-or-policy", status: "usable", http: { method: "POST", path: "/v1/capability-jobs/{jobId}/cancel" }, mcp: ["cancel_capability_job"] },
  { id: "run-workflow", name: "Quote and start a durable use-case workflow", mutatesProject: true, async: true, approval: "cost-or-policy", status: "usable", http: { method: "POST", path: "/v1/workflow-quotes" }, mcp: ["quote_workflow", "approve_workflow_quote", "start_workflow_run"], agentContract: { scope: "mcp:spend", quote: { http: { method: "POST", path: "/v1/workflow-quotes" }, mcp: "quote_workflow" }, approve: { http: { method: "POST", path: "/v1/workflow-quotes/{quoteId}/approve" }, mcp: "approve_workflow_quote", when: "budget-policy" }, start: { http: { method: "POST", path: "/v1/workflow-runs" }, mcp: "start_workflow_run", idempotencyKey: "required" }, status: { http: { method: "GET", path: "/v1/workflow-runs/{runId}" }, mcp: "get_workflow_run" }, cancel: { http: { method: "POST", path: "/v1/workflow-runs/{runId}/cancel" }, mcp: "cancel_workflow_run" } } },
  { id: "get-workflow-run", name: "List or inspect durable workflow runs", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "GET", path: "/v1/workflow-runs/{runId}" }, mcp: ["list_workflow_runs", "get_workflow_run"] },
  { id: "control-workflow", name: "Approve, resume or cancel a workflow run", mutatesProject: true, async: true, approval: "cost-or-policy", status: "usable", http: { method: "POST", path: "/v1/workflow-runs/{runId}/approve" }, mcp: ["approve_workflow_run", "resume_workflow_run", "cancel_workflow_run"] },
  { id: "render", name: "Render a pinned project revision", mutatesProject: false, async: true, approval: "cost-or-policy", status: "usable", http: { method: "POST", path: "/v1/render-quotes" }, mcp: ["quote_render", "approve_render_quote", "start_render_job"], agentContract: { scope: "mcp:spend", quote: { http: { method: "POST", path: "/v1/render-quotes" }, mcp: "quote_render" }, approve: { http: { method: "POST", path: "/v1/render-quotes/{quoteId}/approve" }, mcp: "approve_render_quote", when: "budget-policy" }, start: { http: { method: "POST", path: "/v1/render-jobs" }, mcp: "start_render_job", idempotencyKey: "required" }, status: { http: { method: "GET", path: "/v1/render-jobs/{jobId}" }, mcp: "get_render_job" }, cancel: { http: { method: "POST", path: "/v1/render-jobs/{jobId}/cancel" }, mcp: "cancel_render_job" } } },
  { id: "get-render", name: "Inspect a durable render job", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "GET", path: "/v1/render-jobs/{jobId}" }, mcp: ["get_render_job"] },
  { id: "cancel-render", name: "Cancel a queued or running render", mutatesProject: false, async: true, approval: "cost-or-policy", status: "usable", http: { method: "POST", path: "/v1/render-jobs/{jobId}/cancel" }, mcp: ["cancel_render_job"] },
  { id: "evaluate-render", name: "Inspect pinned project quality and technical post-render QC", mutatesProject: false, async: true, approval: "none", status: "usable", http: { method: "GET", path: "/v1/render-jobs/{jobId}/evaluation" }, mcp: ["evaluate_render"] },
];

/**
 * Presentation metadata shared by Studio, HTTP discovery and generated docs.
 * Maturity always comes from the underlying use-case/capability catalog; this
 * layer only owns grouping, labels and example prompts.
 */
export const ATTELIER_DISCOVERY_CATALOG: {
  useCases: DiscoveryUseCase[];
  deterministicGroups: DiscoveryGroup[];
  aiGroups: DiscoveryGroup[];
} = {
  useCases: [
    { id: "product-ad", examplePrompt: "create a 15-second ad for a running shoe for Instagram" },
    { id: "create-from-brief", examplePrompt: "create a 20-second video introducing my coffee shop, friendly tone" },
    { id: "long-to-shorts", examplePrompt: "turn this video into a vertical short with subtitles" },
    { id: "talking-head", examplePrompt: "remove the silences and filler words and add subtitles" },
    { id: "localization", examplePrompt: "dub the video into English" },
    { id: "pure-editing", examplePrompt: "trim the clip to 5s" },
    { id: "social-repurposing" },
    { id: "restoration" },
    { id: "generative-vfx" },
    { id: "authorized-avatar" },
  ],
  deterministicGroups: [
    {
      id: "cutting-timeline",
      title: "Cutting & timeline",
      entries: [
        { id: "trim", label: "Trim", examplePrompt: "trim the clip to 5s" },
        { id: "split", label: "Split", examplePrompt: "cut the video at 3s" },
        { id: "move", label: "Move in time", examplePrompt: "move the music to 2s" },
        { id: "speed", label: "Speed", examplePrompt: "2x speed on the video", effect: effectRef("atelier.retime.speed") },
        { id: "delete", label: "Duplicate / delete", examplePrompt: "delete the selected clip" },
        { id: "transcript-editing", label: "Edit by transcript", examplePrompt: "remove filler words and shorten long silences", capabilityId: "transcript-editing" },
      ],
    },
    {
      id: "composition-text",
      title: "Composition & text",
      entries: [
        { id: "scale", label: "Scale / zoom", examplePrompt: "zoom 1.5 on the clip" },
        { id: "opacity", label: "Opacity", examplePrompt: "60% opacity on the title" },
        { id: "rotate", label: "Rotate", examplePrompt: "rotate the clip 90 degrees" },
        { id: "typography", label: "Titles & typography", examplePrompt: "add a title that says “My Brand”", effect: effectRef("atelier.text.readable-overlay") },
        { id: "aspect-ratio", label: "Format / aspect ratio", examplePrompt: "make it vertical 9:16" },
        { id: "reframe", label: "Reframe", examplePrompt: "reframe to vertical" },
        { id: "blur-face", label: "Blur a tracked region", examplePrompt: "blur the face and track it", effect: effectRef("atelier.region.blur") },
        { id: "color-match", label: "Match clip color", examplePrompt: "match the selected clip color to the previous clip", capabilityId: "color-match", effect: effectRef("atelier.color.match-and-look") },
        { id: "color-scopes", label: "Analyze exposure and white balance", examplePrompt: "analyze the selected clip color and propose a correction", capabilityId: "color-analysis" },
      ],
    },
    {
      id: "transitions-motion",
      title: "Transitions & motion",
      entries: [
        { id: "fade", label: "Fade in / out", examplePrompt: "make it appear with a fade" },
        { id: "cross-dissolve", label: "Crossfade", examplePrompt: "add a crossfade between the clips", effect: effectRef("atelier.transition.cross-dissolve") },
        { id: "dip-to-black", label: "Dip to black", examplePrompt: "add a dip-to-black transition between the clips", effect: effectRef("atelier.transition.dip-to-black") },
        { id: "dip-to-white", label: "Dip to white", examplePrompt: "add a dip-to-white transition between the clips", effect: effectRef("atelier.transition.dip-to-white") },
        { id: "ken-burns", label: "Ken Burns", examplePrompt: "give the clip a ken burns effect", effect: effectRef("atelier.motion.ken-burns") },
        { id: "stabilization", label: "Analyze and stabilize camera motion", examplePrompt: "stabilize the selected video", capabilityId: "motion-analysis", effect: effectRef("atelier.motion.stabilization") },
        { id: "motion-blur", label: "Motion blur", examplePrompt: "add subtle motion blur to the selected video", effect: effectRef("atelier.motion.motion-blur") },
        { id: "slow-zoom", label: "Slow zoom", examplePrompt: "do a slow zoom on the image" },
        { id: "zoom-punch", label: "Zoom punch", examplePrompt: "zoom punch at the start" },
        { id: "camera-shake", label: "Camera shake", examplePrompt: "make the camera shake" },
        { id: "slide-in", label: "Slide in", examplePrompt: "slide it in from the left" },
        { id: "spin", label: "Spin", examplePrompt: "make it spin continuously" },
      ],
    },
    {
      id: "audio-output",
      title: "Audio & output",
      entries: [
        { id: "mute", label: "Mute", examplePrompt: "mute the music" },
        { id: "volume", label: "Volume", examplePrompt: "-6dB volume on the voice" },
        { id: "audio-fades", label: "Audio fades", examplePrompt: "2s fade out on the music" },
        { id: "professional-mix", label: "Professional mix", examplePrompt: "clean the dialogue, duck the music and master the mix", effect: effectRef("atelier.audio.professional-mix") },
        { id: "export-mp4", label: "Export MP4" },
      ],
    },
  ],
  aiGroups: [
    {
      id: "generate",
      title: "Generate",
      entries: [
        { id: "text-to-image", label: "Image", examplePrompt: "generate an image of a sunset on the beach", capabilityId: "text-to-image" },
        { id: "image-to-image", label: "Reference-guided image", examplePrompt: "create a new image that preserves this reference", capabilityId: "image-to-image" },
        { id: "product-shot", label: "Product lifestyle shot", examplePrompt: "place this exact product in a premium studio scene", capabilityId: "product-shot" },
        { id: "text-to-video", label: "Video from text", examplePrompt: "generate a clip of waves crashing", capabilityId: "text-to-video" },
        { id: "image-to-video", label: "Image → video", examplePrompt: "animate this image with a subtle camera move", capabilityId: "image-to-video", effect: effectRef("atelier.generate.image-to-video") },
        { id: "voice-generation", label: "Voiceover", examplePrompt: "add a voiceover that says “Welcome”", capabilityId: "voice-generation" },
        { id: "music-generation", label: "Music", examplePrompt: "add epic cinematic music", capabilityId: "music-generation" },
        { id: "sound-effect-generation", label: "Sound effects", examplePrompt: "add a sound of a car starting", capabilityId: "sound-effect-generation" },
      ],
    },
    {
      id: "understand-enhance",
      title: "Understand & enhance",
      entries: [
        { id: "transcription", label: "Transcribe / synced subtitles", examplePrompt: "transcribe the voiceover and add subtitles", capabilityId: "transcription" },
        { id: "translation", label: "Translate / dub", examplePrompt: "dub the video into English", capabilityId: "translation" },
        { id: "lip-sync", label: "Lip-sync", examplePrompt: "sync the lips to the voice", capabilityId: "lip-sync", effect: effectRef("atelier.identity.lip-sync") },
        { id: "upscale", label: "Enhance quality / upscale", examplePrompt: "improve the image quality", capabilityId: "upscale" },
        { id: "background-removal", label: "Remove background", examplePrompt: "remove the image background", capabilityId: "background-removal", effect: effectRef("atelier.composite.subject-cutout") },
        { id: "region-inpaint", label: "Retouch a region", examplePrompt: "edit this region: make the sky blue", capabilityId: "region-inpaint", effect: effectRef("atelier.region.inpaint") },
        { id: "subject-reframe", label: "Subject-tracked reframe", examplePrompt: "track the person and reframe the selected video to vertical", capabilityId: "subject-reframe" },
      ],
    },
  ],
};

export const validateCatalog = (): string[] => {
  const issues: string[] = [];
  const capabilityIds = new Set(CAPABILITY_CATALOG.map(({ id }) => id));
  const unique = (values: string[], label: string) => {
    if (new Set(values).size !== values.length) issues.push(`${label} contains duplicate ids.`);
  };
  unique(CAPABILITY_CATALOG.map(({ id }) => id), "capability catalog");
  unique(USE_CASE_CATALOG.map(({ id }) => id), "use-case catalog");
  unique(TOOL_CATALOG.map(({ id }) => id), "tool catalog");
  unique(TOOL_CATALOG.flatMap(({ mcp }) => [...(mcp ?? [])]), "catalog MCP mappings");
  for (const useCase of USE_CASE_CATALOG) {
    if (useCase.workflow.length < 2) issues.push(`${useCase.id} has no meaningful workflow.`);
    if (!useCase.benchmarkId) issues.push(`${useCase.id} has no benchmark.`);
    for (const capability of useCase.capabilities) {
      if (!capabilityIds.has(capability)) issues.push(`${useCase.id} references unknown capability ${capability}.`);
    }
  }
  for (const tool of TOOL_CATALOG) {
    if (tool.status === "usable" && !tool.http) issues.push(`${tool.id} is usable but has no API entrypoint.`);
  }
  const discoveryEntries = [...ATTELIER_DISCOVERY_CATALOG.deterministicGroups, ...ATTELIER_DISCOVERY_CATALOG.aiGroups]
    .flatMap(({ entries }) => entries);
  unique(ATTELIER_DISCOVERY_CATALOG.useCases.map(({ id }) => id), "discovery use cases");
  unique(discoveryEntries.map(({ id }) => id), "discovery entries");
  for (const { id } of USE_CASE_CATALOG) {
    if (!ATTELIER_DISCOVERY_CATALOG.useCases.some((entry) => entry.id === id)) issues.push(`${id} is missing from UI discovery.`);
  }
  for (const { id } of CAPABILITY_CATALOG) {
    if (!discoveryEntries.some((entry) => entry.capabilityId === id)) issues.push(`${id} is missing from UI discovery.`);
  }
  for (const entry of discoveryEntries) {
    if (entry.capabilityId && !capabilityIds.has(entry.capabilityId)) issues.push(`${entry.id} references unknown capability ${entry.capabilityId}.`);
  }
  for (const { effectId } of EFFECT_CATALOG) {
    if (!discoveryEntries.some((entry) => entry.effect?.id === effectId)) issues.push(`${effectId} is missing from UI discovery.`);
  }
  return issues;
};

export const ATTELIER_PRODUCT_CATALOG = {
  schemaVersion: 1 as const,
  catalogVersion: ATTELIER_CATALOG_VERSION,
  taxonomy: { outcome: "useCase", recipe: "workflow", primitive: "capability", action: "tool", implementation: "provider" },
  useCases: USE_CASE_CATALOG,
  capabilities: CAPABILITY_CATALOG,
  tools: TOOL_CATALOG,
  discovery: ATTELIER_DISCOVERY_CATALOG,
  audioDelivery: {
    version: ATTELIER_AUDIO_DELIVERY_PROFILE_VERSION,
    profiles: Object.values(AUDIO_DELIVERY_PROFILES),
  },
  colorAssist: {
    version: ATTELIER_COLOR_ASSIST_VERSION,
    measurement: "bounded RGB24 representative-frame scopes",
    application: "proposal-only; simulate before commit",
  },
  motionTreatment: {
    preflightVersion: ATTELIER_MOTION_TREATMENT_PREFLIGHT_VERSION,
    analysisVersion: ATTELIER_MOTION_ANALYSIS_VERSION,
    measurement: "bounded local grayscale global-translation window plus explicit project annotations; OCR and semantic subject intent are not claimed",
    application: "proposal-only; unsafe evidence returns needs-action with no transaction",
  },
  subjectReframe: {
    version: ATTELIER_SUBJECT_REFRAME_VERSION,
    detector: "torchvision/ssdlite320_mobilenet_v3_large-coco",
    application: "proposal-only editable keyframes; fail closed below confidence and coverage gates",
  },
};
