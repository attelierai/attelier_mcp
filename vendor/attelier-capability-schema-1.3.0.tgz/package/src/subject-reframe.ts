import type { Keyframe, MediaTime, ProjectOperation } from "@attelier/project-schema";

export const ATTELIER_SUBJECT_REFRAME_VERSION = "1.0.0" as const;

export type SubjectBox = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export type SubjectDetection = {
  label: string;
  confidence: number;
  box: SubjectBox;
};

export type SubjectObservation = {
  at: MediaTime;
  detections: SubjectDetection[];
};

export type SubjectReframeTarget = "vertical" | "square" | "landscape";

export const SUBJECT_REFRAME_TARGETS: Record<SubjectReframeTarget, { width: number; height: number }> = {
  vertical: { width: 1080, height: 1920 },
  square: { width: 1080, height: 1080 },
  landscape: { width: 1920, height: 1080 },
};

export type SubjectReframeAnalysis = {
  version: typeof ATTELIER_SUBJECT_REFRAME_VERSION;
  status: "ready" | "needs-action";
  subjectLabel?: string;
  target: SubjectReframeTarget;
  canvas: { width: number; height: number };
  sampledFrames: number;
  detectedFrames: number;
  metrics: {
    detectionRatio: number;
    meanConfidence: number;
    minimumSubjectCoverage: number;
    maximumCenterJump: number;
  };
  treatment?: {
    scale: number;
    positionKeyframes: Keyframe[];
  };
  reasons: string[];
};

const clamp = (value: number, minimum: number, maximum: number): number =>
  Math.max(minimum, Math.min(maximum, value));

const rounded = (value: number, digits = 4): number => {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
};

const validBox = (box: SubjectBox): boolean =>
  [box.x, box.y, box.width, box.height].every(Number.isFinite) &&
  box.x >= 0 && box.y >= 0 && box.width > 0 && box.height > 0 &&
  box.x + box.width <= 1.001 && box.y + box.height <= 1.001;

const center = (box: SubjectBox): [number, number] =>
  [box.x + box.width / 2, box.y + box.height / 2];

const centerDistance = (left: SubjectBox, right: SubjectBox): number => {
  const [leftX, leftY] = center(left);
  const [rightX, rightY] = center(right);
  return Math.hypot(leftX - rightX, leftY - rightY);
};

const coverage = (
  box: SubjectBox,
  position: [number, number],
  drawWidth: number,
  drawHeight: number,
  canvasWidth: number,
  canvasHeight: number,
): number => {
  const left = position[0] * canvasWidth + (box.x - 0.5) * drawWidth;
  const top = position[1] * canvasHeight + (box.y - 0.5) * drawHeight;
  const right = left + box.width * drawWidth;
  const bottom = top + box.height * drawHeight;
  const visibleWidth = Math.max(0, Math.min(canvasWidth, right) - Math.max(0, left));
  const visibleHeight = Math.max(0, Math.min(canvasHeight, bottom) - Math.max(0, top));
  return clamp((visibleWidth * visibleHeight) / Math.max(1, box.width * drawWidth * box.height * drawHeight), 0, 1);
};

type TrackedObservation = { at: MediaTime; detection: SubjectDetection };

const selectTrack = (
  observations: SubjectObservation[],
  requestedLabel?: string,
): TrackedObservation[] => {
  const normalizedLabel = requestedLabel?.trim().toLowerCase();
  let previous: SubjectDetection | undefined;
  const result: TrackedObservation[] = [];
  for (const observation of observations) {
    const candidates = observation.detections
      .filter(({ confidence, box, label }) =>
        confidence >= 0.4 && validBox(box) && (!normalizedLabel || label.toLowerCase() === normalizedLabel))
      .sort((left, right) => {
        const leftContinuity = previous ? 1 - clamp(centerDistance(previous.box, left.box), 0, 1) : 0;
        const rightContinuity = previous ? 1 - clamp(centerDistance(previous.box, right.box), 0, 1) : 0;
        const leftArea = Math.sqrt(left.box.width * left.box.height);
        const rightArea = Math.sqrt(right.box.width * right.box.height);
        return (right.confidence * 0.75 + rightContinuity * 0.2 + rightArea * 0.05) -
          (left.confidence * 0.75 + leftContinuity * 0.2 + leftArea * 0.05);
      });
    const selected = candidates[0];
    if (!selected) continue;
    // A large discontinuity usually means the detector switched to another
    // person/object. Fail closed by leaving the frame unmatched.
    if (previous && centerDistance(previous.box, selected.box) > 0.42) continue;
    result.push({ at: observation.at, detection: selected });
    previous = selected;
  }
  return result;
};

export const analyzeSubjectReframe = (input: {
  source: { width: number; height: number };
  target: SubjectReframeTarget;
  observations: SubjectObservation[];
  requestedLabel?: string;
}): SubjectReframeAnalysis => {
  const canvas = SUBJECT_REFRAME_TARGETS[input.target];
  if (!Number.isFinite(input.source.width) || !Number.isFinite(input.source.height) || input.source.width < 2 || input.source.height < 2) {
    throw new Error("Subject reframe requires valid source dimensions.");
  }
  if (input.observations.length < 3 || input.observations.length > 12) {
    throw new Error("Subject reframe requires between three and twelve sampled frames.");
  }
  const observations = [...input.observations].sort((left, right) => Number(left.at) - Number(right.at));
  const requestedLabel = input.requestedLabel?.trim().toLowerCase();
  const inferredPerson = !requestedLabel && observations.some(({ detections }) =>
    detections.some(({ label, confidence }) => label.toLowerCase() === "person" && confidence >= 0.4));
  const track = selectTrack(observations, requestedLabel ?? (inferredPerson ? "person" : undefined));
  const detectedFrames = track.length;
  const detectionRatio = detectedFrames / observations.length;
  const meanConfidence = detectedFrames
    ? track.reduce((total, item) => total + item.detection.confidence, 0) / detectedFrames
    : 0;
  const reasons: string[] = [];
  if (detectedFrames < 3 || detectionRatio < 0.7) {
    reasons.push(`A consistent subject was detected in only ${detectedFrames}/${observations.length} sampled frames.`);
  }
  if (meanConfidence < 0.55) reasons.push(`Mean detector confidence ${rounded(meanConfidence)} is below 0.55.`);
  if (reasons.length > 0) {
    return {
      version: ATTELIER_SUBJECT_REFRAME_VERSION,
      status: "needs-action",
      target: input.target,
      canvas,
      sampledFrames: observations.length,
      detectedFrames,
      metrics: { detectionRatio: rounded(detectionRatio), meanConfidence: rounded(meanConfidence), minimumSubjectCoverage: 0, maximumCenterJump: 0 },
      reasons: [...reasons, "Attelier kept the original framing; choose the subject manually or provide clearer footage."],
    };
  }

  const sourceAspect = input.source.width / input.source.height;
  const canvasAspect = canvas.width / canvas.height;
  const scale = Math.max(canvasAspect / sourceAspect, sourceAspect / canvasAspect);
  const baseFit = Math.min(canvas.width / input.source.width, canvas.height / input.source.height);
  const drawWidth = input.source.width * baseFit * scale;
  const drawHeight = input.source.height * baseFit * scale;
  const minimumX = drawWidth >= canvas.width ? 1 - drawWidth / (2 * canvas.width) : 0.5;
  const maximumX = drawWidth >= canvas.width ? drawWidth / (2 * canvas.width) : 0.5;
  const minimumY = drawHeight >= canvas.height ? 1 - drawHeight / (2 * canvas.height) : 0.5;
  const maximumY = drawHeight >= canvas.height ? drawHeight / (2 * canvas.height) : 0.5;
  const subjectLabel = track[0]!.detection.label;
  const targetY = subjectLabel.toLowerCase() === "person" ? 0.45 : 0.5;

  const rawPositions = track.map(({ detection }) => {
    const [subjectX, subjectY] = center(detection.box);
    return [
      clamp(0.5 - (subjectX - 0.5) * drawWidth / canvas.width, minimumX, maximumX),
      clamp(targetY - (subjectY - 0.5) * drawHeight / canvas.height, minimumY, maximumY),
    ] as [number, number];
  });
  const positions = rawPositions.map((position, index) => {
    const window = rawPositions.slice(Math.max(0, index - 1), Math.min(rawPositions.length, index + 2));
    return [
      window.reduce((total, item) => total + item[0], 0) / window.length,
      window.reduce((total, item) => total + item[1], 0) / window.length,
    ] as [number, number];
  });
  const coverages = track.map(({ detection }, index) => coverage(
    detection.box,
    positions[index]!,
    drawWidth,
    drawHeight,
    canvas.width,
    canvas.height,
  ));
  const jumps = positions.slice(1).map((position, index) =>
    Math.hypot(position[0] - positions[index]![0], position[1] - positions[index]![1]));
  const minimumSubjectCoverage = Math.min(...coverages);
  const maximumCenterJump = Math.max(0, ...jumps);
  if (minimumSubjectCoverage < 0.88) reasons.push(`Minimum subject coverage ${rounded(minimumSubjectCoverage)} is below 0.88.`);
  if (maximumCenterJump > 0.3) reasons.push(`Tracked framing jumps ${rounded(maximumCenterJump)} of the canvas between samples.`);
  if (reasons.length > 0) {
    return {
      version: ATTELIER_SUBJECT_REFRAME_VERSION,
      status: "needs-action",
      subjectLabel,
      target: input.target,
      canvas,
      sampledFrames: observations.length,
      detectedFrames,
      metrics: { detectionRatio: rounded(detectionRatio), meanConfidence: rounded(meanConfidence), minimumSubjectCoverage: rounded(minimumSubjectCoverage), maximumCenterJump: rounded(maximumCenterJump) },
      reasons: [...reasons, "Attelier kept the original framing; adjust subject selection or framing manually."],
    };
  }

  const positionKeyframes = track.map(({ at }, index): Keyframe => ({
    id: `subject-reframe-position-${index + 1}`,
    at,
    value: positions[index]!.map((value) => rounded(value)),
    easing: "easeInOut",
  }));
  return {
    version: ATTELIER_SUBJECT_REFRAME_VERSION,
    status: "ready",
    subjectLabel,
    target: input.target,
    canvas,
    sampledFrames: observations.length,
    detectedFrames,
    metrics: { detectionRatio: rounded(detectionRatio), meanConfidence: rounded(meanConfidence), minimumSubjectCoverage: rounded(minimumSubjectCoverage), maximumCenterJump: rounded(maximumCenterJump) },
    treatment: { scale: rounded(scale), positionKeyframes },
    reasons: [
      `Tracked ${subjectLabel} in ${detectedFrames}/${observations.length} samples.`,
      `Minimum measured subject coverage is ${rounded(minimumSubjectCoverage)}.`,
    ],
  };
};

export const buildSubjectReframeOperations = (input: {
  sequenceId: string;
  elementId: string;
  analysis: SubjectReframeAnalysis;
}): ProjectOperation[] => {
  if (input.analysis.status !== "ready" || !input.analysis.treatment) return [];
  return [
    { type: "setSequenceCanvas", sequenceId: input.sequenceId, canvas: input.analysis.canvas },
    { type: "setProperty", elementId: input.elementId, path: "capability.subjectReframe.id", value: "subject-reframe" },
    { type: "setProperty", elementId: input.elementId, path: "capability.subjectReframe.version", value: ATTELIER_SUBJECT_REFRAME_VERSION },
    { type: "setProperty", elementId: input.elementId, path: "capability.subjectReframe.subjectLabel", value: input.analysis.subjectLabel ?? "subject" },
    { type: "setProperty", elementId: input.elementId, path: "capability.subjectReframe.confidence", value: input.analysis.metrics.meanConfidence },
    { type: "setProperty", elementId: input.elementId, path: "capability.subjectReframe.minimumCoverage", value: input.analysis.metrics.minimumSubjectCoverage },
    { type: "setProperty", elementId: input.elementId, path: "transform.scale", value: input.analysis.treatment.scale },
    ...input.analysis.treatment.positionKeyframes.map((keyframe): ProjectOperation => ({
      type: "addKeyframe",
      elementId: input.elementId,
      path: "transform.position",
      keyframe,
    })),
  ];
};
