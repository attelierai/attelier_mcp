import assert from "node:assert/strict";
import test from "node:test";
import { secondsToTicks, type Project, type TimelineElement } from "@attelier/project-schema";
import {
  compileEditorialEdit,
  EditorialEditError,
  inspectSourceHandles,
} from "./editorial-editing.js";

const clip = (
  id: string,
  timelineStart: number,
  sourceStart: number,
  duration = 5,
): TimelineElement => ({
  id,
  name: id.toUpperCase(),
  kind: "video",
  assetId: `asset-${id}`,
  timelineRange: { start: secondsToTicks(timelineStart), duration: secondsToTicks(duration) },
  sourceRange: { start: secondsToTicks(sourceStart), duration: secondsToTicks(duration) },
  properties: {},
  keyframes: [],
});

const fixture = (): Project => ({
  schemaVersion: 2,
  id: "editorial-fixture",
  name: "Editorial fixture",
  revision: 0,
  activeSequenceId: "sequence",
  assets: ["a", "b", "c"].map((id) => ({
    id: `asset-${id}`,
    name: `Asset ${id}`,
    mediaType: "video" as const,
    role: "original" as const,
    duration: secondsToTicks(30),
    storage: [{ kind: "memory" as const, objectUrl: `memory://${id}` }],
  })),
  sequences: [{
    id: "sequence",
    name: "Sequence",
    canvas: { width: 1920, height: 1080 },
    frameRate: { numerator: 25, denominator: 1 },
    tracks: [{
      id: "video",
      name: "Video",
      kind: "video",
      order: 0,
      locked: false,
      muted: false,
      hidden: false,
      elements: [clip("a", 0, 5), clip("b", 5, 10), clip("c", 10, 15)],
    }],
  }],
  appliedTransactionIds: [],
});

test("slip changes only the source window in exact sequence frames", () => {
  const plan = compileEditorialEdit(fixture(), { kind: "slip", elementId: "b", offsetFrames: 5 });
  assert.equal(plan.frameTicks, 4_800);
  assert.equal(plan.operations.length, 1);
  assert.deepEqual(plan.operations[0], {
    type: "trimElement",
    elementId: "b",
    timelineRange: { start: secondsToTicks(5), duration: secondsToTicks(5) },
    sourceRange: { start: String(Number(secondsToTicks(10)) + 24_000), duration: secondsToTicks(5) },
  });
});

test("roll moves one shared cut without changing the sequence duration", () => {
  const plan = compileEditorialEdit(fixture(), {
    kind: "roll",
    outgoingElementId: "a",
    incomingElementId: "b",
    offsetFrames: 2,
  });
  assert.equal(plan.operations.length, 2);
  const [left, right] = plan.operations;
  assert.equal(left?.type, "trimElement");
  assert.equal(right?.type, "trimElement");
  if (left?.type !== "trimElement" || right?.type !== "trimElement") return;
  assert.equal(Number(left.timelineRange.duration), Number(secondsToTicks(5)) + 9_600);
  assert.equal(Number(right.timelineRange.start), Number(secondsToTicks(5)) + 9_600);
  assert.equal(Number(right.timelineRange.duration), Number(secondsToTicks(5)) - 9_600);
  assert.equal(
    Number(left.timelineRange.start) + Number(left.timelineRange.duration) + Number(right.timelineRange.duration),
    Number(secondsToTicks(10)),
  );
});

test("slide moves the middle clip while extending and trimming its neighbors", () => {
  const plan = compileEditorialEdit(fixture(), { kind: "slide", elementId: "b", offsetFrames: 3 });
  assert.deepEqual(plan.operations.map(({ type }) => type), ["trimElement", "moveElement", "trimElement"]);
  const move = plan.operations[1];
  assert.equal(move?.type, "moveElement");
  if (move?.type === "moveElement") {
    assert.equal(Number(move.start), Number(secondsToTicks(5)) + 14_400);
  }
  const following = plan.operations[2];
  assert.equal(following?.type, "trimElement");
  if (following?.type === "trimElement") {
    assert.equal(Number(following.timelineRange.start), Number(secondsToTicks(10)) + 14_400);
    assert.equal(Number(following.timelineRange.duration), Number(secondsToTicks(5)) - 14_400);
  }
});

test("ripple trim shifts only later elements on the same track", () => {
  const plan = compileEditorialEdit(fixture(), {
    kind: "ripple-trim",
    elementId: "b",
    edge: "end",
    offsetFrames: -5,
  });
  assert.deepEqual(plan.affectedElementIds, ["b", "c"]);
  assert.deepEqual(plan.operations.map(({ type }) => type), ["trimElement", "moveElement"]);
  const move = plan.operations[1];
  assert.equal(move?.type, "moveElement");
  if (move?.type === "moveElement") {
    assert.equal(Number(move.start), Number(secondsToTicks(10)) - 24_000);
  }
});

test("source handle inspection and validation fail closed", () => {
  assert.deepEqual(inspectSourceHandles(fixture(), "a"), {
    elementId: "a",
    frameTicks: 4_800,
    sourceStart: secondsToTicks(5),
    sourceEnd: secondsToTicks(10),
    assetDuration: secondsToTicks(30),
    headFrames: 125,
    tailFrames: 500,
  });
  assert.throws(
    () => compileEditorialEdit(fixture(), { kind: "slip", elementId: "a", offsetFrames: -126 }),
    EditorialEditError,
  );
  const retimed = fixture();
  retimed.sequences[0]!.tracks[0]!.elements[0]!.properties["playback.rate"] = 2;
  assert.throws(
    () => compileEditorialEdit(retimed, { kind: "slip", elementId: "a", offsetFrames: 1 }),
    /Normalize its speed/,
  );
});

test("roll and slide require exact neighboring cuts", () => {
  const gapped = fixture();
  gapped.sequences[0]!.tracks[0]!.elements[1]!.timelineRange.start = secondsToTicks(5.5);
  assert.throws(
    () => compileEditorialEdit(gapped, { kind: "roll", outgoingElementId: "a", offsetFrames: 1 }),
    /exact cut/,
  );
  assert.throws(
    () => compileEditorialEdit(gapped, { kind: "slide", elementId: "b", offsetFrames: 1 }),
    /exact cut/,
  );
});
