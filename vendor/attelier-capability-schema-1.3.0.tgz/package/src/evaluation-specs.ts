import type { DefectCategory } from "@attelier/capability-schema/craft-guide";

export const ATTELIER_EVALUATION_SPEC_VERSION = "1.0.0";
export const ATTELIER_EVALUATION_REGISTRY_VERSION = "1.8.0";

export type RubricDimension = {
  id: string;
  label: string;
  description: string;
  craftRuleIds: string[];
  anchors: { 1: string; 3: string; 5: string };
};

export type EvaluationInvalidator = {
  id: string;
  label: string;
  defectCategory: DefectCategory;
  description: string;
  craftRuleIds: string[];
};

export type EvaluationRootCause =
  | "tool-effect" | "default" | "skill" | "planner" | "provider-model"
  | "renderer" | "workflow" | "ambiguous-requirement";

export type UseCaseEvaluationRubric = {
  id: string;
  benchmarkId: string;
  version: string;
  primaryMetric: string;
  comparison: "blind-paired";
  preferenceOptions: readonly ["baseline", "candidate", "tie", "neither-publishable"];
  publishReadyOptions: readonly ["ready", "minor-changes", "major-changes", "reject"];
  dimensions: readonly RubricDimension[];
  invalidators: readonly EvaluationInvalidator[];
  rootCauses: readonly EvaluationRootCause[];
};

export const PRODUCT_AD_RUBRIC = {
  id: "product-ad-rubric.v1",
  benchmarkId: "workflow.product-ad.v1",
  version: "1.0.0",
  primaryMetric: "publish_ready_rate",
  comparison: "blind-paired" as const,
  preferenceOptions: ["baseline", "candidate", "tie", "neither-publishable"] as const,
  publishReadyOptions: ["ready", "minor-changes", "major-changes", "reject"] as const,
  dimensions: [
    { id: "hook", label: "Opening impact", description: "The first 2–3 seconds earn attention and establish a relevant promise.", craftRuleIds: ["craft.pacing.intentional"], anchors: { 1: "No clear opening idea or reason to continue.", 3: "Understandable opening, but generic or slow.", 5: "Immediate, specific and audience-relevant hook." } },
    { id: "product-clarity", label: "Product and benefit clarity", description: "The viewer understands what the product is, who it is for and why it matters.", craftRuleIds: ["craft.brand.truthful"], anchors: { 1: "Product or benefit is confusing.", 3: "Product is clear but the benefit or audience is weak.", 5: "Product, audience and differentiated benefit are unmistakable." } },
    { id: "brief-claims", label: "Brief and claim fidelity", description: "Every fact, offer and constraint is grounded in the approved brief.", craftRuleIds: ["craft.brand.truthful"], anchors: { 1: "Material brief violation or unsupported claim.", 3: "Mostly compliant with a minor omission or ambiguity.", 5: "Complete, precise and fully grounded in approved inputs." } },
    { id: "persuasion", label: "Persuasion", description: "The piece builds credible desire or intent rather than merely listing features.", craftRuleIds: ["craft.pacing.intentional", "craft.brand.truthful"], anchors: { 1: "No persuasive logic or credible reason to act.", 3: "Some value is communicated, but proof or motivation is weak.", 5: "Benefit, proof and motivation form a convincing commercial argument." } },
    { id: "narrative-pacing", label: "Narrative and pacing", description: "The sequence has coherent progression, intentional shot choice and no dead or rushed beats.", craftRuleIds: ["craft.pacing.intentional", "craft.editing.cuts", "craft.continuity.visual"], anchors: { 1: "Confusing, repetitive, rushed or materially slow.", 3: "Coherent with one or two pacing or continuity weaknesses.", 5: "Every beat advances the argument with confident rhythm and continuity." } },
    { id: "craft", label: "Audiovisual craft", description: "Composition, editing, motion, transitions, color, typography and audio feel intentional.", craftRuleIds: ["craft.composition.safe-area", "craft.motion.subtle", "craft.transitions.sparse", "craft.color.match-before-look", "craft.typography.readable", "craft.audio.intelligible"], anchors: { 1: "Multiple distracting craft failures.", 3: "Competent execution with visible room for polish.", 5: "Cohesive professional execution with no distracting weakness." } },
    { id: "brand-fit", label: "Brand fit", description: "Visual language, voice and product treatment feel coherent with supplied brand assets.", craftRuleIds: ["craft.brand.truthful", "craft.color.match-before-look"], anchors: { 1: "Off-brand or inconsistent treatment.", 3: "Recognizably on-brand but generic or uneven.", 5: "Distinctive, consistent and faithful brand expression." } },
    { id: "artifact-control", label: "Artifact control", description: "Generated and composited media remain stable and free from distracting defects.", craftRuleIds: ["craft.continuity.visual", "craft.delivery.qc"], anchors: { 1: "Severe or repeated distracting artifacts.", 3: "Minor visible artifacts that do not break the message.", 5: "No meaningful visual, temporal or audio artifacts." } },
    { id: "cta-legibility", label: "CTA and platform legibility", description: "The requested action is clear, readable and placed safely for the target platform.", craftRuleIds: ["craft.typography.readable", "craft.composition.safe-area", "craft.formats.platform-fit"], anchors: { 1: "CTA absent, unclear or unreadable.", 3: "CTA is present but could be clearer or better timed.", 5: "Clear, compelling and immediately legible CTA with strong platform fit." } },
    { id: "publish-ready", label: "Publish readiness", description: "Amount and severity of work needed before the ad can be published.", craftRuleIds: ["craft.delivery.qc", "craft.brand.truthful", "craft.formats.platform-fit"], anchors: { 1: "Reject or substantial rework required.", 3: "Publishable after meaningful but bounded changes.", 5: "Publishable as delivered with no important changes." } },
  ] satisfies RubricDimension[],
  invalidators: [
    { id: "wrong-identity", label: "Wrong product or identity", defectCategory: "brief-brand", description: "Product, person, logo or core brand identity is wrong or materially altered.", craftRuleIds: ["craft.brand.truthful"] },
    { id: "invented-claim", label: "Invented claim, price or offer", defectCategory: "brief-brand", description: "A commercial fact not present in approved inputs is asserted as true.", craftRuleIds: ["craft.brand.truthful"] },
    { id: "essential-text-unreadable", label: "Essential text unreadable", defectCategory: "technical", description: "A required claim, price or CTA cannot be read in the delivery context.", craftRuleIds: ["craft.typography.readable", "craft.composition.safe-area"] },
    { id: "severe-artifact", label: "Severe audiovisual artifact", defectCategory: "visual-artifact", description: "A broken render, black frame, clipping, identity drift or comparable defect invalidates publication.", craftRuleIds: ["craft.delivery.qc"] },
    { id: "safety-rights", label: "Safety, consent or rights failure", defectCategory: "rights", description: "Required consent, rights or provenance is missing or violated.", craftRuleIds: ["craft.safety.consent"] },
    { id: "delivery-mismatch", label: "Delivery mismatch", defectCategory: "technical", description: "Duration, aspect, language or required format does not match the brief.", craftRuleIds: ["craft.formats.platform-fit"] },
  ] satisfies EvaluationInvalidator[],
  rootCauses: ["tool-effect", "default", "skill", "planner", "provider-model", "renderer", "ambiguous-requirement"] as const satisfies readonly EvaluationRootCause[],
} as const;

export const TALKING_HEAD_RUBRIC = {
  id: "talking-head-rubric.v1",
  benchmarkId: "workflow.talking-head.v1",
  version: "1.0.0",
  primaryMetric: "publish_ready_rate",
  comparison: "blind-paired" as const,
  preferenceOptions: ["baseline", "candidate", "tie", "neither-publishable"] as const,
  publishReadyOptions: ["ready", "minor-changes", "major-changes", "reject"] as const,
  dimensions: [
    { id: "meaning-integrity", label: "Meaning integrity", description: "The edit preserves the speaker's intended meaning, qualifications and protected phrases.", craftRuleIds: ["craft.brand.truthful", "craft.editing.cuts"], anchors: { 1: "The edit changes, fabricates or materially distorts meaning.", 3: "Meaning is preserved with one minor ambiguity or awkward omission.", 5: "Meaning, nuance and protected wording are completely preserved." } },
    { id: "editorial-pacing", label: "Editorial pacing", description: "Pauses, fillers and repetitions are handled without rushing thought or leaving avoidable dead air.", craftRuleIds: ["craft.pacing.intentional", "craft.editing.cuts"], anchors: { 1: "Distractingly slow, repetitive, rushed or mechanically cut.", 3: "Generally clear with a few pauses or cuts that need refinement.", 5: "Natural, confident rhythm that supports comprehension throughout." } },
    { id: "cut-continuity", label: "Cut continuity", description: "Dialogue edits preserve sync and hide or motivate visual discontinuities.", craftRuleIds: ["craft.editing.cuts", "craft.continuity.visual"], anchors: { 1: "Frequent jump cuts, sync breaks or continuity failures distract from speech.", 3: "Cuts are usable with one or two visible discontinuities.", 5: "Every cut feels intentional, synchronized and visually resolved." } },
    { id: "subject-framing", label: "Subject framing", description: "The speaker, eyeline, gestures and demonstrations remain comfortably composed for the target format.", craftRuleIds: ["craft.composition.safe-area", "craft.motion.subtle", "craft.formats.platform-fit"], anchors: { 1: "The crop loses the subject, eyeline, gesture or essential demonstration.", 3: "Subject remains visible but framing is static, loose or occasionally awkward.", 5: "Stable, intentional framing follows the communication without calling attention to itself." } },
    { id: "caption-quality", label: "Caption quality", description: "Captions are accurate, synchronized, readable and segmented by meaning.", craftRuleIds: ["craft.captions.accessible", "craft.typography.readable", "craft.composition.safe-area"], anchors: { 1: "Captions are materially wrong, mistimed, missing or unreadable.", 3: "Captions are usable with minor timing, wording or line-break issues.", 5: "Captions are accurate, natural, well timed and effortless to read." } },
    { id: "dialogue-quality", label: "Dialogue quality", description: "Speech is intelligible, natural and consistently mixed without destructive cleanup.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"], anchors: { 1: "Speech is hard to understand, clipped, pumping or unnaturally processed.", 3: "Speech is intelligible with bounded noise, level or edit artifacts.", 5: "Speech is clear, stable and natural across the full piece." } },
    { id: "visual-cohesion", label: "Visual cohesion", description: "Color, B-roll, graphics and motion support the speaker rather than compete with them.", craftRuleIds: ["craft.color.match-before-look", "craft.transitions.sparse", "craft.motion.subtle"], anchors: { 1: "Visual treatment is inconsistent or repeatedly distracts from the message.", 3: "Treatment is coherent but generic or uneven in places.", 5: "A restrained, cohesive visual system strengthens the communication." } },
    { id: "platform-fit", label: "Platform fit", description: "Duration, format, safe areas and information density suit the stated audience and delivery target.", craftRuleIds: ["craft.formats.platform-fit", "craft.composition.safe-area", "craft.pacing.intentional"], anchors: { 1: "The piece materially misses its requested delivery context.", 3: "The output fits the platform with minor adaptation needed.", 5: "The edit feels purpose-built for its audience, format and viewing context." } },
    { id: "publish-ready", label: "Publish readiness", description: "Amount and severity of work needed before the talking-head piece can be published.", craftRuleIds: ["craft.delivery.qc", "craft.editing.cuts", "craft.audio.intelligible"], anchors: { 1: "Reject or structural re-edit required.", 3: "Publishable after meaningful but bounded changes.", 5: "Publishable as delivered with no important changes." } },
  ] satisfies RubricDimension[],
  invalidators: [
    { id: "meaning-altered", label: "Meaning materially altered", defectCategory: "brief-brand", description: "A cut removes a qualification, reverses intent or changes the speaker's factual meaning.", craftRuleIds: ["craft.brand.truthful", "craft.editing.cuts"] },
    { id: "fabricated-speech", label: "Fabricated or unapproved speech", defectCategory: "brief-brand", description: "The output presents words the speaker did not say or approve as authentic speech.", craftRuleIds: ["craft.brand.truthful", "craft.safety.consent"] },
    { id: "essential-subject-cropped", label: "Essential subject content cropped", defectCategory: "technical", description: "The speaker, eyeline, gesture, product or demonstration required for comprehension is materially cropped out.", craftRuleIds: ["craft.composition.safe-area", "craft.formats.platform-fit"] },
    { id: "dialogue-unintelligible", label: "Dialogue unintelligible", defectCategory: "audio", description: "Required speech cannot be understood because of level, noise, clipping, sync or destructive processing.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"] },
    { id: "captions-essential-error", label: "Essential caption error", defectCategory: "technical", description: "Captions omit, invent or make unreadable meaning required for accessibility or comprehension.", craftRuleIds: ["craft.captions.accessible", "craft.typography.readable"] },
    { id: "safety-rights", label: "Safety, consent or rights failure", defectCategory: "rights", description: "Speaker identity, voice, supplied media or generated inserts lack required consent, rights or provenance.", craftRuleIds: ["craft.safety.consent"] },
    { id: "delivery-mismatch", label: "Delivery mismatch", defectCategory: "technical", description: "Duration, aspect, language or required format does not match the brief.", craftRuleIds: ["craft.formats.platform-fit"] },
  ] satisfies EvaluationInvalidator[],
  rootCauses: ["tool-effect", "default", "skill", "planner", "provider-model", "renderer", "workflow", "ambiguous-requirement"] as const satisfies readonly EvaluationRootCause[],
} as const;

export const LONG_TO_SHORTS_RUBRIC = {
  id: "long-to-shorts-rubric.v1",
  benchmarkId: "workflow.long-to-shorts.v1",
  version: "1.0.0",
  primaryMetric: "publish_ready_rate",
  comparison: "blind-paired" as const,
  preferenceOptions: ["baseline", "candidate", "tie", "neither-publishable"] as const,
  publishReadyOptions: ["ready", "minor-changes", "major-changes", "reject"] as const,
  dimensions: [
    { id: "meaning-integrity", label: "Meaning integrity", description: "The short preserves claims, attribution, uncertainty and causal context from the source.", craftRuleIds: ["craft.brand.truthful", "craft.editing.cuts"], anchors: { 1: "The extraction materially distorts or fabricates meaning.", 3: "Meaning is mostly preserved with a bounded context weakness.", 5: "Meaning and essential context are completely faithful to the source." } },
    { id: "highlight-selection", label: "Highlight selection", description: "The selected moment is valuable, specific and appropriate for the requested audience.", craftRuleIds: ["craft.pacing.intentional"], anchors: { 1: "The moment is trivial, redundant or misses the source's useful material.", 3: "The moment is relevant but not the strongest available choice.", 5: "The selection captures a distinctive, high-value moment for the audience." } },
    { id: "hook-strength", label: "Hook strength", description: "The opening earns attention without clickbait or removing necessary setup.", craftRuleIds: ["craft.pacing.intentional", "craft.brand.truthful"], anchors: { 1: "The opening is confusing, slow or misleading.", 3: "The topic is clear but the opening is generic or needs trimming.", 5: "The opening is immediate, specific and truthful." } },
    { id: "self-contained-story", label: "Self-contained story", description: "The clip provides enough setup, progression and resolution to work independently.", craftRuleIds: ["craft.editing.cuts", "craft.continuity.visual", "craft.pacing.intentional"], anchors: { 1: "The clip starts or ends mid-thought and cannot stand alone.", 3: "The clip is understandable with a minor setup or ending weakness.", 5: "The clip forms a concise, complete narrative unit." } },
    { id: "editorial-pacing", label: "Editorial pacing", description: "Cuts, pauses and supporting shots sustain clarity and momentum without feeling mechanical.", craftRuleIds: ["craft.pacing.intentional", "craft.editing.cuts"], anchors: { 1: "Distractingly slow, rushed, repetitive or mechanically cut.", 3: "Generally effective with a few weak beats.", 5: "Every beat advances comprehension with natural rhythm." } },
    { id: "reframe-quality", label: "Reframe quality", description: "People, gestures, demonstrations and on-screen content remain intentionally composed in the target format.", craftRuleIds: ["craft.composition.safe-area", "craft.formats.platform-fit", "craft.motion.subtle"], anchors: { 1: "Essential subjects or content are cropped or the frame repeatedly hunts.", 3: "The crop is usable with occasional static or awkward composition.", 5: "Framing tracks communication smoothly and preserves all essential content." } },
    { id: "caption-quality", label: "Caption quality", description: "Captions are faithful, synchronized, readable and segmented for short-form viewing.", craftRuleIds: ["craft.captions.accessible", "craft.typography.readable", "craft.composition.safe-area"], anchors: { 1: "Captions are wrong, missing, mistimed or unreadable.", 3: "Captions are usable with minor wording, timing or layout issues.", 5: "Captions are accurate, concise and effortless to follow." } },
    { id: "audiovisual-craft", label: "Audiovisual craft", description: "Audio, color, graphics, transitions and supporting media feel cohesive and restrained.", craftRuleIds: ["craft.audio.intelligible", "craft.color.match-before-look", "craft.transitions.sparse", "craft.delivery.qc"], anchors: { 1: "Multiple craft failures distract from or obscure the message.", 3: "Competent execution with visible room for polish.", 5: "Cohesive professional execution with no distracting weakness." } },
    { id: "publish-ready", label: "Publish readiness", description: "Amount and severity of work required before the short can be published.", craftRuleIds: ["craft.delivery.qc", "craft.formats.platform-fit"], anchors: { 1: "Reject or structural re-edit required.", 3: "Publishable after meaningful but bounded changes.", 5: "Publishable as delivered with no important changes." } },
  ] satisfies RubricDimension[],
  invalidators: [
    { id: "context-distortion", label: "Context or meaning distorted", defectCategory: "narrative", description: "The extraction removes context in a way that changes the speaker's claim, intent or attribution.", craftRuleIds: ["craft.brand.truthful", "craft.editing.cuts"] },
    { id: "fabricated-speech", label: "Fabricated or unapproved speech", defectCategory: "brief-brand", description: "The output presents words the source speaker did not say or approve as authentic speech.", craftRuleIds: ["craft.brand.truthful", "craft.safety.consent"] },
    { id: "not-self-contained", label: "Essential setup or resolution missing", defectCategory: "narrative", description: "The short cannot be understood independently because required context or resolution is absent.", craftRuleIds: ["craft.editing.cuts", "craft.pacing.intentional"] },
    { id: "essential-content-cropped", label: "Essential content cropped", defectCategory: "technical", description: "A speaker, gesture, demonstration or on-screen element required for comprehension is materially cropped out.", craftRuleIds: ["craft.composition.safe-area", "craft.formats.platform-fit"] },
    { id: "captions-essential-error", label: "Essential caption error", defectCategory: "technical", description: "Captions omit, invent or make unreadable meaning required for comprehension.", craftRuleIds: ["craft.captions.accessible", "craft.typography.readable"] },
    { id: "safety-rights", label: "Safety, consent or rights failure", defectCategory: "rights", description: "Source, speaker, voice, music or supporting media lacks required consent, rights or provenance.", craftRuleIds: ["craft.safety.consent"] },
    { id: "delivery-mismatch", label: "Delivery mismatch", defectCategory: "technical", description: "Count, duration, aspect, language or required package does not match the brief.", craftRuleIds: ["craft.formats.platform-fit"] },
  ] satisfies EvaluationInvalidator[],
  rootCauses: ["tool-effect", "default", "skill", "planner", "provider-model", "renderer", "workflow", "ambiguous-requirement"] as const satisfies readonly EvaluationRootCause[],
} as const;

export const LOCALIZATION_RUBRIC = {
  id: "localization-rubric.v1",
  benchmarkId: "workflow.localization.v1",
  version: "1.0.0",
  primaryMetric: "publish_ready_rate",
  comparison: "blind-paired" as const,
  preferenceOptions: ["baseline", "candidate", "tie", "neither-publishable"] as const,
  publishReadyOptions: ["ready", "minor-changes", "major-changes", "reject"] as const,
  dimensions: [
    { id: "meaning-fidelity", label: "Meaning fidelity", description: "The localized version preserves claims, intent, nuance, uncertainty and speaker attribution.", craftRuleIds: ["craft.brand.truthful", "craft.captions.accessible"], anchors: { 1: "Meaning is invented, omitted or materially changed.", 3: "Core meaning is preserved with a bounded nuance or attribution weakness.", 5: "Meaning, nuance and attribution are completely faithful and natural." } },
    { id: "terminology-accuracy", label: "Terminology, names and numbers", description: "Approved glossary terms, product names, proper nouns, quantities and offers are exact and consistent.", craftRuleIds: ["craft.brand.truthful"], anchors: { 1: "A protected term, name, number or offer is materially wrong.", 3: "Required terminology is usable with a minor consistency issue.", 5: "Every protected token is exact, consistent and contextually correct." } },
    { id: "linguistic-naturalness", label: "Linguistic naturalness", description: "Wording, register and cultural adaptation sound native for the requested audience without changing the brief.", craftRuleIds: ["craft.brand.truthful", "craft.pacing.intentional"], anchors: { 1: "Language is unnatural, culturally inappropriate or difficult to understand.", 3: "Understandable and mostly natural with a few literal or awkward choices.", 5: "Fluent, audience-appropriate language that never feels translated." } },
    { id: "subtitle-quality", label: "Subtitle quality", description: "Localized captions are faithful, readable, safely placed and segmented at natural linguistic boundaries.", craftRuleIds: ["craft.captions.accessible", "craft.typography.readable", "craft.composition.safe-area"], anchors: { 1: "Subtitles are wrong, missing, mistimed or unreadable.", 3: "Subtitles are usable with minor timing, line-break or reading-speed issues.", 5: "Subtitles are accurate, effortless to read and naturally segmented." } },
    { id: "voice-performance", label: "Voice and identity performance", description: "The localized voice is intelligible, emotionally appropriate, consistent by speaker and authorized for the stated purpose.", craftRuleIds: ["craft.audio.intelligible", "craft.safety.consent"], anchors: { 1: "Voice is unintelligible, mismatched, unstable or unauthorized.", 3: "Voice is usable with minor performance, pronunciation or consistency issues.", 5: "Voice is natural, correctly attributed, well performed and fully authorized." } },
    { id: "speech-sync", label: "Speech timing and sync", description: "Localized speech fits the available time and remains acceptably synchronized without destructive retiming.", craftRuleIds: ["craft.audio.intelligible", "craft.pacing.intentional", "craft.continuity.visual"], anchors: { 1: "Speech is cut off, overlaps materially or is visibly out of sync.", 3: "Timing is usable with a few noticeable pauses or sync compromises.", 5: "Phrasing, pauses and visual sync feel intentional throughout." } },
    { id: "audio-mix", label: "Localized audio mix", description: "Dialogue, source sound and music remain clean, stable and balanced for the delivery target.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"], anchors: { 1: "Dialogue is obscured, clipped, silent or destructively processed.", 3: "Mix is intelligible with bounded level, tone or transition weaknesses.", 5: "The localized mix is transparent, consistent and delivery-ready." } },
    { id: "delivery-lineage", label: "Delivery, editability and lineage", description: "Each locale has the requested editable branch, captions, voice status, consent, provenance and delivery metadata.", craftRuleIds: ["craft.formats.platform-fit", "craft.safety.consent", "craft.delivery.qc"], anchors: { 1: "A required locale, editable component, right or lineage record is missing.", 3: "The package is usable with a minor metadata or editability gap.", 5: "Every locale is complete, editable, traceable and correctly packaged." } },
    { id: "publish-ready", label: "Publish readiness", description: "Amount and severity of work required before the localized version can be published.", craftRuleIds: ["craft.delivery.qc", "craft.formats.platform-fit", "craft.safety.consent"], anchors: { 1: "Reject or full localization redo required.", 3: "Publishable after meaningful but bounded changes.", 5: "Publishable as delivered with no important changes." } },
  ] satisfies RubricDimension[],
  invalidators: [
    { id: "meaning-altered", label: "Meaning materially altered", defectCategory: "brief-brand", description: "The localization changes a claim, intent, qualification, attribution or required instruction.", craftRuleIds: ["craft.brand.truthful"] },
    { id: "protected-token-error", label: "Protected term, name or number wrong", defectCategory: "brief-brand", description: "A glossary term, product name, person, quantity, price or offer required by the brief is incorrect.", craftRuleIds: ["craft.brand.truthful"] },
    { id: "unauthorized-identity", label: "Unauthorized or mismatched identity", defectCategory: "rights", description: "A cloned, modified or assigned voice lacks valid scoped consent or is attributed to the wrong speaker.", craftRuleIds: ["craft.safety.consent"] },
    { id: "required-locale-missing", label: "Required locale missing", defectCategory: "technical", description: "A requested language branch, subtitle track, dub or explicit provider-required status is absent.", craftRuleIds: ["craft.formats.platform-fit", "craft.delivery.qc"] },
    { id: "essential-subtitle-error", label: "Essential subtitle error", defectCategory: "technical", description: "Localized captions omit, invent, mistime or make unreadable information needed for comprehension.", craftRuleIds: ["craft.captions.accessible", "craft.typography.readable"] },
    { id: "speech-unintelligible-or-unsynced", label: "Speech unintelligible or materially unsynced", defectCategory: "audio", description: "Required localized speech cannot be understood, is cut off or is materially out of sync.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"] },
    { id: "safety-rights", label: "Safety, consent or rights failure", defectCategory: "rights", description: "Source, speaker, voice, music or generated media lacks required consent, rights or provenance.", craftRuleIds: ["craft.safety.consent"] },
    { id: "delivery-mismatch", label: "Delivery mismatch", defectCategory: "technical", description: "Locale, aspect, duration, caption format or required package does not match the brief.", craftRuleIds: ["craft.formats.platform-fit"] },
  ] satisfies EvaluationInvalidator[],
  rootCauses: ["tool-effect", "default", "skill", "planner", "provider-model", "renderer", "workflow", "ambiguous-requirement"] as const satisfies readonly EvaluationRootCause[],
} as const;

/**
 * Product Orbit is a capability benchmark, not a complete-ad benchmark. Its
 * perceptual gate therefore judges one source image, one requested camera move
 * and one generated clip at a time. Objective decode/QC measurements remain
 * separate hard gates; these scores must never compensate for a broken clip,
 * missing rights evidence or a reversed camera instruction.
 */
export const CONTROLLED_CAMERA_I2V_RUBRIC = {
  id: "controlled-camera-i2v-rubric.v1",
  benchmarkId: "capability.controlled-camera-i2v.v1",
  version: "1.0.0",
  primaryMetric: "blind_human_preference",
  comparison: "blind-paired" as const,
  preferenceOptions: ["baseline", "candidate", "tie", "neither-publishable"] as const,
  publishReadyOptions: ["ready", "minor-changes", "major-changes", "reject"] as const,
  dimensions: [
    { id: "product-identity", label: "Product identity", description: "The generated clip preserves the source product's silhouette, proportions, materials, colors and distinguishing details.", craftRuleIds: ["craft.brand.truthful", "craft.continuity.visual"], anchors: { 1: "The product becomes a different object or materially changes identity.", 3: "The product remains recognizable with minor shape, material or detail drift.", 5: "Identity and physical details remain convincing throughout the shot." } },
    { id: "camera-instruction", label: "Requested camera move", description: "The visible camera path follows the requested direction and creates credible viewpoint change rather than a static crop or unrelated object motion.", craftRuleIds: ["craft.motion.subtle", "craft.continuity.visual"], anchors: { 1: "The move is absent, reversed or unrelated to the request.", 3: "The requested direction is visible but weak, partial or uneven.", 5: "The requested move is clear, controlled and spatially convincing." } },
    { id: "temporal-coherence", label: "Temporal coherence", description: "Geometry, texture, reflections, background and motion remain stable from frame to frame.", craftRuleIds: ["craft.continuity.visual", "craft.delivery.qc"], anchors: { 1: "Severe morphing, flicker, tearing or discontinuity breaks the shot.", 3: "The shot is usable with bounded visible instability.", 5: "Motion and appearance remain coherent throughout." } },
    { id: "physical-plausibility", label: "Physical and spatial plausibility", description: "Parallax, occlusion, perspective and lighting changes agree with a plausible camera moving around a stable product.", craftRuleIds: ["craft.continuity.visual", "craft.color.match-before-look"], anchors: { 1: "Perspective, lighting or occlusion is physically contradictory.", 3: "The spatial result reads, with minor synthetic or flattened moments.", 5: "The camera path and scene response feel physically credible." } },
    { id: "commercial-craft", label: "Commercial shot utility", description: "Composition, pacing, lighting and cleanliness make the clip useful as a premium product insert.", craftRuleIds: ["craft.composition.safe-area", "craft.pacing.intentional", "craft.color.match-before-look"], anchors: { 1: "The shot is distracting, generic or unusable in an edit.", 3: "The shot is serviceable but needs visible polish or reframing.", 5: "The shot feels intentional, premium and immediately editable." } },
    { id: "publish-ready", label: "Publish readiness", description: "Amount and severity of work required before this shot can be used in a finished commercial edit.", craftRuleIds: ["craft.delivery.qc", "craft.formats.platform-fit"], anchors: { 1: "Reject or regenerate the shot.", 3: "Usable after meaningful but bounded repair.", 5: "Usable as delivered with no important correction." } },
  ] satisfies RubricDimension[],
  invalidators: [
    { id: "wrong-product-identity", label: "Wrong or materially altered product", defectCategory: "brief-brand", description: "The generated object no longer preserves the supplied product identity.", craftRuleIds: ["craft.brand.truthful", "craft.continuity.visual"] },
    { id: "requested-motion-missing", label: "Requested camera motion missing", defectCategory: "temporal", description: "The shot is effectively static or substitutes object/background movement for the requested camera move.", craftRuleIds: ["craft.motion.subtle"] },
    { id: "requested-motion-reversed", label: "Requested direction reversed", defectCategory: "temporal", description: "The camera visibly travels in the opposite direction to the case instruction.", craftRuleIds: ["craft.motion.subtle"] },
    { id: "severe-temporal-artifact", label: "Severe temporal or geometry artifact", defectCategory: "visual-artifact", description: "Morphing, flicker, duplicated parts, tearing or an impossible viewpoint invalidates the shot.", craftRuleIds: ["craft.continuity.visual", "craft.delivery.qc"] },
    { id: "unrequested-overlay", label: "Unrequested text, logo or watermark", defectCategory: "brief-brand", description: "The output adds an overlay, wordmark, watermark or other unsupported graphic.", craftRuleIds: ["craft.brand.truthful"] },
    { id: "delivery-failure", label: "Technical delivery failure", defectCategory: "technical", description: "The clip is undecodable, contains black/frozen output, or misses the required duration or format.", craftRuleIds: ["craft.delivery.qc", "craft.formats.platform-fit"] },
    { id: "safety-rights", label: "Rights or provenance failure", defectCategory: "rights", description: "The source image, output, model or evaluation lineage lacks the required rights record.", craftRuleIds: ["craft.safety.consent"] },
  ] satisfies EvaluationInvalidator[],
  rootCauses: ["provider-model", "renderer", "tool-effect", "ambiguous-requirement"] as const satisfies readonly EvaluationRootCause[],
} as const;

export const RATER_GUIDE = {
  id: "atelier-rater-guide.v1",
  version: "1.0.0",
  rules: [
    "Review the brief before playing either result and judge only against approved inputs.",
    "Watch A and B in a randomized order at least once without scrubbing, then inspect details.",
    "Record invalidators before preference; a high average never cancels a critical invalidator.",
    "Choose A, B, tie or neither publishable. Do not infer provider identity from style or latency.",
    "Score every dimension from 1 to 5 using its anchors and provide a concrete reason for scores 1, 2 or 5.",
    "Assess publish readiness by required revision severity, not personal taste.",
  ],
  publishReadyAnchors: {
    ready: "No important change is required before publication.",
    "minor-changes": "Only local polish is required; strategy, claims and structure remain intact.",
    "major-changes": "A structural, creative, claim, brand or quality revision is required.",
    reject: "The result is unusable, unsafe, off-brief or economically unreasonable to repair.",
  },
  minimumPromotionReviewersPerCase: 3,
} as const;

export const DOCUMENTARY_RUBRIC = {
  id: "documentary-rubric.v1",
  benchmarkId: "workflow.documentary.v1",
  version: "1.0.0",
  primaryMetric: "publish_ready_rate",
  comparison: "blind-paired" as const,
  preferenceOptions: ["baseline", "candidate", "tie", "neither-publishable"] as const,
  publishReadyOptions: ["ready", "minor-changes", "major-changes", "reject"] as const,
  dimensions: [
    { id: "story-order", label: "Story order", description: "The shot order builds an argument or narrative rather than replaying the capture order of the source clips.", craftRuleIds: ["craft.editing.cuts", "craft.pacing.intentional"], anchors: { 1: "Shots follow ingest order with no editorial reason.", 3: "A readable order with one or two beats out of place.", 5: "Every shot earns its position in the story." } },
    { id: "cut-craft", label: "Cut craft", description: "Cuts land on word and action boundaries with usable handles; picture and sound cuts are placed deliberately.", craftRuleIds: ["craft.editing.cuts", "craft.continuity.visual"], anchors: { 1: "Cuts clip words or actions and break continuity.", 3: "Mostly clean cuts with a few audible or visible seams.", 5: "Word-accurate cuts, motivated J/L offsets, no clipped syllables." } },
    { id: "dialogue-consistency", label: "Dialogue consistency", description: "Speech from different sources sits on one level bed and one tonal character across the piece.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"], anchors: { 1: "Level or tone jumps at nearly every cut.", 3: "One or two audible steps between clips.", 5: "Speech reads as one continuous recording." } },
    { id: "visual-continuity", label: "Visual continuity", description: "Exposure, white balance and grade match across sources before any creative look is applied.", craftRuleIds: ["craft.color.match-before-look", "craft.continuity.visual"], anchors: { 1: "Sources visibly mismatch shot to shot.", 3: "A shared look hides most, but not all, source drift.", 5: "Clips are matched first and graded once as one film." } },
    { id: "titles-and-lower-thirds", label: "Titles and lower thirds", description: "Names, roles and titles are readable, consistently placed and inside the delivery safe area.", craftRuleIds: ["craft.typography.readable", "craft.composition.safe-area"], anchors: { 1: "Inconsistent, unreadable or clipped identification.", 3: "Readable but inconsistently positioned or timed.", 5: "One typographic system, correctly timed and safely placed." } },
    { id: "timebase-integrity", label: "Timebase integrity", description: "Sequence frame rate, source frame rates and durations agree so motion is not judder-cadenced.", craftRuleIds: ["craft.delivery.qc"], anchors: { 1: "Sequence rate contradicts the sources and motion judders.", 3: "Rates agree but some durations are not frame-aligned.", 5: "One timebase derived from the sources, frame-accurate throughout." } },
    { id: "sound-bed", label: "Sound bed", description: "Ambience, music and room tone hold the piece together under the cuts without masking speech.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"], anchors: { 1: "Silence or music drops expose every edit.", 3: "A bed exists but ducking or continuity is uneven.", 5: "A continuous, ducked bed makes the edit invisible." } },
    { id: "publish-ready", label: "Publish readiness", description: "Amount and severity of work needed before the documentary cut can be published.", craftRuleIds: ["craft.delivery.qc", "craft.editing.cuts", "craft.audio.intelligible"], anchors: { 1: "Reject or structural re-edit required.", 3: "Publishable after meaningful but bounded changes.", 5: "Publishable as delivered with no important changes." } },
  ] satisfies RubricDimension[],
  invalidators: [
    { id: "meaning-altered", label: "Meaning materially altered", defectCategory: "brief-brand", description: "A cut reverses intent, removes a qualification or attributes a statement to the wrong speaker.", craftRuleIds: ["craft.brand.truthful", "craft.editing.cuts"] },
    { id: "mid-word-cut", label: "Speech clipped by a cut", defectCategory: "audio", description: "A picture or audio cut lands inside a spoken word and clips a syllable.", craftRuleIds: ["craft.editing.cuts", "craft.audio.intelligible"] },
    { id: "dialogue-level-jump", label: "Dialogue level jump", defectCategory: "audio", description: "Speech level steps audibly between clips because per-clip gain was never set.", craftRuleIds: ["craft.audio.intelligible", "craft.delivery.qc"] },
    { id: "timebase-mismatch", label: "Timebase mismatch", defectCategory: "technical", description: "The sequence frame rate does not follow the source frame rate, producing cadence judder in the master.", craftRuleIds: ["craft.delivery.qc"] },
    { id: "identification-unreadable", label: "Identification unreadable", defectCategory: "technical", description: "A required name or role card is illegible, mistimed or outside the delivery safe area.", craftRuleIds: ["craft.typography.readable", "craft.composition.safe-area"] },
    { id: "safety-rights", label: "Safety, consent or rights failure", defectCategory: "rights", description: "A recognizable person, voice or supplied clip lacks required consent, rights or provenance.", craftRuleIds: ["craft.safety.consent"] },
  ] satisfies EvaluationInvalidator[],
  rootCauses: ["tool-effect", "default", "skill", "planner", "provider-model", "renderer", "workflow", "ambiguous-requirement"] as const satisfies readonly EvaluationRootCause[],
} as const;

export const USE_CASE_EVALUATION_RUBRICS = [
  PRODUCT_AD_RUBRIC,
  TALKING_HEAD_RUBRIC,
  LONG_TO_SHORTS_RUBRIC,
  LOCALIZATION_RUBRIC,
  CONTROLLED_CAMERA_I2V_RUBRIC,
  DOCUMENTARY_RUBRIC,
] as const;

export const evaluationSpecForBenchmark = (benchmarkId: string): UseCaseEvaluationRubric | undefined =>
  USE_CASE_EVALUATION_RUBRICS.find((rubric) => rubric.benchmarkId === benchmarkId);

export const evaluationSpecById = (specId: string): UseCaseEvaluationRubric | undefined =>
  USE_CASE_EVALUATION_RUBRICS.find((rubric) => rubric.id === specId);

export const validateProductAdRubric = (): string[] => {
  const issues: string[] = [];
  const ids = PRODUCT_AD_RUBRIC.dimensions.map(({ id }) => id);
  if (new Set(ids).size !== ids.length) issues.push("product-ad rubric has duplicate dimensions");
  if (PRODUCT_AD_RUBRIC.dimensions.length !== 10) issues.push("product-ad rubric must contain ten dimensions");
  for (const dimension of PRODUCT_AD_RUBRIC.dimensions) {
    if (!dimension.anchors[1] || !dimension.anchors[3] || !dimension.anchors[5]) issues.push(`${dimension.id} is missing rater anchors`);
    if (dimension.craftRuleIds.length === 0) issues.push(`${dimension.id} is not linked to craft`);
  }
  if (PRODUCT_AD_RUBRIC.invalidators.length === 0) issues.push("product-ad rubric has no invalidators");
  return issues;
};

export const validateTalkingHeadRubric = (): string[] => {
  const issues: string[] = [];
  const ids = TALKING_HEAD_RUBRIC.dimensions.map(({ id }) => id);
  if (new Set(ids).size !== ids.length) issues.push("talking-head rubric has duplicate dimensions");
  if (TALKING_HEAD_RUBRIC.dimensions.length !== 9) issues.push("talking-head rubric must contain nine dimensions");
  for (const dimension of TALKING_HEAD_RUBRIC.dimensions) {
    if (!dimension.anchors[1] || !dimension.anchors[3] || !dimension.anchors[5]) issues.push(`${dimension.id} is missing rater anchors`);
    if (dimension.craftRuleIds.length === 0) issues.push(`${dimension.id} is not linked to craft`);
  }
  if (TALKING_HEAD_RUBRIC.invalidators.length === 0) issues.push("talking-head rubric has no invalidators");
  return issues;
};

export const validateLongToShortsRubric = (): string[] => {
  const issues: string[] = [];
  const ids = LONG_TO_SHORTS_RUBRIC.dimensions.map(({ id }) => id);
  if (new Set(ids).size !== ids.length) issues.push("long-to-shorts rubric has duplicate dimensions");
  if (LONG_TO_SHORTS_RUBRIC.dimensions.length !== 9) issues.push("long-to-shorts rubric must contain nine dimensions");
  for (const dimension of LONG_TO_SHORTS_RUBRIC.dimensions) {
    if (!dimension.anchors[1] || !dimension.anchors[3] || !dimension.anchors[5]) issues.push(`${dimension.id} is missing rater anchors`);
    if (dimension.craftRuleIds.length === 0) issues.push(`${dimension.id} is not linked to craft`);
  }
  if (LONG_TO_SHORTS_RUBRIC.invalidators.length === 0) issues.push("long-to-shorts rubric has no invalidators");
  return issues;
};

export const validateLocalizationRubric = (): string[] => {
  const issues: string[] = [];
  const ids = LOCALIZATION_RUBRIC.dimensions.map(({ id }) => id);
  if (new Set(ids).size !== ids.length) issues.push("localization rubric has duplicate dimensions");
  if (LOCALIZATION_RUBRIC.dimensions.length !== 9) issues.push("localization rubric must contain nine dimensions");
  for (const dimension of LOCALIZATION_RUBRIC.dimensions) {
    if (!dimension.anchors[1] || !dimension.anchors[3] || !dimension.anchors[5]) issues.push(`${dimension.id} is missing rater anchors`);
    if (dimension.craftRuleIds.length === 0) issues.push(`${dimension.id} is not linked to craft`);
  }
  if (LOCALIZATION_RUBRIC.invalidators.length === 0) issues.push("localization rubric has no invalidators");
  return issues;
};

export const validateControlledCameraI2vRubric = (): string[] => {
  const issues: string[] = [];
  const ids = CONTROLLED_CAMERA_I2V_RUBRIC.dimensions.map(({ id }) => id);
  if (new Set(ids).size !== ids.length) issues.push("controlled-camera-i2v rubric has duplicate dimensions");
  if (CONTROLLED_CAMERA_I2V_RUBRIC.dimensions.length !== 6) issues.push("controlled-camera-i2v rubric must contain six dimensions");
  for (const dimension of CONTROLLED_CAMERA_I2V_RUBRIC.dimensions) {
    if (!dimension.anchors[1] || !dimension.anchors[3] || !dimension.anchors[5]) issues.push(`${dimension.id} is missing rater anchors`);
    if (dimension.craftRuleIds.length === 0) issues.push(`${dimension.id} is not linked to craft`);
  }
  if (CONTROLLED_CAMERA_I2V_RUBRIC.invalidators.length === 0) issues.push("controlled-camera-i2v rubric has no invalidators");
  return issues;
};

export const validateDocumentaryRubric = (): string[] => {
  const issues: string[] = [];
  const ids = DOCUMENTARY_RUBRIC.dimensions.map(({ id }) => id);
  if (new Set(ids).size !== ids.length) issues.push("documentary rubric has duplicate dimensions");
  if (DOCUMENTARY_RUBRIC.dimensions.length !== 8) issues.push("documentary rubric must contain eight dimensions");
  for (const dimension of DOCUMENTARY_RUBRIC.dimensions) {
    if (!dimension.anchors[1] || !dimension.anchors[3] || !dimension.anchors[5]) issues.push(`${dimension.id} is missing rater anchors`);
    if (dimension.craftRuleIds.length === 0) issues.push(`${dimension.id} is not linked to craft`);
  }
  if (DOCUMENTARY_RUBRIC.invalidators.length === 0) issues.push("documentary rubric has no invalidators");
  return issues;
};
