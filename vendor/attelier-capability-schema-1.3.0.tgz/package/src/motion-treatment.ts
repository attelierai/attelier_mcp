/** Provider-independent safety decision for render-only motion treatments. */

export const ATTELIER_MOTION_TREATMENT_PREFLIGHT_VERSION = "1.0.0" as const;

export type MotionTreatmentKind = "stabilization" | "motion-blur" | "both";
export type MotionIntent = "unknown" | "unintentional" | "intentional";
export type MotionLevel = "unknown" | "static" | "low" | "moderate" | "high";

export type MotionTreatmentPreflight = {
  version: typeof ATTELIER_MOTION_TREATMENT_PREFLIGHT_VERSION;
  status: "allowed" | "needs-action";
  kind: MotionTreatmentKind;
  observations: {
    motionIntent: MotionIntent;
    motionLevel: MotionLevel;
    protectedDetail: boolean;
    analysisStatus: "not-run" | "measured" | "insufficient";
  };
  reasonCodes: Array<
    "intentional-motion-protected" |
    "motion-analysis-insufficient" |
    "insufficient-motion" |
    "essential-detail-protected"
  >;
  reasons: string[];
  limitations: string[];
  requiresEncodedProof: true;
};

const motionIntent = (value: unknown): MotionIntent =>
  value === "intentional" || value === "unintentional" ? value : "unknown";

const motionLevel = (value: unknown): MotionLevel =>
  value === "static" || value === "low" || value === "moderate" || value === "high" ? value : "unknown";

/**
 * Fail closed when a project/user annotation proves that the requested effect
 * contradicts the shot's intent. It merges explicit project annotations with
 * optional measured global-motion evidence, while keeping unavailable pixel
 * semantics and the lack of OCR explicit.
 */
export const assessMotionTreatment = (input: {
  kind: MotionTreatmentKind;
  properties?: Record<string, unknown>;
  motionIntent?: unknown;
  motionLevel?: unknown;
  protectedDetail?: unknown;
  analysisStatus?: unknown;
}): MotionTreatmentPreflight => {
  const properties = input.properties ?? {};
  const propertyIntent = motionIntent(properties["motion.intent"]);
  const propertyLevel = motionLevel(properties["motion.level"]);
  const measuredIntent = motionIntent(input.motionIntent);
  const measuredLevel = motionLevel(input.motionLevel);
  const observedIntent = propertyIntent === "intentional" || measuredIntent === "intentional"
    ? "intentional"
    : propertyIntent !== "unknown" ? propertyIntent : measuredIntent;
  const observedLevel = propertyLevel === "static" || measuredLevel === "static"
    ? "static"
    : propertyLevel === "low" || measuredLevel === "low"
      ? "low"
      : propertyLevel !== "unknown" ? propertyLevel : measuredLevel;
  const propertyAnalysisStatus = properties["motion.analysis.status"];
  const analysisStatus = propertyAnalysisStatus === "insufficient" || input.analysisStatus === "insufficient"
    ? "insufficient"
    : propertyAnalysisStatus === "measured" || input.analysisStatus === "measured"
      ? "measured"
      : "not-run";
  const detailProtected = input.protectedDetail === true ||
    properties["content.essentialDetail"] === true ||
    properties["motion.protectedDetail"] === true;
  const includesStabilization = input.kind === "stabilization" || input.kind === "both";
  const includesBlur = input.kind === "motion-blur" || input.kind === "both";
  const reasonCodes: MotionTreatmentPreflight["reasonCodes"] = [];
  const reasons: string[] = [];
  if (includesStabilization && observedIntent === "intentional") {
    reasonCodes.push("intentional-motion-protected");
    reasons.push("Stabilization was not proposed because this clip is marked as intentional camera motion.");
  }
  if (analysisStatus === "insufficient") {
    reasonCodes.push("motion-analysis-insufficient");
    reasons.push("Motion treatment was not proposed because the measured camera-motion signal is insufficient or unreliable.");
  }
  if ((includesStabilization || includesBlur) && (observedLevel === "static" || observedLevel === "low")) {
    reasonCodes.push("insufficient-motion");
    reasons.push("Motion treatment was not proposed because the clip is measured or marked as static or low-motion.");
  }
  if (includesBlur && detailProtected) {
    reasonCodes.push("essential-detail-protected");
    reasons.push("Motion blur was not proposed because the clip contains protected text, identity, or product detail.");
  }
  return {
    version: ATTELIER_MOTION_TREATMENT_PREFLIGHT_VERSION,
    status: reasonCodes.length > 0 ? "needs-action" : "allowed",
    kind: input.kind,
    observations: {
      motionIntent: observedIntent,
      motionLevel: observedLevel,
      protectedDetail: detailProtected,
      analysisStatus,
    },
    reasonCodes,
    reasons,
    limitations: [
      analysisStatus === "not-run"
        ? "Automatic camera-motion analysis was not available; only explicit project annotations were checked."
        : "Camera motion was measured from one bounded representative window; the entire clip was not scanned.",
      "Protected-detail detection is not OCR or face/product recognition.",
    ],
    requiresEncodedProof: true,
  };
};
