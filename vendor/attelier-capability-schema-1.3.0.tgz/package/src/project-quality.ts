import type { Project, TimelineElement } from "@attelier/project-schema";
import { readElementTransition, ticksToSeconds } from "@attelier/project-schema";
import type { ColorAnalysisArtifact } from "@attelier/analysis-schema";
import { colorDistance, isColorMismatch, type ColorMeasurement } from "@attelier/capability-schema/color-matching";

export const QUALITY_PROFILE_IDS = ["general-video-v1", "social-video-v1", "product-ad-v1", "talking-head-v1", "documentary-v1"] as const;
export type QualityProfileId = typeof QUALITY_PROFILE_IDS[number];

/** Normalized-fraction rectangle a text layer must stay inside. */
export type SafeAreaRect = { left: number; right: number; top: number; bottom: number };

export type QualityProfileSpec = {
  id: QualityProfileId;
  label: string;
  /** Bound on the authored `transform.position` anchor of a text layer. */
  anchor: SafeAreaRect;
  /** Bound on the estimated rendered bounds of a text layer. */
  bounds: SafeAreaRect;
  /** Ad-claim proof gates (CTA required, claim bound to a shot, readable-overlay contract). */
  adClaimGates: boolean;
  /** Severity for a still with no authored motion; documentary tolerates held frames. */
  stillMotionSeverity: QualitySeverity;
  /** Loudness step between neighbouring dialogue clips that reads as a level jump. */
  dialogueLevelJumpDb: number;
  /** Whether a cut authored across a spoken word is reported. */
  midWordCutWarnings: boolean;
};

const SOCIAL_ANCHOR: SafeAreaRect = { left: 0.06, right: 0.88, top: 0.13, bottom: 0.78 };
const SOCIAL_BOUNDS: SafeAreaRect = { left: 0.06, right: 0.94, top: 0.1, bottom: 0.8 };
/** 16:9 broadcast-style safe area: 5% on every edge, so a lower third sits legally
 * in the bottom third instead of colliding with a social interaction band. */
const DOCUMENTARY_SAFE: SafeAreaRect = { left: 0.05, right: 0.95, top: 0.05, bottom: 0.95 };

const defaultProfileSpec = (id: QualityProfileId, label: string, adClaimGates: boolean): QualityProfileSpec => ({
  id,
  label,
  anchor: SOCIAL_ANCHOR,
  bounds: SOCIAL_BOUNDS,
  adClaimGates,
  stillMotionSeverity: "minor",
  dialogueLevelJumpDb: 4,
  midWordCutWarnings: false,
});

export const QUALITY_PROFILE_SPECS: Readonly<Record<QualityProfileId, QualityProfileSpec>> = {
  "general-video-v1": defaultProfileSpec("general-video-v1", "General video", false),
  "social-video-v1": defaultProfileSpec("social-video-v1", "Social video", false),
  "product-ad-v1": defaultProfileSpec("product-ad-v1", "Product ad", true),
  "talking-head-v1": defaultProfileSpec("talking-head-v1", "Talking head", false),
  "documentary-v1": {
    id: "documentary-v1",
    label: "Documentary / launch film",
    anchor: DOCUMENTARY_SAFE,
    bounds: DOCUMENTARY_SAFE,
    adClaimGates: false,
    // A documentary holds on stills, archive frames and a locked-off interview.
    stillMotionSeverity: "info",
    dialogueLevelJumpDb: 3,
    midWordCutWarnings: true,
  },
};

export const qualityProfileSpec = (profile: QualityProfileId): QualityProfileSpec =>
  QUALITY_PROFILE_SPECS[profile];
export type QualitySeverity = "critical" | "major" | "minor" | "info";
export type QualityOwner = "planning" | "asset-generation" | "asset-selection" | "editing" | "audio" | "render" | "editor-ui" | "unknown";

export type QualityIssue = {
  id: string;
  category: "technical" | "safe-area" | "text" | "audio" | "motion" | "transition" | "color" | "brand";
  severity: QualitySeverity;
  owner: QualityOwner;
  message: string;
  elementId?: string;
  startSeconds?: number;
  autoFix?: string;
};

export type QualityReport = {
  /** Deterministic project integrity, never a perceptual final-video score. */
  scoreKind: "integrity";
  profile: QualityProfileId;
  passedGates: boolean;
  score: number;
  durationSeconds: number;
  issues: QualityIssue[];
  summary: Record<QualitySeverity, number>;
};

export type ProjectQualityEvidence = {
  colorAnalysisForAsset?: (assetId: string) => ColorAnalysisArtifact | undefined;
};

const visual = (element: TimelineElement) => element.kind === "video" || element.kind === "image";
const text = (element: TimelineElement) => element.kind === "text" || element.kind === "caption";
const audioRole = (element: TimelineElement): string =>
  typeof element.properties["audio.role"] === "string" ? String(element.properties["audio.role"]) : "";

const normalizedCopy = (value: unknown): string => String(value ?? "")
  .normalize("NFKD")
  .replace(/[\u0300-\u036f]/g, "")
  .toLocaleLowerCase("en")
  .replace(/[^a-z0-9]+/g, " ")
  .trim();

const finiteNumber = (value: unknown): number | undefined =>
  typeof value === "number" && Number.isFinite(value) ? value : undefined;

const qualityOwner = (issue: Omit<QualityIssue, "owner">): QualityOwner => {
  if (issue.id.startsWith("audio.voice-") || issue.id.startsWith("audio.dialogue-")) return "audio";
  if (issue.id.startsWith("brand.voice-copy") || issue.id.startsWith("brand.claim-without-shot") || issue.id.startsWith("brand.required-beat")) return "planning";
  if (issue.id.startsWith("composition.subject")) return "asset-selection";
  if (issue.id.startsWith("brand.generated-")) return "asset-generation";
  if (issue.category === "audio") return "audio";
  if (issue.category === "technical") return "render";
  if (issue.category === "safe-area" || issue.category === "text") return "editor-ui";
  if (issue.category === "transition" || issue.category === "motion" || issue.category === "color") return "editing";
  if (issue.category === "brand") return "planning";
  return "unknown";
};

/**
 * Deterministic L2 project evaluation. This catches technical/editorial issues
 * and emits actionable locations; it is not a perceptual or human quality verdict.
 */
export const evaluateProjectQuality = (
  project: Project,
  profile: QualityProfileId = "general-video-v1",
  evidence: ProjectQualityEvidence = {},
): QualityReport => {
  const sequence = project.sequences.find(({ id }) => id === project.activeSequenceId);
  const spec = qualityProfileSpec(profile);
  const issues: Array<Omit<QualityIssue, "owner">> = [];
  if (!sequence) {
    issues.push({ id: "technical.no-sequence", category: "technical", severity: "critical", message: "The project has no active sequence." });
  }
  const elements = sequence?.tracks.flatMap((track) => track.hidden || track.muted ? [] : track.elements) ?? [];
  const durationSeconds = Math.max(0, ...elements.map((element) =>
    ticksToSeconds(element.timelineRange.start) + ticksToSeconds(element.timelineRange.duration)));
  const visualElements = elements.filter(visual);
  const textElements = elements.filter(text);
  const audioElements = elements.filter((element) => element.kind === "audio" || element.kind === "video");

  for (const track of sequence?.tracks.filter((candidate) => !candidate.hidden && !candidate.muted) ?? []) {
    const ordered = [...track.elements].sort((left, right) =>
      Number(left.timelineRange.start) - Number(right.timelineRange.start));
    for (let index = 1; index < ordered.length; index += 1) {
      const previous = ordered[index - 1]!;
      const current = ordered[index]!;
      const previousEnd = ticksToSeconds(previous.timelineRange.start) + ticksToSeconds(previous.timelineRange.duration);
      const currentStart = ticksToSeconds(current.timelineRange.start);
      const overlap = previousEnd - currentStart;
      if (overlap <= 0.001) continue;
      const transition = readElementTransition(current, "in");
      const authoredTransition = transition?.peerElementId === previous.id &&
        Math.abs(transition.durationSeconds - overlap) <= 1 / 24;
      const splitKind = current.properties["edit.split.kind"];
      const authoredSplit = (splitKind === "j-cut" || splitKind === "l-cut") &&
        current.properties["edit.split.peerElementId"] === previous.id &&
        Math.abs(Number(current.properties["edit.split.durationSeconds"]) - overlap) <= 1 / 24;
      if (!authoredTransition && !authoredSplit) {
        issues.push({
          id: `transition.accidental-overlap.${current.id}`,
          category: "transition",
          severity: "major",
          message: `“${current.name}” overlaps “${previous.name}” without an authored transition or split edit.`,
          elementId: current.id,
          startSeconds: currentStart,
        });
      }
    }
  }

  if (durationSeconds <= 0) {
    issues.push({ id: "technical.empty", category: "technical", severity: "critical", message: "The sequence is empty or has zero duration." });
  }
  if (visualElements.length === 0) {
    issues.push({ id: "technical.no-visual", category: "technical", severity: "critical", message: "The sequence has no visual media." });
  }
  if (sequence && visualElements.length > 0) {
    const frameSeconds = sequence.frameRate.denominator / sequence.frameRate.numerator;
    const coverageTolerance = Math.max(0.001, frameSeconds * 1.25);
    const ranges = visualElements
      .map((element) => ({
        element,
        start: ticksToSeconds(element.timelineRange.start),
        end: ticksToSeconds(element.timelineRange.start) + ticksToSeconds(element.timelineRange.duration),
      }))
      .filter(({ end, start }) => end > start)
      .sort((left, right) => left.start - right.start || right.end - left.end);
    let coveredUntil = 0;
    for (const range of ranges) {
      if (range.start > coveredUntil + coverageTolerance) {
        issues.push({
          id: `technical.visual-gap.${range.element.id}`,
          category: "technical",
          severity: "critical",
          message: `No visual layer covers ${(range.start - coveredUntil).toFixed(1)}s between ${coveredUntil.toFixed(1)}s and ${range.start.toFixed(1)}s.`,
          elementId: range.element.id,
          startSeconds: coveredUntil,
        });
      }
      coveredUntil = Math.max(coveredUntil, range.end);
    }
    if (durationSeconds > coveredUntil + coverageTolerance) {
      const supportRoles = new Set(["music", "sfx", "effect", "effects", "sound_effect", "sound-effects", "ambience", "ambient", "room-tone"]);
      const tailElements = elements.filter((element) =>
        ticksToSeconds(element.timelineRange.start) + ticksToSeconds(element.timelineRange.duration) > coveredUntil + coverageTolerance);
      const supportAudioOnly = tailElements.length > 0 && tailElements.every((element) =>
        element.kind === "audio" && supportRoles.has(audioRole(element)));
      if (!supportAudioOnly) {
        issues.push({
          id: "technical.picture-ends-early",
          category: "technical",
          severity: "critical",
          message: `Picture ends ${(durationSeconds - coveredUntil).toFixed(1)}s before the remaining timeline content.`,
          startSeconds: coveredUntil,
        });
      }
    }
  }
  if (sequence && profile === "social-video-v1" && sequence.canvas.height <= sequence.canvas.width) {
    issues.push({ id: "technical.not-vertical", category: "technical", severity: "major", message: "This delivery profile expects a vertical canvas.", autoFix: "set-canvas-9:16" });
  }

  for (const element of textElements) {
    const position = element.properties["transform.position"];
    const [x, y] = Array.isArray(position) && position.length >= 2
      ? [Number(position[0]), Number(position[1])]
      : [0.5, element.kind === "caption" ? 0.72 : 0.5];
    if (x < spec.anchor.left || x > spec.anchor.right || y < spec.anchor.top || y > spec.anchor.bottom) {
      issues.push({
        id: `safe-area.${element.id}`,
        category: "safe-area",
        severity: "major",
        message: `“${element.name}” sits outside the ${spec.label} safe area.`,
        elementId: element.id,
        startSeconds: ticksToSeconds(element.timelineRange.start),
        autoFix: "move-to-safe-area",
      });
    }
    const content = String(element.properties["text.content"] ?? element.name).trim();
    if (content.length > (element.kind === "caption" ? 84 : 126)) {
      issues.push({
        id: `text.long.${element.id}`,
        category: "text",
        severity: "minor",
        message: `“${element.name}” contains too much text for quick reading.`,
        elementId: element.id,
        startSeconds: ticksToSeconds(element.timelineRange.start),
      });
    }
    const fontSize = finiteNumber(element.properties["style.fontSize"]) ?? 72;
    const canvasWidth = sequence?.canvas.width ?? 1080;
    const canvasHeight = sequence?.canvas.height ?? 1920;
    const normalizedFontHeight = fontSize / Math.min(canvasWidth, canvasHeight);
    const estimatedLineCount = Math.max(1, Math.ceil(content.length / 28));
    const estimatedWidth = Math.min(0.86, Math.max(0.08, content.length * normalizedFontHeight * 0.52 / estimatedLineCount));
    const estimatedHeight = normalizedFontHeight * 1.25 * estimatedLineCount;
    const horizontalAnchor = element.properties["text.align"] === "left" ? 0 : 0.5;
    const left = x - estimatedWidth * horizontalAnchor;
    const right = x + estimatedWidth * (1 - horizontalAnchor);
    const top = y - estimatedHeight / 2;
    const bottom = y + estimatedHeight / 2;
    if (left < spec.bounds.left || right > spec.bounds.right || top < spec.bounds.top || bottom > spec.bounds.bottom) {
      issues.push({
        id: `text.bounds-outside-safe-area.${element.id}`,
        category: "safe-area",
        severity: profile === "product-ad-v1" ? "critical" : "major",
        message: `Rendered bounds for “${element.name}” are estimated to leave the delivery safe area.`,
        elementId: element.id,
        startSeconds: ticksToSeconds(element.timelineRange.start),
        autoFix: "move-to-safe-area",
      });
    }
  }

  for (const element of visualElements.filter(({ kind }) => kind === "image")) {
    if (!element.keyframes.some(({ path, keyframes }) => path === "transform.scale" && keyframes.length >= 2)) {
      issues.push({
        id: `motion.static.${element.id}`,
        category: "motion",
        severity: spec.stillMotionSeverity,
        message: `Still “${element.name}” has no authored motion.`,
        elementId: element.id,
        startSeconds: ticksToSeconds(element.timelineRange.start),
        autoFix: "ken-burns",
      });
    }
  }

  for (const element of visualElements) {
    const hasTransitionMetadata = typeof element.properties["transition.in.type"] === "string";
    if (hasTransitionMetadata && !readElementTransition(element, "in")) {
      issues.push({
        id: `transition.invalid.${element.id}`,
        category: "transition",
        severity: "major",
        message: `“${element.name}” has incomplete or invalid transition metadata.`,
        elementId: element.id,
        startSeconds: ticksToSeconds(element.timelineRange.start),
      });
    }
  }

  const dialogue = audioElements.filter((element) => ["dialogue", "voice", "voiceover", "dub"].includes(audioRole(element)));
  const music = audioElements.filter((element) => audioRole(element) === "music");
  const visualEndSeconds = Math.max(0, ...visualElements.map((element) =>
    ticksToSeconds(element.timelineRange.start) + ticksToSeconds(element.timelineRange.duration)));
  const supportRoles = new Set(["music", "sfx", "effect", "effects", "sound_effect", "sound-effects", "ambience", "ambient", "room-tone"]);
  for (const element of audioElements.filter((candidate) => candidate.kind === "audio" && supportRoles.has(audioRole(candidate)))) {
    const startSeconds = ticksToSeconds(element.timelineRange.start);
    const endSeconds = startSeconds + ticksToSeconds(element.timelineRange.duration);
    if (visualEndSeconds <= 0 || endSeconds <= visualEndSeconds + 0.001) continue;
    const canTrim = startSeconds < visualEndSeconds - 0.001;
    issues.push({
      id: `audio.outlasts-picture.${element.id}`,
      category: "audio",
      severity: "critical",
      message: canTrim
        ? `“${element.name}” continues ${(endSeconds - visualEndSeconds).toFixed(1)}s after the last visual frame.`
        : `“${element.name}” starts after the last visual frame.`,
      elementId: element.id,
      startSeconds,
      ...(canTrim ? { autoFix: "trim-support-to-visual-end" } : {}),
    });
  }
  if (dialogue.length > 0 && music.some((element) => element.properties["audio.ducking"] === false)) {
    issues.push({ id: "audio.music-not-ducked", category: "audio", severity: "major", message: "Music is explicitly excluded from dialogue ducking.", autoFix: "enable-ducking" });
  }
  const assetsById = new Map(project.assets.map((asset) => [asset.id, asset]));
  for (const element of dialogue) {
    const asset = element.assetId ? assetsById.get(element.assetId) : undefined;
    const assetDurationSeconds = asset?.duration ? ticksToSeconds(asset.duration) : undefined;
    const sourceStartSeconds = element.sourceRange ? ticksToSeconds(element.sourceRange.start) : 0;
    const sourceDurationSeconds = element.sourceRange ? ticksToSeconds(element.sourceRange.duration) : ticksToSeconds(element.timelineRange.duration);
    if (assetDurationSeconds !== undefined && sourceStartSeconds + sourceDurationSeconds < assetDurationSeconds - 0.08) {
      issues.push({
        id: `audio.voice-truncated.${element.id}`,
        category: "audio",
        severity: "critical",
        message: `“${element.name}” uses only ${sourceDurationSeconds.toFixed(2)}s of a ${assetDurationSeconds.toFixed(2)}s voice asset. Speech must be regenerated, retimed or given a longer shot instead of truncated.`,
        elementId: element.id,
        startSeconds: ticksToSeconds(element.timelineRange.start),
      });
    }
  }
  if (audioElements.length > 0 && !audioElements.some((element) => typeof element.properties["audio.normalizeLufs"] === "number")) {
    issues.push({ id: "audio.no-master-target", category: "audio", severity: "minor", message: "No loudness target is configured for the final mix.", autoFix: "set-social-loudness" });
  }
  /* Dialogue level jump. `get_audio_analysis` stores the measured integrated
     loudness on the element as `audio.measuredLufs`; the delivered level of a
     clip is that measurement plus its authored gain. Two neighbouring clips
     that differ by more than the profile step read as a jump in the cut. */
  const levelledDialogue = dialogue
    .map((element) => ({
      element,
      startSeconds: ticksToSeconds(element.timelineRange.start),
      lufs: finiteNumber(element.properties["audio.measuredLufs"]),
      gain: finiteNumber(element.properties["audio.gainDb"]) ?? 0,
    }))
    .filter((entry): entry is typeof entry & { lufs: number } => entry.lufs !== undefined)
    .sort((left, right) => left.startSeconds - right.startSeconds);
  for (let index = 1; index < levelledDialogue.length; index += 1) {
    const previous = levelledDialogue[index - 1]!;
    const current = levelledDialogue[index]!;
    const step = Math.abs((current.lufs + current.gain) - (previous.lufs + previous.gain));
    if (step <= spec.dialogueLevelJumpDb) continue;
    issues.push({
      id: `audio.dialogue-level-jump.${current.element.id}`,
      category: "audio",
      severity: "major",
      message: `Dialogue steps ${step.toFixed(1)} dB between “${previous.element.name}” and “${current.element.name}”. Set audio.gainDb per clip so every voice lands on the same bed.`,
      elementId: current.element.id,
      startSeconds: current.startSeconds,
      autoFix: "level-dialogue-to-bed",
    });
  }
  if (spec.midWordCutWarnings) {
    /* Word-boundary evidence is authored by the transcript-driven trim; an
       element explicitly marked as cutting inside a word is a report, not a guess. */
    for (const element of elements) {
      for (const edge of ["in", "out"] as const) {
        if (element.properties[`edit.boundary.${edge}.midWord`] !== true) continue;
        issues.push({
          id: `audio.dialogue-mid-word-cut.${edge}.${element.id}`,
          category: "audio",
          severity: "major",
          message: `The ${edge} point of “${element.name}” lands inside a spoken word. Move it to the word boundary from get_transcript and keep a 120 ms handle.`,
          elementId: element.id,
          startSeconds: ticksToSeconds(element.timelineRange.start),
        });
      }
    }
  }
  if (visualElements.length > 1 && !visualElements.some((element) => typeof element.properties["plan.look"] === "string" || typeof element.properties["color.look"] === "string")) {
    issues.push({ id: "color.no-shared-look", category: "color", severity: "info", message: "Multiple visual sources have no shared finishing look.", autoFix: "apply-look" });
  }
  if (evidence.colorAnalysisForAsset) {
    const measuredVisuals = visualElements
      .map((element) => {
        const measured = element.assetId ? evidence.colorAnalysisForAsset!(element.assetId) : undefined;
        if (!measured) return undefined;
        const corrected: ColorMeasurement = {
          meanY: Math.max(0, Math.min(1, measured.meanY + (finiteNumber(element.properties["color.exposure"]) ?? 0))),
          percentile10Y: Math.max(0, Math.min(1, measured.percentile10Y + (finiteNumber(element.properties["color.exposure"]) ?? 0))),
          percentile90Y: Math.max(0, Math.min(1, measured.percentile90Y + (finiteNumber(element.properties["color.exposure"]) ?? 0))),
          meanCbOffset: measured.meanCbOffset + (finiteNumber(element.properties["color.temperatureShift"]) ?? 0),
          meanCrOffset: measured.meanCrOffset + (finiteNumber(element.properties["color.tintShift"]) ?? 0),
          saturation: measured.saturation * (finiteNumber(element.properties["color.saturation"]) ?? 1),
        };
        return { element, measured: corrected, start: ticksToSeconds(element.timelineRange.start) };
      })
      .filter((entry): entry is NonNullable<typeof entry> => entry !== undefined)
      .sort((left, right) => left.start - right.start);
    for (let index = 1; index < measuredVisuals.length; index += 1) {
      const previous = measuredVisuals[index - 1]!;
      const current = measuredVisuals[index]!;
      if (!isColorMismatch(previous.measured, current.measured)) continue;
      const distance = colorDistance(previous.measured, current.measured);
      issues.push({
        id: `color_mismatch.${current.element.id}`,
        category: "color",
        // A documentary commonly cuts between intentionally different places,
        // times and lighting conditions. Keep the measurement visible for a
        // colorist, but do not score scene contrast as an integrity defect.
        severity: profile === "documentary-v1" ? "info" : "minor",
        message: `Measured color mismatch from “${previous.element.name}” to “${current.element.name}” (distance ${distance.distance.toFixed(3)}, ΔY ${distance.meanYDelta.toFixed(3)}, ΔCb ${distance.cbOffsetDelta.toFixed(3)}, ΔCr ${distance.crOffsetDelta.toFixed(3)}). Use match_clip_color with ${current.element.id} as target and ${previous.element.id} as reference.`,
        elementId: current.element.id,
        startSeconds: current.start,
        autoFix: "match_clip_color",
      });
    }
  }
  if (spec.adClaimGates) {
    if (textElements.length === 0) {
      issues.push({ id: "brand.no-message", category: "brand", severity: "major", message: "The product-ad profile has no authored headline or call to action." });
    }
    const textRoles = new Set(textElements.map((element) => element.properties["text.role"]));
    if (!textRoles.has("cta")) {
      issues.push({ id: "brand.no-cta", category: "brand", severity: "major", message: "The product ad has no editable CTA layer." });
    }
    const assetsById = new Map(project.assets.map((asset) => [asset.id, asset]));
    for (const element of visualElements) {
      const asset = element.assetId ? assetsById.get(element.assetId) : undefined;
      const scale = finiteNumber(element.properties["transform.scale"]) ?? 1;
      const fullFrame = scale >= 0.5;
      const startSeconds = ticksToSeconds(element.timelineRange.start);
      const duration = ticksToSeconds(element.timelineRange.duration);
      if (fullFrame && duration < 1.25) {
        issues.push({
          id: `motion.flash-shot.${element.id}`,
          category: "motion",
          severity: "major",
          message: `“${element.name}” lasts only ${duration.toFixed(2)}s; this is too brief for a readable product-ad beat unless explicitly marked intentional.`,
          elementId: element.id,
          startSeconds,
        });
      }
      if (!asset || !fullFrame) continue;
      if (!asset.width || !asset.height) {
        issues.push({
          id: `technical.visual-dimensions-missing.${element.id}`,
          category: "technical",
          severity: "major",
          message: `Full-frame visual “${element.name}” has no source dimensions, so resolution and canvas coverage cannot be validated.`,
          elementId: element.id,
          startSeconds,
        });
        continue;
      }
      if (asset.width < 480 || asset.height < 270 || asset.width * asset.height < 230_400) {
        issues.push({
          id: `technical.visual-resolution.${element.id}`,
          category: "technical",
          severity: "critical",
          message: `Full-frame visual “${element.name}” is only ${asset.width}×${asset.height}; it is not suitable for a commercial master.`,
          elementId: element.id,
          startSeconds,
        });
      }
      const fit = element.properties["transform.fit"] === "cover" ? "cover" : "contain";
      const canvasAspect = sequence!.canvas.width / sequence!.canvas.height;
      const assetAspect = asset.width / asset.height;
      const containCoverage = assetAspect > canvasAspect ? canvasAspect / assetAspect : assetAspect / canvasAspect;
      const hasDesignedBackground = visualElements.some((background) => {
        if (background.id === element.id || background.properties["transform.fit"] !== "cover") return false;
        const backgroundScale = finiteNumber(background.properties["transform.scale"]) ?? 1;
        if (backgroundScale < 0.5) return false;
        const backgroundStart = ticksToSeconds(background.timelineRange.start);
        const backgroundEnd = backgroundStart + ticksToSeconds(background.timelineRange.duration);
        return backgroundStart <= startSeconds && backgroundEnd >= startSeconds + duration;
      });
      if (fit === "contain" && containCoverage * scale * scale < 0.72 && !hasDesignedBackground) {
        issues.push({
          id: `safe-area.empty-canvas.${element.id}`,
          category: "safe-area",
          severity: "critical",
          message: `“${element.name}” fills only about ${Math.round(containCoverage * scale * scale * 100)}% of the canvas under contain; choose a safe cover/reframe or a designed background.`,
          elementId: element.id,
          startSeconds,
          autoFix: "review-cover-reframe",
        });
      }
    }
    for (const element of dialogue) {
      const asset = element.assetId ? assetsById.get(element.assetId) : undefined;
      if (asset?.provenance?.rights?.publishable === false) {
        issues.push({
          id: `audio.voice-not-publishable.${element.id}`,
          category: "audio",
          severity: "critical",
          message: `Voice “${element.name}” is explicitly marked non-publishable and cannot satisfy a product-ad delivery.`,
          elementId: element.id,
          startSeconds: ticksToSeconds(element.timelineRange.start),
        });
      }
    }
    for (const element of textElements) {
      if (element.properties["effect.text.id"] !== "atelier.text.readable-overlay") {
        issues.push({
          id: `text.no-readable-overlay.${element.id}`,
          category: "text",
          severity: "major",
          message: `“${element.name}” is not bound to the readable-overlay effect contract.`,
          elementId: element.id,
          startSeconds: ticksToSeconds(element.timelineRange.start),
        });
      }
    }
    const generatedAssets = visualElements
      .map((element) => project.assets.find((asset) => asset.id === element.assetId))
      .filter((asset) => asset?.provenance?.origin === "generated");
    if (generatedAssets.some((asset) => asset?.provenance?.settings?.includeText === true)) {
      issues.push({ id: "brand.generated-copy-baked", category: "brand", severity: "major", message: "Generated Product Ad imagery contains provider-authored text instead of editable copy." });
    }
    const styleSeeds = new Set(generatedAssets.map((asset) => asset?.provenance?.settings?.styleSeed).filter((value): value is string => typeof value === "string"));
    if (styleSeeds.size > 1) {
      issues.push({ id: "brand.generated-style-drift", category: "brand", severity: "major", message: "Generated Product Ad shots do not share one style seed." });
    }
    const palettes = new Set(generatedAssets.map((asset) => asset?.provenance?.settings?.palette).filter(Array.isArray).map((value) => JSON.stringify(value)));
    if (palettes.size > 1) {
      issues.push({ id: "brand.generated-palette-drift", category: "brand", severity: "major", message: "Generated Product Ad shots do not share one palette." });
    }

    const managedProductAd = elements.some((element) => typeof element.properties["product.shotId"] === "string");
    if (managedProductAd) {
      const visualsByShot = new Map<string, TimelineElement>();
      for (const element of visualElements) {
        const shotId = element.properties["product.shotId"];
        if (typeof shotId === "string" && shotId) visualsByShot.set(shotId, element);
        const subjectKind = element.properties["composition.subjectKind"];
        const bounds = element.properties["composition.subjectBounds"];
        if ((subjectKind === "product" || subjectKind === "face") && Array.isArray(bounds) && bounds.length === 4) {
          const [left, top, right, bottom] = bounds.map(Number) as [number, number, number, number];
          const valid = [left, top, right, bottom].every(Number.isFinite) && left >= 0.03 && top >= 0.03 && right <= 0.97 && bottom <= 0.88 && right - left >= 0.14 && bottom - top >= 0.14;
          if (!valid) {
            issues.push({
              id: `composition.subject-unsafe.${element.id}`,
              category: "safe-area",
              severity: "critical",
              message: `The measured ${subjectKind} bounds for “${element.name}” are cropped, platform-obscured or too small to carry the beat.`,
              elementId: element.id,
              startSeconds: ticksToSeconds(element.timelineRange.start),
            });
          }
        } else if (element.properties["composition.requiresSubjectEvidence"] === true) {
          issues.push({
            id: `composition.subject-evidence-missing.${element.id}`,
            category: "safe-area",
            severity: "critical",
            message: `“${element.name}” requires measured product/face bounds before Product Ad export.`,
            elementId: element.id,
            startSeconds: ticksToSeconds(element.timelineRange.start),
          });
        }
      }

      for (const element of textElements) {
        const role = String(element.properties["text.role"] ?? "");
        if (!["headline", "proof", "cta"].includes(role)) continue;
        const shotId = element.properties["product.shotId"];
        if (typeof shotId !== "string" || !visualsByShot.has(shotId)) {
          issues.push({
            id: `brand.claim-without-shot.${element.id}`,
            category: "brand",
            severity: "critical",
            message: `“${element.name}” has no linked visual evidence beat.`,
            elementId: element.id,
            startSeconds: ticksToSeconds(element.timelineRange.start),
          });
        }
      }

      const identityLockedVisuals = visualElements.filter((element) => element.properties["product.identityLockRequired"] === true);
      if (identityLockedVisuals.length > 1) {
        const references = new Set(identityLockedVisuals.map((element) => element.properties["product.identityReferenceAssetId"])
          .filter((value): value is string => typeof value === "string" && value.length > 0));
        const referenceId = references.size === 1 ? [...references][0] : undefined;
        const lineageBroken = !referenceId || identityLockedVisuals.some((element) => {
          if (!element.assetId) return true;
          if (element.assetId === referenceId) return false;
          const asset = assetsById.get(element.assetId);
          return !asset?.provenance?.referenceAssetIds?.includes(referenceId);
        });
        if (lineageBroken) {
          issues.push({
            id: "brand.product-identity-lineage",
            category: "brand",
            severity: "critical",
            message: "Identity-locked product beats do not all derive from one auditable reference asset.",
          });
        }
      }

      for (const element of dialogue) {
        if (element.properties["voice.copyMatchRequired"] !== true) continue;
        const shotId = element.properties["voice.shotId"];
        const transcript = normalizedCopy(element.properties["voice.transcript"]);
        const matchingText = typeof shotId === "string" ? textElements.find((candidate) =>
          candidate.properties["product.shotId"] === shotId && candidate.properties["text.voiceMatchRequired"] === true) : undefined;
        const visibleCopy = normalizedCopy(matchingText?.properties["text.content"]);
        if (!transcript || !matchingText || transcript !== visibleCopy) {
          issues.push({
            id: `brand.voice-copy-mismatch.${element.id}`,
            category: "brand",
            severity: "critical",
            message: `Voice transcript and required on-screen copy do not match for shot ${String(shotId ?? "unknown")}.`,
            elementId: element.id,
            startSeconds: ticksToSeconds(element.timelineRange.start),
          });
        }
      }
    }
  }

  const attributedIssues: QualityIssue[] = issues.map((issue) => ({ ...issue, owner: qualityOwner(issue) }));
  // Informational recommendations remain in the itemized report but, by
  // definition, do not reduce the integrity score.
  const penalty: Record<QualitySeverity, number> = { critical: 35, major: 12, minor: 5, info: 0 };
  const score = Math.max(0, Math.round(100 - attributedIssues.reduce((sum, issue) => sum + penalty[issue.severity], 0)));
  const summary: Record<QualitySeverity, number> = { critical: 0, major: 0, minor: 0, info: 0 };
  for (const issue of attributedIssues) summary[issue.severity] += 1;
  return { scoreKind: "integrity", profile, passedGates: summary.critical === 0, score, durationSeconds, issues: attributedIssues, summary };
};
