export type AutomaticQualityEvidence = {
  technicalPassed: boolean;
  deterministicPassed: boolean;
  deterministicScore: number;
  criticalIssues: number;
  majorIssues: number;
  perceptualJudgeCount?: number;
  perceptualInvalidators?: number;
  perceptualPublishReadyVotes?: number;
};

export type AutomaticQualityTriage = {
  status: "blocked" | "proxy-clear" | "audit-worthy";
  reasons: string[];
  canClaimPublishable: false;
  claimCeiling: string;
  requiresHumanPromotionEvidence: true;
};

/**
 * Routes renders through free/automated evidence without pretending that a
 * technical or model judge establishes subjective publishability.
 */
export const triageAutomaticQuality = (evidence: AutomaticQualityEvidence): AutomaticQualityTriage => {
  const reasons: string[] = [];
  if (!evidence.technicalPassed) reasons.push("technical_qc_failed");
  if (!evidence.deterministicPassed) reasons.push("deterministic_quality_gate_failed");
  if (evidence.criticalIssues > 0) reasons.push("critical_issue_present");
  if (evidence.majorIssues > 0) reasons.push("major_issue_present");
  if (reasons.length > 0) return {
    status: "blocked",
    reasons,
    canClaimPublishable: false,
    claimCeiling: "The render is blocked by objective or contract evidence.",
    requiresHumanPromotionEvidence: true,
  };

  const judgeCount = evidence.perceptualJudgeCount ?? 0;
  const invalidators = evidence.perceptualInvalidators ?? 0;
  const readyVotes = evidence.perceptualPublishReadyVotes ?? 0;
  if (judgeCount >= 2 && invalidators === 0 && readyVotes === judgeCount) return {
    status: "audit-worthy",
    reasons: ["objective_gates_clear", "automated_perceptual_panel_agrees"],
    canClaimPublishable: false,
    claimCeiling: "Eligible for a future blinded human audit; automated agreement is not publishability evidence.",
    requiresHumanPromotionEvidence: true,
  };

  return {
    status: "proxy-clear",
    reasons: ["objective_gates_clear", judgeCount === 0 ? "no_perceptual_panel" : "perceptual_panel_insufficient_or_disagrees"],
    canClaimPublishable: false,
    claimCeiling: "Objective gates passed; subjective quality remains unknown.",
    requiresHumanPromotionEvidence: true,
  };
};
