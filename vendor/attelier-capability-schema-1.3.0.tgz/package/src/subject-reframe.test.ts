import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import type { MediaTime } from "@attelier/project-schema";
import { analyzeSubjectReframe, buildSubjectReframeOperations } from "./subject-reframe.js";

const at = (seconds: number) => String(seconds * 120_000) as MediaTime;

test("subject reframe emits smooth editable keyframes with measured coverage", () => {
  const analysis = analyzeSubjectReframe({
    source: { width: 1920, height: 1080 },
    target: "vertical",
    observations: [0, 1, 2, 3, 4].map((second, index) => ({
      at: at(second),
      detections: [{
        label: "person",
        confidence: 0.91,
        box: { x: 0.2 + index * 0.08, y: 0.18, width: 0.18, height: 0.7 },
      }],
    })),
  });
  assert.equal(analysis.status, "ready");
  assert.equal(analysis.subjectLabel, "person");
  assert.equal(analysis.metrics.detectionRatio, 1);
  assert.ok(analysis.metrics.minimumSubjectCoverage >= 0.88);
  assert.equal(analysis.treatment?.positionKeyframes.length, 5);
  assert.notDeepEqual(
    analysis.treatment?.positionKeyframes[0]?.value,
    analysis.treatment?.positionKeyframes.at(-1)?.value,
  );
  const operations = buildSubjectReframeOperations({ sequenceId: "sequence", elementId: "clip", analysis });
  assert.equal(operations[0]?.type, "setSequenceCanvas");
  assert.equal(operations.filter(({ type }) => type === "addKeyframe").length, 5);
  assert.ok(operations.some((operation) => operation.type === "setProperty" && operation.path === "capability.subjectReframe.minimumCoverage"));
});

test("subject reframe fails closed instead of substituting an unmeasured center crop", () => {
  const analysis = analyzeSubjectReframe({
    source: { width: 1920, height: 1080 },
    target: "vertical",
    observations: [0, 1, 2, 3, 4].map((second, index) => ({
      at: at(second),
      detections: index === 2
        ? [{ label: "person", confidence: 0.45, box: { x: 0.4, y: 0.2, width: 0.2, height: 0.7 } }]
        : [],
    })),
  });
  assert.equal(analysis.status, "needs-action");
  assert.equal(analysis.treatment, undefined);
  assert.deepEqual(buildSubjectReframeOperations({ sequenceId: "sequence", elementId: "clip", analysis }), []);
  assert.match(analysis.reasons.join(" "), /kept the original framing/i);
});

test("the public subject-reframe benchmark passes every ready and fail-closed contract case", () => {
  const dataset = JSON.parse(readFileSync(fileURLToPath(new URL("../../../tests/fixtures/benchmarks/datasets/subject-reframe.v1.json", import.meta.url)), "utf8")) as {
    cases: Array<{
      id: string;
      source: { width: number; height: number };
      target: "vertical" | "square" | "landscape";
      observations: Array<{ second: number; detections: Parameters<typeof analyzeSubjectReframe>[0]["observations"][number]["detections"] }>;
      expected: { status: "ready" | "needs-action"; minimumSubjectCoverage?: number; maximumCenterJump?: number };
    }>;
  };
  assert.equal(dataset.cases.length, 5);
  for (const fixture of dataset.cases) {
    const analysis = analyzeSubjectReframe({
      source: fixture.source,
      target: fixture.target,
      observations: fixture.observations.map(({ second, detections }) => ({ at: at(second), detections })),
    });
    assert.equal(analysis.status, fixture.expected.status, fixture.id);
    if (fixture.expected.minimumSubjectCoverage !== undefined) assert.ok(analysis.metrics.minimumSubjectCoverage >= fixture.expected.minimumSubjectCoverage, fixture.id);
    if (fixture.expected.maximumCenterJump !== undefined) assert.ok(analysis.metrics.maximumCenterJump <= fixture.expected.maximumCenterJump, fixture.id);
  }
});

test("the encoded presenter fixture is content-addressed, synthetic and bounded to technical evaluation", () => {
  const manifestUrl = new URL("../../../tests/fixtures/benchmarks/assets/subject-reframe-presenter.v1/manifest.json", import.meta.url);
  const manifest = JSON.parse(readFileSync(fileURLToPath(manifestUrl), "utf8")) as {
    schemaVersion: number;
    id: string;
    asset: { path: string; sha256: string; byteSize: number; width: number; height: number };
    rights: { origin: string; identity: string; publishable: boolean };
    evaluationScope: string;
  };
  assert.equal(manifest.schemaVersion, 1);
  assert.equal(manifest.id, "subject-reframe-presenter.v1");
  assert.equal(manifest.rights.origin, "generated");
  assert.equal(manifest.rights.identity, "fictional");
  assert.equal(manifest.rights.publishable, false);
  assert.match(manifest.evaluationScope, /not human or perceptual evidence/);
  assert.ok(manifest.asset.width > manifest.asset.height);
  const bytes = readFileSync(fileURLToPath(new URL(manifest.asset.path, manifestUrl)));
  assert.equal(bytes.length, manifest.asset.byteSize);
  assert.equal(createHash("sha256").update(bytes).digest("hex"), manifest.asset.sha256);
});
