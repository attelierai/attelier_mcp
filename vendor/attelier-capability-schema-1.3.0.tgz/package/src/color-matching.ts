import type { ColorAnalysisArtifact } from "@attelier/analysis-schema";

export const COLOR_MEAN_Y_MISMATCH = 12 / 255;
export const COLOR_CHROMA_MISMATCH = 6 / 255;

export type ColorMeasurement = Pick<ColorAnalysisArtifact,
  "meanY" | "percentile10Y" | "percentile90Y" | "meanCbOffset" | "meanCrOffset" | "saturation"
>;

export type ColorDistance = {
  distance: number;
  meanYDelta: number;
  cbOffsetDelta: number;
  crOffsetDelta: number;
  saturationDelta: number;
};

export type MeasuredColorCorrection = {
  exposure: number;
  temperatureShift: number;
  tintShift: number;
  saturation: number;
  before: ColorDistance;
  after: ColorDistance;
};

const clamp = (value: number, minimum: number, maximum: number): number =>
  Math.max(minimum, Math.min(maximum, value));
const rounded = (value: number): number => Number(value.toFixed(8));

export const colorDistance = (left: ColorMeasurement, right: ColorMeasurement): ColorDistance => {
  const meanYDelta = Math.abs(left.meanY - right.meanY);
  const cbOffsetDelta = Math.abs(left.meanCbOffset - right.meanCbOffset);
  const crOffsetDelta = Math.abs(left.meanCrOffset - right.meanCrOffset);
  const saturationDelta = Math.abs(left.saturation - right.saturation);
  return {
    distance: rounded(Math.hypot(meanYDelta, cbOffsetDelta, crOffsetDelta, saturationDelta)),
    meanYDelta: rounded(meanYDelta),
    cbOffsetDelta: rounded(cbOffsetDelta),
    crOffsetDelta: rounded(crOffsetDelta),
    saturationDelta: rounded(saturationDelta),
  };
};

export const isColorMismatch = (left: ColorMeasurement, right: ColorMeasurement): boolean => {
  const distance = colorDistance(left, right);
  return distance.meanYDelta > COLOR_MEAN_Y_MISMATCH
    || distance.cbOffsetDelta > COLOR_CHROMA_MISMATCH
    || distance.crOffsetDelta > COLOR_CHROMA_MISMATCH;
};

/** Derive a bounded correction and its predicted measured result. Strength is
 * linear, so zero is identity and one targets the reference until a renderer
 * safety clamp is reached. */
export const computeMeasuredColorCorrection = (
  target: ColorMeasurement,
  reference: ColorMeasurement,
  strength = 0.8,
): MeasuredColorCorrection => {
  if (!Number.isFinite(strength) || strength < 0 || strength > 1) {
    throw new Error("Color-match strength must be between 0 and 1.");
  }
  const exposure = clamp((reference.meanY - target.meanY) * strength, -0.2, 0.2);
  const temperatureShift = clamp((reference.meanCbOffset - target.meanCbOffset) * strength, -0.12, 0.12);
  const tintShift = clamp((reference.meanCrOffset - target.meanCrOffset) * strength, -0.12, 0.12);
  const fullSaturationRatio = target.saturation > 1 / 255
    ? reference.saturation / target.saturation
    : reference.saturation <= 1 / 255 ? 1 : 2;
  const saturation = clamp(1 + (fullSaturationRatio - 1) * strength, 0.5, 2);
  const predicted: ColorMeasurement = {
    meanY: clamp(target.meanY + exposure, 0, 1),
    percentile10Y: clamp(target.percentile10Y + exposure, 0, 1),
    percentile90Y: clamp(target.percentile90Y + exposure, 0, 1),
    meanCbOffset: clamp(target.meanCbOffset + temperatureShift, -0.5, 0.5),
    meanCrOffset: clamp(target.meanCrOffset + tintShift, -0.5, 0.5),
    saturation: clamp(target.saturation * saturation, 0, Math.SQRT1_2),
  };
  return {
    exposure: rounded(exposure),
    temperatureShift: rounded(temperatureShift),
    tintShift: rounded(tintShift),
    saturation: rounded(saturation),
    before: colorDistance(target, reference),
    after: colorDistance(predicted, reference),
  };
};
