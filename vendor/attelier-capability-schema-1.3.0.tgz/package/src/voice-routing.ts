export const VOICE_PROVIDER_IDS = [
  "fish-audio-s1",
  "elevenlabs-multilingual-v2",
  "elevenlabs-flash-v2.5",
  "voice-flite-local-v1",
] as const;

export type VoiceProviderId = typeof VOICE_PROVIDER_IDS[number];

export type VoiceDirection = {
  languageTag: string;
  accent?: string;
  tone: string;
  pace: "slow" | "measured" | "conversational" | "energetic";
  naturality: "draft" | "high";
  availableSeconds: number;
  usage: "audition" | "draft" | "final";
};

export type VoiceAuditionPlan = {
  version: "atelier.voice-routing.v1";
  direction: VoiceDirection;
  sampleText: string;
  providerIds: VoiceProviderId[];
  provisionalProviderId: VoiceProviderId;
  requiresHumanSelection: boolean;
  criteria: Array<"intelligibility" | "naturality" | "accentFit" | "toneFit" | "timingFit">;
  rationale: string[];
};

export type VoiceAuditionResult = {
  providerId: VoiceProviderId;
  durationSeconds: number;
  scores: {
    intelligibility: number;
    naturality: number;
    accentFit: number;
    toneFit: number;
  };
};

const words = (text: string): string[] => text.trim().split(/\s+/).filter(Boolean);

const clampScore = (value: number): number => Math.max(1, Math.min(5, value));

export const planVoiceAudition = (
  direction: VoiceDirection,
  script: string,
): VoiceAuditionPlan => {
  const sampleText = words(script).slice(0, 14).join(" ");
  if (!sampleText) throw new Error("Voice audition requires non-empty script text.");
  if (!Number.isFinite(direction.availableSeconds) || direction.availableSeconds <= 0) {
    throw new Error("Voice audition requires a positive available duration.");
  }
  const multilingual = direction.languageTag.toLowerCase() !== "en-us" || Boolean(direction.accent?.trim());
  const finalQuality = direction.usage === "final" || direction.naturality === "high";
  const providerIds: VoiceProviderId[] = finalQuality
    ? ["elevenlabs-multilingual-v2", "fish-audio-s1"]
    : multilingual
      ? ["fish-audio-s1", "elevenlabs-flash-v2.5"]
      : ["elevenlabs-flash-v2.5", "fish-audio-s1"];
  return {
    version: "atelier.voice-routing.v1",
    direction,
    sampleText,
    providerIds,
    provisionalProviderId: providerIds[0]!,
    requiresHumanSelection: direction.usage === "audition" || finalQuality || Boolean(direction.accent?.trim()),
    criteria: ["intelligibility", "naturality", "accentFit", "toneFit", "timingFit"],
    rationale: [
      `Route for ${direction.languageTag}${direction.accent ? ` (${direction.accent})` : ""}.`,
      `${direction.tone} tone at a ${direction.pace} pace with ${direction.availableSeconds.toFixed(1)}s available.`,
      finalQuality
        ? "Final/high-naturality output compares the multilingual and expressive hosted routes."
        : "Draft output prioritizes a fast route while retaining a second provider for comparison.",
    ],
  };
};

export const selectVoiceAuditionWinner = (
  plan: VoiceAuditionPlan,
  results: VoiceAuditionResult[],
): { providerId: VoiceProviderId; score: number; margin: number; ranked: Array<{ providerId: VoiceProviderId; score: number; timingFit: number }> } => {
  const unique = new Map(results.map((result) => [result.providerId, result]));
  const missing = plan.providerIds.filter((providerId) => !unique.has(providerId));
  if (missing.length > 0) throw new Error(`Missing audition results for: ${missing.join(", ")}.`);
  const ranked = plan.providerIds.map((providerId) => {
    const result = unique.get(providerId)!;
    const overflow = Math.max(0, result.durationSeconds - plan.direction.availableSeconds);
    const timingFit = overflow <= 0.05
      ? 5
      : overflow >= 1.5
        ? 1
        : 5 - (overflow / 1.5) * 4;
    const score =
      clampScore(result.scores.intelligibility) * 0.3 +
      clampScore(result.scores.naturality) * 0.25 +
      clampScore(result.scores.accentFit) * 0.2 +
      clampScore(result.scores.toneFit) * 0.15 +
      clampScore(timingFit) * 0.1;
    return { providerId, score: Math.round(score * 100) / 100, timingFit: Math.round(timingFit * 100) / 100 };
  }).sort((left, right) => right.score - left.score || plan.providerIds.indexOf(left.providerId) - plan.providerIds.indexOf(right.providerId));
  return {
    providerId: ranked[0]!.providerId,
    score: ranked[0]!.score,
    margin: Math.round((ranked[0]!.score - (ranked[1]?.score ?? ranked[0]!.score)) * 100) / 100,
    ranked,
  };
};
