/** Deterministic global-motion analysis over bounded grayscale frame windows. */

import type { MotionIntent, MotionLevel } from "./motion-treatment.js";

export const ATTELIER_MOTION_ANALYSIS_VERSION = "1.0.0" as const;

export type MotionFrameAnalysis = {
  version: typeof ATTELIER_MOTION_ANALYSIS_VERSION;
  status: "measured" | "insufficient";
  sampledFrames: number;
  dimensions: { width: number; height: number };
  metrics: {
    detailEnergy: number;
    temporalDelta: number;
    meanTranslation: number;
    rmsTranslation: number;
    pathLength: number;
    endpointTranslation: { x: number; y: number };
    endpointDistance: number;
    pathEfficiency: number;
    directionConsistency: number;
    meanMatchConfidence: number;
  };
  assessment: {
    level: MotionLevel;
    intent: MotionIntent;
    confidence: number;
    reasons: string[];
  };
  limitations: string[];
};

type Translation = {
  x: number;
  y: number;
  bestError: number;
  zeroError: number;
  confidence: number;
};

const rounded = (value: number, digits = 4): number => {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
};

const clamp = (value: number, minimum = 0, maximum = 1): number =>
  Math.max(minimum, Math.min(maximum, value));

const frameSlices = (pixels: Uint8Array, width: number, height: number): Uint8Array[] => {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 48 || height < 32) {
    throw new Error("Motion analysis requires integer frame dimensions of at least 48×32.");
  }
  const frameBytes = width * height;
  if (pixels.length < frameBytes * 3 || pixels.length % frameBytes !== 0) {
    throw new Error("Motion analysis requires at least three complete grayscale frames.");
  }
  return Array.from({ length: pixels.length / frameBytes }, (_, index) =>
    pixels.subarray(index * frameBytes, (index + 1) * frameBytes));
};

const estimateTranslation = (
  previous: Uint8Array,
  current: Uint8Array,
  width: number,
  height: number,
  radius: number,
): Translation => {
  const margin = Math.max(radius + 2, Math.ceil(Math.min(width, height) * 0.14));
  const stride = 2;
  const errorAt = (x: number, y: number): number => {
    let error = 0;
    let samples = 0;
    for (let row = margin; row < height - margin; row += stride) {
      for (let column = margin; column < width - margin; column += stride) {
        error += Math.abs(previous[row * width + column]! - current[(row + y) * width + column + x]!);
        samples += 1;
      }
    }
    return error / Math.max(1, samples);
  };
  const zeroError = errorAt(0, 0);
  let best = { x: 0, y: 0, bestError: zeroError };
  for (let y = -radius; y <= radius; y += 1) {
    for (let x = -radius; x <= radius; x += 1) {
      const bestError = errorAt(x, y);
      if (bestError < best.bestError) best = { x, y, bestError };
    }
  }
  return {
    ...best,
    zeroError,
    confidence: clamp((zeroError - best.bestError) / Math.max(1, zeroError)),
  };
};

const detailEnergy = (frames: Uint8Array[], width: number, height: number): number => {
  let total = 0;
  let samples = 0;
  for (const frame of frames) {
    for (let row = 1; row < height - 1; row += 1) {
      for (let column = 1; column < width - 1; column += 1) {
        const offset = row * width + column;
        total += Math.abs(4 * frame[offset]! - frame[offset - 1]! - frame[offset + 1]!
          - frame[offset - width]! - frame[offset + width]!);
        samples += 1;
      }
    }
  }
  return total / Math.max(1, samples);
};

const temporalDelta = (frames: Uint8Array[]): number => {
  let total = 0;
  let samples = 0;
  for (let index = 1; index < frames.length; index += 1) {
    const previous = frames[index - 1]!;
    const current = frames[index]!;
    for (let offset = 0; offset < current.length; offset += 2) {
      total += Math.abs(previous[offset]! - current[offset]!);
      samples += 1;
    }
  }
  return total / Math.max(1, samples);
};

/**
 * Measure global translation only. This intentionally does not claim optical
 * flow, subject motion, semantic text detection or stabilizer suitability.
 */
export const analyzeGrayMotionFrames = (
  pixels: Uint8Array,
  width: number,
  height: number,
): MotionFrameAnalysis => {
  const frames = frameSlices(pixels, width, height);
  const translations = frames.slice(1).map((frame, index) =>
    estimateTranslation(frames[index]!, frame, width, height, 6));
  const endpoint = estimateTranslation(frames[0]!, frames.at(-1)!, width, height, 14);
  const magnitudes = translations.map(({ x, y }) => Math.hypot(x, y));
  const pathLength = magnitudes.reduce((total, value) => total + value, 0);
  const endpointDistance = Math.hypot(endpoint.x, endpoint.y);
  const meanTranslation = magnitudes.reduce((total, value) => total + value, 0) / Math.max(1, magnitudes.length);
  const rmsTranslation = Math.sqrt(magnitudes.reduce((total, value) => total + value ** 2, 0) / Math.max(1, magnitudes.length));
  const pathEfficiency = clamp(endpointDistance / Math.max(1, pathLength));
  const movingTranslations = translations.filter(({ x, y }) => x !== 0 || y !== 0);
  const directionConsistency = endpointDistance < 1 || movingTranslations.length === 0 ? 0 :
    movingTranslations.filter(({ x, y }) => (x * endpoint.x + y * endpoint.y) / Math.max(0.0001, Math.hypot(x, y) * endpointDistance) >= 0.5).length /
      movingTranslations.length;
  const meanMatchConfidence = translations.reduce((total, item) => total + item.confidence, 0) / Math.max(1, translations.length);
  const detail = detailEnergy(frames, width, height);
  const temporal = temporalDelta(frames);

  const level: MotionLevel = temporal < 0.15 && endpointDistance < 1
    ? "static"
    : meanTranslation < 0.75
      ? "low"
      : meanTranslation < 2
        ? "moderate"
        : "high";
  const textureConfidence = clamp(detail / 2);
  const staticConfidence = level === "static" ? clamp(1 - temporal / 0.15) : 0;
  const signalConfidence = level === "static"
    ? staticConfidence
    : clamp(meanMatchConfidence * 0.65 + textureConfidence * 0.35);
  const insufficient = (level !== "static" && textureConfidence < 0.18) ||
    ((level === "moderate" || level === "high") && meanMatchConfidence < 0.04);
  let intent: MotionIntent = "unknown";
  if (!insufficient && (level === "moderate" || level === "high")) {
    if (endpointDistance >= 2 && pathEfficiency >= 0.68 && directionConsistency >= 0.7) intent = "intentional";
    else if (pathEfficiency <= 0.5 || directionConsistency <= 0.5) intent = "unintentional";
  }
  const reasons = [
    `Global motion level is ${level} (${rounded(meanTranslation)} px mean translation at ${width}×${height}).`,
    intent === "intentional"
      ? `The path is directional (${rounded(pathEfficiency)} efficiency; ${rounded(directionConsistency)} direction consistency).`
      : intent === "unintentional"
        ? `The path reverses or wanders (${rounded(pathEfficiency)} efficiency; ${rounded(directionConsistency)} direction consistency).`
        : "The sampled path does not support a reliable intentional/unintentional label.",
  ];
  if (insufficient) reasons.push("Texture or translation-match evidence is insufficient for automatic treatment selection.");

  return {
    version: ATTELIER_MOTION_ANALYSIS_VERSION,
    status: insufficient ? "insufficient" : "measured",
    sampledFrames: frames.length,
    dimensions: { width, height },
    metrics: {
      detailEnergy: rounded(detail),
      temporalDelta: rounded(temporal),
      meanTranslation: rounded(meanTranslation),
      rmsTranslation: rounded(rmsTranslation),
      pathLength: rounded(pathLength),
      endpointTranslation: { x: endpoint.x, y: endpoint.y },
      endpointDistance: rounded(endpointDistance),
      pathEfficiency: rounded(pathEfficiency),
      directionConsistency: rounded(directionConsistency),
      meanMatchConfidence: rounded(meanMatchConfidence),
    },
    assessment: {
      level,
      intent,
      confidence: rounded(signalConfidence),
      reasons,
    },
    limitations: [
      "Global translation is measured from one bounded representative window, not the entire edit.",
      "Subject motion, rolling shutter, parallax, rotation, zoom and baked text are not classified.",
      "This analysis proposes a safety annotation; encoded proof and human motion intent remain authoritative.",
    ],
  };
};
