import assert from "node:assert/strict";
import test from "node:test";
import { analyzeGrayMotionFrames } from "./motion-analysis.js";

const WIDTH = 64;
const HEIGHT = 40;

const texturedFrame = (offsetX = 0, offsetY = 0): Uint8Array => {
  const frame = new Uint8Array(WIDTH * HEIGHT);
  for (let y = 0; y < HEIGHT; y += 1) {
    for (let x = 0; x < WIDTH; x += 1) {
      const sourceX = x + offsetX;
      const sourceY = y + offsetY;
      frame[y * WIDTH + x] = (sourceX * 17 + sourceY * 29 + (sourceX % 7) * 31) % 256;
    }
  }
  return frame;
};

const packed = (offsets: Array<[number, number]>): Uint8Array => {
  const output = new Uint8Array(offsets.length * WIDTH * HEIGHT);
  offsets.forEach(([x, y], index) => output.set(texturedFrame(x, y), index * WIDTH * HEIGHT));
  return output;
};

test("motion analysis recognizes static global pixels", () => {
  const result = analyzeGrayMotionFrames(packed([[0, 0], [0, 0], [0, 0], [0, 0]]), WIDTH, HEIGHT);
  assert.equal(result.status, "measured");
  assert.equal(result.assessment.level, "static");
  assert.equal(result.assessment.intent, "unknown");
});

test("motion analysis distinguishes a directional pan from reversing jitter", () => {
  const pan = analyzeGrayMotionFrames(packed([[0, 0], [1, 0], [2, 0], [3, 0], [4, 0], [5, 0]]), WIDTH, HEIGHT);
  assert.equal(pan.assessment.intent, "intentional");
  assert.ok(pan.metrics.pathEfficiency >= 0.8);
  const jitter = analyzeGrayMotionFrames(packed([[0, 0], [3, 0], [-2, 1], [3, -1], [-3, 0], [1, 1]]), WIDTH, HEIGHT);
  assert.equal(jitter.assessment.intent, "unintentional");
  assert.ok(jitter.metrics.pathEfficiency <= 0.5);
});

test("motion analysis rejects incomplete frame buffers", () => {
  assert.throws(() => analyzeGrayMotionFrames(new Uint8Array(WIDTH * HEIGHT * 2), WIDTH, HEIGHT), /at least three/);
  assert.throws(() => analyzeGrayMotionFrames(new Uint8Array(WIDTH * HEIGHT * 3 + 1), WIDTH, HEIGHT), /complete grayscale/);
});
