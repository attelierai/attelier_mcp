import {
  TICKS_PER_SECOND,
  type MediaTime,
  type Project,
  type ProjectOperation,
  type Sequence,
  type TimelineElement,
  type Track,
} from "@attelier/project-schema";

export const ATTELIER_EDITORIAL_EDITING_VERSION = "1.0.0";

export type EditorialEditIntent =
  | { kind: "slip"; elementId: string; offsetFrames: number }
  | {
      kind: "roll";
      outgoingElementId: string;
      incomingElementId?: string;
      offsetFrames: number;
    }
  | { kind: "slide"; elementId: string; offsetFrames: number }
  | {
      kind: "ripple-trim";
      elementId: string;
      edge: "start" | "end";
      offsetFrames: number;
    };

export type EditorialEditPlan = {
  version: typeof ATTELIER_EDITORIAL_EDITING_VERSION;
  intent: EditorialEditIntent;
  frameTicks: number;
  summary: string;
  affectedElementIds: string[];
  operations: ProjectOperation[];
};

export type SourceHandleReport = {
  elementId: string;
  frameTicks: number;
  sourceStart: MediaTime;
  sourceEnd: MediaTime;
  assetDuration: MediaTime;
  headFrames: number;
  tailFrames: number;
};

export class EditorialEditError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "EditorialEditError";
  }
}

type LocatedElement = {
  sequence: Sequence;
  track: Track;
  element: TimelineElement;
  sortedIndex: number;
  sortedElements: TimelineElement[];
};

type SourceWindow = {
  start: number;
  duration: number;
  assetDuration: number;
};

const ticks = (value: number): MediaTime => String(value) as MediaTime;
const startOf = (element: TimelineElement): number => Number(element.timelineRange.start);
const durationOf = (element: TimelineElement): number => Number(element.timelineRange.duration);
const endOf = (element: TimelineElement): number => startOf(element) + durationOf(element);

const locate = (project: Project, elementId: string): LocatedElement => {
  for (const sequence of project.sequences) {
    for (const track of sequence.tracks) {
      const sortedElements = [...track.elements].sort(
        (left, right) => startOf(left) - startOf(right) || left.id.localeCompare(right.id),
      );
      const sortedIndex = sortedElements.findIndex((element) => element.id === elementId);
      if (sortedIndex >= 0) {
        return { sequence, track, element: sortedElements[sortedIndex]!, sortedIndex, sortedElements };
      }
    }
  }
  throw new EditorialEditError(`Unknown timeline element “${elementId}”.`);
};

const frameTicksFor = (sequence: Sequence): number => {
  const { numerator, denominator } = sequence.frameRate;
  if (!Number.isInteger(numerator) || !Number.isInteger(denominator) || numerator <= 0 || denominator <= 0) {
    throw new EditorialEditError(`Sequence “${sequence.name}” has an invalid frame rate.`);
  }
  return Math.max(1, Math.round((TICKS_PER_SECOND * denominator) / numerator));
};

const offsetTicks = (frames: number, frameTicks: number): number => {
  if (!Number.isInteger(frames) || frames === 0) {
    throw new EditorialEditError("offsetFrames must be a non-zero integer.");
  }
  if (Math.abs(frames) > 10_000) {
    throw new EditorialEditError("offsetFrames is outside the supported range.");
  }
  return frames * frameTicks;
};

const assertNormalSpeed = (element: TimelineElement): void => {
  const rate = element.properties["playback.rate"];
  if (rate !== undefined && (typeof rate !== "number" || Math.abs(rate - 1) > 1e-9)) {
    throw new EditorialEditError(
      `“${element.name}” is retimed. Normalize its speed before a source-handle edit.`,
    );
  }
};

const assertNoSplitAudio = (element: TimelineElement): void => {
  if (
    typeof element.properties["audio.splitElementId"] === "string" ||
    typeof element.properties["audio.splitFromElementId"] === "string"
  ) {
    throw new EditorialEditError(
      `“${element.name}” participates in a J/L split edit. Adjust its split audio before changing this cut.`,
    );
  }
};

const sourceWindow = (project: Project, element: TimelineElement): SourceWindow => {
  assertNormalSpeed(element);
  assertNoSplitAudio(element);
  if (!element.sourceRange || !element.assetId) {
    throw new EditorialEditError(`“${element.name}” has no editable source range.`);
  }
  const asset = project.assets.find((candidate) => candidate.id === element.assetId);
  if (!asset?.duration) {
    throw new EditorialEditError(`“${element.name}” has no measured source duration.`);
  }
  const window = {
    start: Number(element.sourceRange.start),
    duration: Number(element.sourceRange.duration),
    assetDuration: Number(asset.duration),
  };
  validateSourceWindow(element, window);
  return window;
};

const validateSourceWindow = (element: TimelineElement, window: SourceWindow): void => {
  if (
    !Number.isSafeInteger(window.start) ||
    !Number.isSafeInteger(window.duration) ||
    !Number.isSafeInteger(window.assetDuration) ||
    window.start < 0 ||
    window.duration <= 0 ||
    window.start + window.duration > window.assetDuration
  ) {
    throw new EditorialEditError(`“${element.name}” would exceed its available source handles.`);
  }
};

const validateTimelineDuration = (
  element: TimelineElement,
  duration: number,
  minimumDuration: number,
): void => {
  if (!Number.isSafeInteger(duration) || duration < minimumDuration) {
    throw new EditorialEditError(`“${element.name}” must retain at least one sequence frame.`);
  }
};

const trimOperation = (
  element: TimelineElement,
  timelineStart: number,
  timelineDuration: number,
  source: SourceWindow,
): ProjectOperation => ({
  type: "trimElement",
  elementId: element.id,
  timelineRange: { start: ticks(timelineStart), duration: ticks(timelineDuration) },
  sourceRange: { start: ticks(source.start), duration: ticks(source.duration) },
});

const assertTouching = (
  left: TimelineElement,
  right: TimelineElement,
): void => {
  if (endOf(left) !== startOf(right)) {
    throw new EditorialEditError(
      `“${left.name}” and “${right.name}” must share one exact cut with no gap or overlap.`,
    );
  }
};

const formatFrameOffset = (frames: number): string => `${frames > 0 ? "+" : ""}${frames}f`;

export const inspectSourceHandles = (
  project: Project,
  elementId: string,
): SourceHandleReport => {
  const located = locate(project, elementId);
  const frameTicks = frameTicksFor(located.sequence);
  const source = sourceWindow(project, located.element);
  return {
    elementId,
    frameTicks,
    sourceStart: ticks(source.start),
    sourceEnd: ticks(source.start + source.duration),
    assetDuration: ticks(source.assetDuration),
    headFrames: Math.floor(source.start / frameTicks),
    tailFrames: Math.floor((source.assetDuration - source.start - source.duration) / frameTicks),
  };
};

export const compileEditorialEdit = (
  project: Project,
  intent: EditorialEditIntent,
): EditorialEditPlan => {
  if (intent.kind === "slip") {
    const located = locate(project, intent.elementId);
    const frameTicks = frameTicksFor(located.sequence);
    const delta = offsetTicks(intent.offsetFrames, frameTicks);
    const source = sourceWindow(project, located.element);
    const nextSource = { ...source, start: source.start + delta };
    validateSourceWindow(located.element, nextSource);
    return {
      version: ATTELIER_EDITORIAL_EDITING_VERSION,
      intent,
      frameTicks,
      summary: `Slip “${located.element.name}” ${formatFrameOffset(intent.offsetFrames)} without moving it.`,
      affectedElementIds: [located.element.id],
      operations: [
        trimOperation(
          located.element,
          startOf(located.element),
          durationOf(located.element),
          nextSource,
        ),
      ],
    };
  }

  if (intent.kind === "roll") {
    const outgoing = locate(project, intent.outgoingElementId);
    const incoming = intent.incomingElementId
      ? locate(project, intent.incomingElementId)
      : (() => {
          const next = outgoing.sortedElements[outgoing.sortedIndex + 1];
          if (!next) throw new EditorialEditError(`“${outgoing.element.name}” has no following clip to roll.`);
          return locate(project, next.id);
        })();
    if (outgoing.sequence.id !== incoming.sequence.id || outgoing.track.id !== incoming.track.id) {
      throw new EditorialEditError("A roll edit requires two adjacent clips on the same track.");
    }
    if (incoming.sortedIndex !== outgoing.sortedIndex + 1) {
      throw new EditorialEditError("A roll edit requires the next adjacent clip on the same track.");
    }
    assertTouching(outgoing.element, incoming.element);
    const frameTicks = frameTicksFor(outgoing.sequence);
    const delta = offsetTicks(intent.offsetFrames, frameTicks);
    const outgoingSource = sourceWindow(project, outgoing.element);
    const incomingSource = sourceWindow(project, incoming.element);
    const nextOutgoingDuration = durationOf(outgoing.element) + delta;
    const nextIncomingDuration = durationOf(incoming.element) - delta;
    validateTimelineDuration(outgoing.element, nextOutgoingDuration, frameTicks);
    validateTimelineDuration(incoming.element, nextIncomingDuration, frameTicks);
    const nextOutgoingSource = { ...outgoingSource, duration: outgoingSource.duration + delta };
    const nextIncomingSource = {
      ...incomingSource,
      start: incomingSource.start + delta,
      duration: incomingSource.duration - delta,
    };
    validateSourceWindow(outgoing.element, nextOutgoingSource);
    validateSourceWindow(incoming.element, nextIncomingSource);
    return {
      version: ATTELIER_EDITORIAL_EDITING_VERSION,
      intent,
      frameTicks,
      summary: `Roll the cut between “${outgoing.element.name}” and “${incoming.element.name}” ${formatFrameOffset(intent.offsetFrames)}.`,
      affectedElementIds: [outgoing.element.id, incoming.element.id],
      operations: [
        trimOperation(
          outgoing.element,
          startOf(outgoing.element),
          nextOutgoingDuration,
          nextOutgoingSource,
        ),
        trimOperation(
          incoming.element,
          startOf(incoming.element) + delta,
          nextIncomingDuration,
          nextIncomingSource,
        ),
      ],
    };
  }

  if (intent.kind === "slide") {
    const selected = locate(project, intent.elementId);
    const previous = selected.sortedElements[selected.sortedIndex - 1];
    const next = selected.sortedElements[selected.sortedIndex + 1];
    if (!previous || !next) {
      throw new EditorialEditError(`“${selected.element.name}” needs touching clips before and after it to slide.`);
    }
    assertTouching(previous, selected.element);
    assertTouching(selected.element, next);
    assertNormalSpeed(selected.element);
    assertNoSplitAudio(selected.element);
    const frameTicks = frameTicksFor(selected.sequence);
    const delta = offsetTicks(intent.offsetFrames, frameTicks);
    const previousSource = sourceWindow(project, previous);
    const nextSource = sourceWindow(project, next);
    const nextPreviousDuration = durationOf(previous) + delta;
    const nextFollowingDuration = durationOf(next) - delta;
    validateTimelineDuration(previous, nextPreviousDuration, frameTicks);
    validateTimelineDuration(next, nextFollowingDuration, frameTicks);
    const extendedPreviousSource = { ...previousSource, duration: previousSource.duration + delta };
    const shiftedNextSource = {
      ...nextSource,
      start: nextSource.start + delta,
      duration: nextSource.duration - delta,
    };
    validateSourceWindow(previous, extendedPreviousSource);
    validateSourceWindow(next, shiftedNextSource);
    return {
      version: ATTELIER_EDITORIAL_EDITING_VERSION,
      intent,
      frameTicks,
      summary: `Slide “${selected.element.name}” ${formatFrameOffset(intent.offsetFrames)} while preserving sequence duration.`,
      affectedElementIds: [previous.id, selected.element.id, next.id],
      operations: [
        trimOperation(previous, startOf(previous), nextPreviousDuration, extendedPreviousSource),
        { type: "moveElement", elementId: selected.element.id, start: ticks(startOf(selected.element) + delta) },
        trimOperation(next, startOf(next) + delta, nextFollowingDuration, shiftedNextSource),
      ],
    };
  }

  const located = locate(project, intent.elementId);
  const frameTicks = frameTicksFor(located.sequence);
  const delta = offsetTicks(intent.offsetFrames, frameTicks);
  const source = sourceWindow(project, located.element);
  const nextSource = intent.edge === "start"
    ? { ...source, start: source.start + delta, duration: source.duration - delta }
    : { ...source, duration: source.duration + delta };
  const nextDuration = intent.edge === "start"
    ? durationOf(located.element) - delta
    : durationOf(located.element) + delta;
  validateTimelineDuration(located.element, nextDuration, frameTicks);
  validateSourceWindow(located.element, nextSource);
  const timelineShift = nextDuration - durationOf(located.element);
  const oldEnd = endOf(located.element);
  const later = located.sortedElements.filter((element) => startOf(element) >= oldEnd);
  return {
    version: ATTELIER_EDITORIAL_EDITING_VERSION,
    intent,
    frameTicks,
    summary: `Ripple-trim the ${intent.edge} of “${located.element.name}” ${formatFrameOffset(intent.offsetFrames)} on its track.`,
    affectedElementIds: [located.element.id, ...later.map(({ id }) => id)],
    operations: [
      trimOperation(located.element, startOf(located.element), nextDuration, nextSource),
      ...later.map((element): ProjectOperation => ({
        type: "moveElement",
        elementId: element.id,
        start: ticks(startOf(element) + timelineShift),
      })),
    ],
  };
};
