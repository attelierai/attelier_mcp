import assert from "node:assert/strict";
import test from "node:test";
import { GOLD_PROJECTS, formatQualityEvalReport, runQualityEvalSet } from "./quality-eval-set.js";
import { evaluateProjectQuality } from "./project-quality.js";

test("every gold project meets its deterministic quality baseline", () => {
  const report = runQualityEvalSet();
  // Print the report so a version-over-version diff is visible in test output.
  console.log(formatQualityEvalReport(report));
  assert.deepEqual(report.regressions, [], `gold cases regressed: ${report.regressions.join(", ")}`);
});

test("the Quality Index holds at or above the committed baseline", () => {
  const report = runQualityEvalSet();
  // Baseline captured 2026-07-29: the deterministic set sits at 100. A drop below
  // it is a regression the change must justify; raise nothing here — improvements
  // show up as new cases, not a higher ceiling.
  assert.ok(report.index >= 100, `Quality Index ${report.index} fell below baseline 100`);
});

test("the set keeps both clean and flawed cases so the index measures both directions", () => {
  assert.ok(GOLD_PROJECTS.some((c) => c.kind === "clean"), "no clean reference case");
  assert.ok(GOLD_PROJECTS.some((c) => c.kind === "flawed"), "no flawed case");
});

test("Toloka defects remain timestamped regressions and every emitted issue has an owner", () => {
  const humanRegressions = GOLD_PROJECTS.filter(({ humanEvidence }) => humanEvidence?.source === "toloka-human-quality-v1.3");
  assert.deepEqual(humanRegressions.map(({ humanEvidence }) => humanEvidence?.itemId).sort(), [
    "n2-local-cafe-v1",
    "n2-meditation-app-v1",
    "n2-running-shoes-v1",
  ]);
  assert.ok(humanRegressions.every(({ humanEvidence }) => humanEvidence!.timecodes.length > 0));
  const report = runQualityEvalSet(humanRegressions);
  assert.ok(report.cases.every(({ failures }) => failures.length === 0));
  for (const goldCase of humanRegressions) {
    const emitted = report.cases.find(({ id }) => id === goldCase.id)!;
    assert.ok(emitted.flagged.length > 0);
    assert.ok(evaluateProjectQuality(goldCase.project, goldCase.profile).issues.every(({ owner }) => owner !== "unknown"));
  }
});
