/** Provider- and renderer-independent editorial rules shared by skills and evaluators. */

export const ATTELIER_CRAFT_GUIDE_VERSION = "1.0.0";

export const DEFECT_CATEGORIES = [
  "technical",
  "visual-artifact",
  "temporal",
  "audio",
  "editorial",
  "narrative",
  "brief-brand",
  "safety",
  "rights",
] as const;

export type DefectCategory = typeof DEFECT_CATEGORIES[number];
export type CraftSeverity = "critical" | "major" | "minor" | "info";
export type CraftChapter =
  | "composition" | "continuity" | "pacing" | "editing" | "motion"
  | "typography" | "captions" | "audio" | "color" | "transitions"
  | "branding" | "formats" | "delivery";

export type CraftRule = {
  id: string;
  version: 1;
  chapter: CraftChapter;
  title: string;
  intent: string;
  goodUse: string;
  badUse: string;
  exceptions: string[];
  example: string;
  severity: CraftSeverity;
  defectCategory: DefectCategory;
  evaluation: {
    kind: "deterministic" | "signal" | "perceptual" | "human";
    signals: string[];
    criticalWhen?: string;
  };
  profiles?: Record<string, Record<string, number | string | boolean>>;
};

export const CRAFT_RULES: readonly CraftRule[] = [
  {
    id: "craft.composition.safe-area", version: 1, chapter: "composition", title: "Protect delivery safe areas",
    intent: "Keep faces, product, essential copy and calls to action clear of platform chrome and crop uncertainty.",
    goodUse: "Place essential elements inside the selected delivery profile's title/action safe region.",
    badUse: "Use one social safe-area preset for every format or place essential copy under platform controls.",
    exceptions: ["Decorative elements may bleed when no meaning is lost.", "A platform-specific approved template may define tighter zones."],
    example: "A 9:16 CTA remains inside x=0.06..0.88 and y=0.13..0.78.", severity: "major", defectCategory: "technical",
    evaluation: { kind: "deterministic", signals: ["safe_area_intersection", "essential_element_visibility"], criticalWhen: "An essential claim, price or CTA is unreadable." },
    profiles: { "social-vertical": { minX: 0.06, maxX: 0.88, minY: 0.13, maxY: 0.78 }, "general": { minX: 0.05, maxX: 0.95, minY: 0.05, maxY: 0.95 } },
  },
  {
    id: "craft.continuity.visual", version: 1, chapter: "continuity", title: "Preserve visual continuity",
    intent: "Make adjacent shots feel intentional while protecting product and identity consistency.",
    goodUse: "Match screen direction, eyeline, product appearance and lighting unless discontinuity serves the story.",
    badUse: "Cut between conflicting product colors, identities or movement directions without motivation.",
    exceptions: ["A deliberate jump cut or contrast beat may break continuity when the edit communicates why."],
    example: "The product label, color and orientation remain stable across a demo sequence.", severity: "major", defectCategory: "editorial",
    evaluation: { kind: "perceptual", signals: ["identity_consistency", "screen_direction", "shot_boundary_discontinuity"] },
  },
  {
    id: "craft.pacing.intentional", version: 1, chapter: "pacing", title: "Pace to information and emotion",
    intent: "Give every beat enough time to land while removing dead time and repetition.",
    goodUse: "Let shot duration follow information density, performance and platform intent.",
    badUse: "Apply a fixed cut interval or accelerate every section because the output is short-form.",
    exceptions: ["A deliberate hold or rapid montage is valid when its narrative purpose is clear."],
    example: "A product ad establishes its promise in 2–3 seconds, then varies shot length around demonstrations and proof.", severity: "major", defectCategory: "narrative",
    evaluation: { kind: "human", signals: ["hook_clarity", "dead_time", "information_density", "shot_duration_distribution"] },
    profiles: { "product-ad": { hookMaxSeconds: 3, ctaMinSeconds: 2 }, "talking-head": { maxUnmotivatedPauseSeconds: 0.7 } },
  },
  {
    id: "craft.editing.cuts", version: 1, chapter: "editing", title: "Cut on purpose",
    intent: "Use cuts to advance meaning, reveal information or improve performance.",
    goodUse: "Prefer a clean cut and add split edits or transitions only when they improve continuity or emphasis.",
    badUse: "Add transitions at every boundary or cut mid-word, mid-action or without usable source handles.",
    exceptions: ["Disruptive cutting is acceptable as an explicitly authored style."],
    example: "A J-cut introduces the next speaker before picture changes while preserving source sync.", severity: "major", defectCategory: "editorial",
    evaluation: { kind: "human", signals: ["cut_motivation", "performance_integrity", "source_handle_validity"] },
  },
  {
    id: "craft.motion.subtle", version: 1, chapter: "motion", title: "Use motivated, smooth motion",
    intent: "Direct attention and create energy without introducing crop errors or mechanical movement.",
    goodUse: "Use eased paths with a stable subject crop and motion appropriate to the beat.",
    badUse: "Apply identical zooms to every shot, abrupt scale changes or motion that crops the subject.",
    exceptions: ["An abrupt punch-in can punctuate a deliberate comedic or emphasis beat."],
    example: "A still moves from 1.00 to 1.08 over four seconds with ease-in-out.", severity: "minor", defectCategory: "temporal",
    evaluation: { kind: "signal", signals: ["velocity_discontinuity", "acceleration_spike", "subject_crop", "duplicate_frames"] },
  },
  {
    id: "craft.typography.readable", version: 1, chapter: "typography", title: "Keep authored text readable",
    intent: "Make headlines, claims and CTA legible at viewing distance and on a small screen.",
    goodUse: "Use concise copy, clear hierarchy, sufficient duration and contrast against the worst background frame.",
    badUse: "Rely on a single sampled frame, thin type, long paragraphs or decorative motion that delays reading.",
    exceptions: ["Non-essential atmospheric text may use lower hierarchy if it remains intentional."],
    example: "A two-line headline maintains at least 4.5:1 contrast and remains visible long enough to read.", severity: "major", defectCategory: "brief-brand",
    evaluation: { kind: "signal", signals: ["contrast_ratio", "words_per_second", "line_count", "collision_area"], criticalWhen: "An approved claim, price or CTA cannot be read." },
    profiles: { "social-vertical": { maxWordsPerSecond: 3, maxHeadlineLines: 3, minContrast: 4.5 } },
  },
  {
    id: "craft.captions.accessible", version: 1, chapter: "captions", title: "Caption speech accurately and accessibly",
    intent: "Preserve meaning, timing and speaker comprehension without covering important imagery.",
    goodUse: "Use accurate wording, readable chunks, synchronized timing and a safe, high-contrast placement.",
    badUse: "Show stale captions, excessive words, invented dialogue or captions that obscure the product.",
    exceptions: ["Intentional paraphrase is allowed only when labeled and meaning is preserved."],
    example: "One or two short lines follow speech within the approved timing tolerance.", severity: "major", defectCategory: "technical",
    evaluation: { kind: "signal", signals: ["word_error_rate", "caption_sync_ms", "words_per_second", "safe_area_intersection"] },
  },
  {
    id: "craft.audio.intelligible", version: 1, chapter: "audio", title: "Prioritize intelligibility and clean delivery",
    intent: "Make dialogue effortless to understand while retaining musical energy and natural dynamics.",
    goodUse: "Assign audio roles, clean dialogue conservatively, duck music, use fades and meet the delivery loudness profile.",
    badUse: "Hard-cut music, over-denoise speech, clip peaks or normalize every stem independently without a mix context.",
    exceptions: ["A deliberate distortion or silence is valid when authored and reviewed."],
    example: "Dialogue stays clear over music; the final social master targets -14 LUFS-I and <= -1.5 dBTP.", severity: "critical", defectCategory: "audio",
    evaluation: { kind: "signal", signals: ["lufs_i", "true_peak_dbtp", "clipping_samples", "dialogue_music_ratio", "hard_audio_cuts"], criticalWhen: "Speech is unintelligible or the delivered master clips." },
    profiles: { "social": { targetLufsI: -14, maxTruePeakDbtp: -1.5 }, "broadcast": { targetLufsI: -23, maxTruePeakDbtp: -1 } },
  },
  {
    id: "craft.color.match-before-look", version: 1, chapter: "color", title: "Match sources before the creative look",
    intent: "Create continuity across cameras and generators while protecting skin, product and brand colors.",
    goodUse: "Normalize exposure and white balance per clip, then apply one intentional creative look.",
    badUse: "Use a global grade to hide mismatched clips or clip channels to force contrast.",
    exceptions: ["A deliberate color discontinuity may separate time, location or point of view."],
    example: "Each source is matched to the hero product frame before the campaign look is applied.", severity: "major", defectCategory: "visual-artifact",
    evaluation: { kind: "signal", signals: ["reference_color_distance", "channel_clipping", "temporal_color_delta", "protected_tone_delta"] },
  },
  {
    id: "craft.transitions.sparse", version: 1, chapter: "transitions", title: "Use transitions sparingly and with handles",
    intent: "Support a change in time, mood or structure without masking weak cuts.",
    goodUse: "Default to cuts; use short dissolves or dips when the story and available handles support them.",
    badUse: "Apply a transition merely because one exists, create accidental black frames or consume invalid handles.",
    exceptions: ["A campaign may intentionally establish one repeated transition motif."],
    example: "A 6-frame dissolve bridges compatible shots with real overlap and matching audio treatment.", severity: "major", defectCategory: "temporal",
    evaluation: { kind: "deterministic", signals: ["effective_overlap", "mix_curve_error", "black_frame_count", "handle_violation"] },
  },
  {
    id: "craft.brand.truthful", version: 1, chapter: "branding", title: "Protect brand and approved claims",
    intent: "Keep identity, product appearance and commercial claims accurate and consistent.",
    goodUse: "Use only approved logos, product facts, prices and claims from the brief or brand kit.",
    badUse: "Invent benefits, redraw a logo, alter product identity or introduce an unapproved price.",
    exceptions: ["Clearly marked concept placeholders may be used before client approval but cannot be publish-ready."],
    example: "The exact supplied logo and approved CTA appear without distortion or invented claims.", severity: "critical", defectCategory: "brief-brand",
    evaluation: { kind: "human", signals: ["logo_fidelity", "product_identity", "claim_grounding", "brand_fit"], criticalWhen: "Product, logo, price or claim is wrong or invented." },
  },
  {
    id: "craft.formats.platform-fit", version: 1, chapter: "formats", title: "Author for the target format",
    intent: "Deliver the promised aspect ratio, duration and language without relying on accidental crops.",
    goodUse: "Set the canvas and delivery profile before generation and review each variant independently.",
    badUse: "Generate in one aspect and blindly crop every platform variant.",
    exceptions: ["A master may be adapted when protected framing and reframe data are available."],
    example: "A 9:16 variant is recomposed, not merely center-cropped from 16:9.", severity: "critical", defectCategory: "technical",
    evaluation: { kind: "deterministic", signals: ["aspect_ratio", "duration", "language", "codec", "reframe_subject_coverage"], criticalWhen: "The output does not match promised delivery." },
  },
  {
    id: "craft.delivery.qc", version: 1, chapter: "delivery", title: "Run post-render quality control",
    intent: "Verify the actual encoded output rather than assuming the timeline guarantees delivery quality.",
    goodUse: "Inspect black/frozen frames, silence, clipping, captions, codec, dimensions and duration after render.",
    badUse: "Call an output publish-ready based only on a successful encode or a timeline score.",
    exceptions: [],
    example: "The pinned render passes technical QC and remains linked to project revision and provenance.", severity: "critical", defectCategory: "technical",
    evaluation: { kind: "deterministic", signals: ["black_frames", "freeze_duration", "silence_duration", "clipping_samples", "caption_presence", "codec_compliance"], criticalWhen: "The output is broken, incomplete or materially differs from the approved project." },
  },
  {
    id: "craft.safety.consent", version: 1, chapter: "delivery", title: "Require consent and provenance for identity",
    intent: "Prevent unauthorized face, voice and identity manipulation and retain an auditable origin trail.",
    goodUse: "Verify scoped consent before identity-sensitive generation and attach provenance to every derivative.",
    badUse: "Infer consent from asset possession or continue generating after revocation.",
    exceptions: [],
    example: "A lip-sync job references an active consent record covering identity, purpose and expiration.", severity: "critical", defectCategory: "rights",
    evaluation: { kind: "deterministic", signals: ["consent_record", "consent_scope", "consent_expiry", "provenance_chain"], criticalWhen: "Required consent or rights evidence is absent or invalid." },
  },
] as const;

export const CRAFT_RULE_IDS = CRAFT_RULES.map(({ id }) => id);

export const validateCraftGuide = (): string[] => {
  const issues: string[] = [];
  const ids = new Set<string>();
  for (const rule of CRAFT_RULES) {
    if (ids.has(rule.id)) issues.push(`duplicate craft rule ${rule.id}`);
    ids.add(rule.id);
    if (!rule.intent || !rule.goodUse || !rule.badUse || !rule.example) issues.push(`${rule.id} is incomplete`);
    if (!DEFECT_CATEGORIES.includes(rule.defectCategory)) issues.push(`${rule.id} has an unknown defect category`);
    if (rule.evaluation.signals.length === 0) issues.push(`${rule.id} has no evaluable signal`);
  }
  const chapters = new Set(CRAFT_RULES.map(({ chapter }) => chapter));
  for (const chapter of ["composition", "continuity", "pacing", "editing", "motion", "typography", "captions", "audio", "color", "transitions", "branding", "formats", "delivery"] satisfies CraftChapter[]) {
    if (!chapters.has(chapter)) issues.push(`missing craft chapter ${chapter}`);
  }
  return issues;
};
