import assert from "node:assert/strict";
import test from "node:test";
import {
  EFFECT_GATE_SPECS,
  EFFECT_PARITY_SPECS,
  createEffectIntentKey,
  evaluateEffectContract,
  evaluatePreviewRenderParity,
  validateEffectGateSpecs,
} from "./effect-evaluation.js";

test("every effect contract has a versioned objective gate", () => {
  assert.deepEqual(validateEffectGateSpecs(), []);
  assert.equal(EFFECT_GATE_SPECS.length, 15);
  assert.equal(EFFECT_PARITY_SPECS.length, 15);
});

test("preview and render parity requires the same intent and measured signals", () => {
  const intentKey = createEffectIntentKey("atelier.transition.cross-dissolve", 1, { duration: 0.25, curve: "equal-power" });
  assert.equal(intentKey, createEffectIntentKey("atelier.transition.cross-dissolve", 1, { curve: "equal-power", duration: 0.25 }));
  const passing = evaluatePreviewRenderParity({
    effectId: "atelier.transition.cross-dissolve",
    effectVersion: 1,
    preview: { intentKey, signals: { envelopeOpacity: 0.5, timingFrames: 12 } },
    render: { intentKey, signals: { envelopeOpacity: 0.52, timingFrames: 13 } },
  });
  assert.equal(passing.status, "pass");
  assert.equal(passing.sameIntent, true);

  const wrongIntent = evaluatePreviewRenderParity({
    effectId: "atelier.transition.cross-dissolve",
    effectVersion: 1,
    preview: { intentKey, signals: { envelopeOpacity: 0.5, timingFrames: 12 } },
    render: { intentKey: `${intentKey}-changed`, signals: { envelopeOpacity: 0.5, timingFrames: 12 } },
  });
  assert.equal(wrongIntent.status, "fail");
  assert.equal(wrongIntent.sameIntent, false);

  const drifted = evaluatePreviewRenderParity({
    effectId: "atelier.transition.cross-dissolve",
    effectVersion: 1,
    preview: { intentKey, signals: { envelopeOpacity: 0.5, timingFrames: 12 } },
    render: { intentKey, signals: { envelopeOpacity: 0.6, timingFrames: 12 } },
  });
  assert.equal(drifted.status, "fail");
  assert.ok(drifted.checks.some(({ signal, passed }) => signal === "envelopeOpacity" && passed === false));
});

test("provider effects require preview and render to decode the same immutable asset", () => {
  const intentKey = createEffectIntentKey("atelier.generate.image-to-video", 1, { seed: 42, duration: 5 });
  const result = evaluatePreviewRenderParity({
    effectId: "atelier.generate.image-to-video",
    effectVersion: 1,
    preview: { intentKey, signals: { contentHash: "sha256:a" } },
    render: { intentKey, signals: { contentHash: "sha256:b" } },
  });
  assert.equal(result.status, "fail");
});

test("effect gates separate pass, objective failure and missing evidence", () => {
  const passing = evaluateEffectContract({
    effectId: "atelier.transition.cross-dissolve",
    effectVersion: 1,
    metrics: { effective_overlap: true, mix_curve_error: 0.02, black_frame_count: 0, audio_continuity: true },
  });
  assert.equal(passing.status, "pass");
  assert.equal(passing.perceptualJudgment, "not_evaluated");

  const failed = evaluateEffectContract({
    effectId: "atelier.transition.cross-dissolve",
    effectVersion: 1,
    metrics: { effective_overlap: true, mix_curve_error: 0.02, black_frame_count: 0, audio_continuity: true },
    observedCriticalFailures: ["black_frame"],
  });
  assert.equal(failed.status, "fail");

  const incomplete = evaluateEffectContract({
    effectId: "atelier.transition.cross-dissolve",
    effectVersion: 1,
    metrics: { black_frame_count: 0 },
  });
  assert.equal(incomplete.status, "incomplete");
  assert.deepEqual(incomplete.missingMetrics.sort(), ["audio_continuity", "effective_overlap", "mix_curve_error"]);
});

test("effect gates reject version drift and invented critical failures", () => {
  assert.throws(() => evaluateEffectContract({ effectId: "atelier.transition.cross-dissolve", effectVersion: 2, metrics: {} }), /requires version 1/);
  assert.throws(() => evaluateEffectContract({ effectId: "atelier.transition.cross-dissolve", effectVersion: 1, metrics: {}, observedCriticalFailures: ["looks_bad"] }), /Unknown critical failure/);
});
