/** Deterministic, provider-independent color scopes and correction proposal. */

export const ATTELIER_COLOR_ASSIST_VERSION = "1.0.0" as const;
export const COLOR_SCOPE_HISTOGRAM_BINS = 64 as const;
export const COLOR_SCOPE_VECTOR_SIZE = 32 as const;

export type ExposureAssessment = "underexposed" | "balanced" | "overexposed" | "clipped";
export type WhiteBalanceAssessment = "cool" | "balanced" | "warm";
export type TintAssessment = "green" | "balanced" | "magenta";

export type ColorScopeAnalysis = {
  version: typeof ATTELIER_COLOR_ASSIST_VERSION;
  sampledFrames: number;
  sampledPixels: number;
  scopes: {
    histogramBins: typeof COLOR_SCOPE_HISTOGRAM_BINS;
    luma: number[];
    red: number[];
    green: number[];
    blue: number[];
    vectorscope: {
      size: typeof COLOR_SCOPE_VECTOR_SIZE;
      density: number[];
    };
  };
  metrics: {
    lumaP01: number;
    lumaMedian: number;
    lumaP99: number;
    shadowClipPercent: number;
    highlightClipPercent: number;
    averageRed: number;
    averageGreen: number;
    averageBlue: number;
    neutralPixelPercent: number;
  };
  assessment: {
    exposure: ExposureAssessment;
    whiteBalance: WhiteBalanceAssessment;
    tint: TintAssessment;
    exposureConfidence: number;
    whiteBalanceConfidence: number;
    reasons: string[];
  };
  correction: {
    brightness: number;
    saturation: number;
    red: number;
    blue: number;
    changesRecommended: boolean;
  };
};

const clamp = (value: number, minimum: number, maximum: number): number =>
  Math.max(minimum, Math.min(maximum, value));

const rounded = (value: number, digits = 4): number => {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
};

const normalizedDistribution = (values: Uint32Array, total: number): number[] =>
  Array.from(values, (value) => rounded(value / Math.max(1, total), 6));

const percentileFromHistogram = (histogram: Uint32Array, total: number, percentile: number): number => {
  const target = Math.max(1, Math.ceil(total * percentile));
  let cumulative = 0;
  for (let index = 0; index < histogram.length; index += 1) {
    cumulative += histogram[index] ?? 0;
    if (cumulative >= target) return index / (histogram.length - 1);
  }
  return 1;
};

/**
 * Analyse packed RGB24 frames. Values are normalized so fixtures, API clients
 * and benchmark evaluators can compare results without depending on FFmpeg.
 */
export const analyzeRgb24ColorScopes = (
  pixels: Uint8Array,
  sampledFrames = 1,
): ColorScopeAnalysis => {
  if (pixels.length === 0 || pixels.length % 3 !== 0) {
    throw new Error("Color scopes require one or more complete RGB24 pixels.");
  }
  if (!Number.isInteger(sampledFrames) || sampledFrames < 1) {
    throw new Error("sampledFrames must be a positive integer.");
  }

  const pixelCount = pixels.length / 3;
  const lumaHistogram = new Uint32Array(COLOR_SCOPE_HISTOGRAM_BINS);
  const redHistogram = new Uint32Array(COLOR_SCOPE_HISTOGRAM_BINS);
  const greenHistogram = new Uint32Array(COLOR_SCOPE_HISTOGRAM_BINS);
  const blueHistogram = new Uint32Array(COLOR_SCOPE_HISTOGRAM_BINS);
  const vectorscope = new Uint32Array(COLOR_SCOPE_VECTOR_SIZE * COLOR_SCOPE_VECTOR_SIZE);
  let redTotal = 0;
  let greenTotal = 0;
  let blueTotal = 0;
  let shadowClips = 0;
  let highlightClips = 0;
  let neutralCount = 0;
  let neutralRed = 0;
  let neutralGreen = 0;
  let neutralBlue = 0;

  for (let offset = 0; offset < pixels.length; offset += 3) {
    const red = pixels[offset] ?? 0;
    const green = pixels[offset + 1] ?? 0;
    const blue = pixels[offset + 2] ?? 0;
    const luma = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
    const lumaBin = Math.min(COLOR_SCOPE_HISTOGRAM_BINS - 1, Math.floor(luma / 256 * COLOR_SCOPE_HISTOGRAM_BINS));
    const channelBin = (channel: number) => Math.min(COLOR_SCOPE_HISTOGRAM_BINS - 1, Math.floor(channel / 256 * COLOR_SCOPE_HISTOGRAM_BINS));
    lumaHistogram[lumaBin] = (lumaHistogram[lumaBin] ?? 0) + 1;
    const redBin = channelBin(red);
    const greenBin = channelBin(green);
    const blueBin = channelBin(blue);
    redHistogram[redBin] = (redHistogram[redBin] ?? 0) + 1;
    greenHistogram[greenBin] = (greenHistogram[greenBin] ?? 0) + 1;
    blueHistogram[blueBin] = (blueHistogram[blueBin] ?? 0) + 1;
    redTotal += red;
    greenTotal += green;
    blueTotal += blue;
    if (luma <= 4) shadowClips += 1;
    if (luma >= 251) highlightClips += 1;

    const maximum = Math.max(red, green, blue);
    const minimum = Math.min(red, green, blue);
    if (maximum - minimum <= 24 && luma >= 26 && luma <= 230) {
      neutralCount += 1;
      neutralRed += red;
      neutralGreen += green;
      neutralBlue += blue;
    }

    // BT.709-style chroma projection, clamped to a normalized vectorscope.
    const u = clamp((-0.1146 * red - 0.3854 * green + 0.5 * blue) / 255 + 0.5, 0, 1);
    const v = clamp((0.5 * red - 0.4542 * green - 0.0458 * blue) / 255 + 0.5, 0, 1);
    const vectorX = Math.min(COLOR_SCOPE_VECTOR_SIZE - 1, Math.floor(u * COLOR_SCOPE_VECTOR_SIZE));
    const vectorY = Math.min(COLOR_SCOPE_VECTOR_SIZE - 1, Math.floor((1 - v) * COLOR_SCOPE_VECTOR_SIZE));
    const vectorIndex = vectorY * COLOR_SCOPE_VECTOR_SIZE + vectorX;
    vectorscope[vectorIndex] = (vectorscope[vectorIndex] ?? 0) + 1;
  }

  const lumaP01 = percentileFromHistogram(lumaHistogram, pixelCount, 0.01);
  const lumaMedian = percentileFromHistogram(lumaHistogram, pixelCount, 0.5);
  const lumaP99 = percentileFromHistogram(lumaHistogram, pixelCount, 0.99);
  const shadowClipPercent = shadowClips / pixelCount * 100;
  const highlightClipPercent = highlightClips / pixelCount * 100;
  const neutralPixelPercent = neutralCount / pixelCount * 100;
  const neutralAverageRed = neutralCount ? neutralRed / neutralCount : redTotal / pixelCount;
  const neutralAverageGreen = neutralCount ? neutralGreen / neutralCount : greenTotal / pixelCount;
  const neutralAverageBlue = neutralCount ? neutralBlue / neutralCount : blueTotal / pixelCount;
  const temperatureBias = (neutralAverageRed - neutralAverageBlue) / 255;
  const tintBias = (neutralAverageGreen - (neutralAverageRed + neutralAverageBlue) / 2) / 255;
  const severeClipping = shadowClipPercent > 2 || highlightClipPercent > 2;
  const exposure: ExposureAssessment = severeClipping
    ? "clipped"
    : lumaMedian < 0.32 && lumaP99 < 0.94
      ? "underexposed"
      : lumaMedian > 0.68 && lumaP01 > 0.03
        ? "overexposed"
        : "balanced";
  const whiteBalance: WhiteBalanceAssessment = temperatureBias > 0.035
    ? "warm"
    : temperatureBias < -0.035 ? "cool" : "balanced";
  const tint: TintAssessment = tintBias > 0.025
    ? "green"
    : tintBias < -0.025 ? "magenta" : "balanced";
  const exposureConfidence = clamp(0.7 + Math.min(0.25, sampledFrames * 0.08), 0, 0.95);
  const whiteBalanceConfidence = clamp(neutralPixelPercent / 8, 0, 0.95);

  let brightness = clamp(0.45 - lumaMedian, -0.12, 0.12);
  if ((highlightClipPercent > 2 && brightness > 0) || (shadowClipPercent > 2 && brightness < 0)) brightness = 0;
  const whiteBalanceReliable = neutralPixelPercent >= 1;
  const red = whiteBalanceReliable ? clamp(-(neutralAverageRed - neutralAverageGreen) / 255, -0.08, 0.08) : 0;
  const blue = whiteBalanceReliable ? clamp(-(neutralAverageBlue - neutralAverageGreen) / 255, -0.08, 0.08) : 0;
  if (exposure === "balanced") brightness = 0;
  const reasons: string[] = [];
  if (exposure === "underexposed") reasons.push(`Median luma is ${Math.round(lumaMedian * 100)} IRE-equivalent.`);
  if (exposure === "overexposed") reasons.push(`Median luma is ${Math.round(lumaMedian * 100)} IRE-equivalent.`);
  if (severeClipping) reasons.push(`Clipping is ${rounded(shadowClipPercent, 2)}% shadows and ${rounded(highlightClipPercent, 2)}% highlights.`);
  if (!whiteBalanceReliable) reasons.push("Too few neutral pixels for a reliable white-balance correction.");
  else if (whiteBalance !== "balanced" || tint !== "balanced") reasons.push(`Neutral pixels indicate ${whiteBalance} temperature and ${tint} tint.`);
  if (reasons.length === 0) reasons.push("Exposure and neutral balance are within conservative finishing thresholds.");

  const correction = {
    brightness: rounded(brightness),
    saturation: 1,
    red: rounded(red),
    blue: rounded(blue),
    changesRecommended: Math.abs(brightness) >= 0.01 || Math.abs(red) >= 0.01 || Math.abs(blue) >= 0.01,
  };

  return {
    version: ATTELIER_COLOR_ASSIST_VERSION,
    sampledFrames,
    sampledPixels: pixelCount,
    scopes: {
      histogramBins: COLOR_SCOPE_HISTOGRAM_BINS,
      luma: normalizedDistribution(lumaHistogram, pixelCount),
      red: normalizedDistribution(redHistogram, pixelCount),
      green: normalizedDistribution(greenHistogram, pixelCount),
      blue: normalizedDistribution(blueHistogram, pixelCount),
      vectorscope: { size: COLOR_SCOPE_VECTOR_SIZE, density: normalizedDistribution(vectorscope, pixelCount) },
    },
    metrics: {
      lumaP01: rounded(lumaP01),
      lumaMedian: rounded(lumaMedian),
      lumaP99: rounded(lumaP99),
      shadowClipPercent: rounded(shadowClipPercent, 3),
      highlightClipPercent: rounded(highlightClipPercent, 3),
      averageRed: rounded(redTotal / pixelCount / 255),
      averageGreen: rounded(greenTotal / pixelCount / 255),
      averageBlue: rounded(blueTotal / pixelCount / 255),
      neutralPixelPercent: rounded(neutralPixelPercent, 3),
    },
    assessment: {
      exposure,
      whiteBalance,
      tint,
      exposureConfidence: rounded(exposureConfidence),
      whiteBalanceConfidence: rounded(whiteBalanceConfidence),
      reasons,
    },
    correction,
  };
};
