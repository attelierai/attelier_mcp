import type { ProjectTransaction, TransactionResult } from "@attelier/project-schema";

export * from "@attelier/agent-schema/session";
export * from "@attelier/agent-schema/project-plan";

export type AgentSelection = {
  elementId?: string;
  assetId?: string;
  start?: string;
  end?: string;
};

export type AgentCostQuote = {
  currency: "USD";
  amount: number;
  reservationRequired: boolean;
  reservationId?: string;
};

/** Exact planner inputs needed to reproduce and compare an agent decision. */
export type AgentRunProvenance = {
  harnessId: string;
  harnessVersion: string;
  plannerId: string;
  plannerVersion: string;
  promptVersion: string;
  catalogVersion: string;
  craftGuideVersion: string;
  effectCatalogVersion: string;
  toolCatalogVersion: string;
  tools: Array<{ id: string; version: string }>;
  modelRegistryVersion: string;
  skills: Array<{ id: string; version: string }>;
  effects: Array<{ id: string; version: number }>;
  decisions: string[];
  model: {
    provider: string;
    id: string;
    version: string;
  };
};

export type AgentPlan = {
  id: string;
  traceId: string;
  projectId: string;
  baseRevision: number;
  prompt: string;
  goal: string;
  summary: string;
  provider: string;
  provenance: AgentRunProvenance;
  transaction: ProjectTransaction;
  simulation: TransactionResult;
  costQuote: AgentCostQuote;
  createdAt: number;
};
