export const ATTELIER_PROJECT_PLAN_SCHEMA_VERSION = 1 as const;

export type AttelierProjectPlanBeat = {
  id: string;
  title: string;
  description?: string;
  milestone?: string;
  purpose?: string;
  visual?: string;
  durationSeconds?: number;
  assetPlan?: string;
};

export type AttelierBriefScriptLine = {
  id: string;
  speaker?: string;
  line: string;
  scene?: string;
};

export type AttelierBriefCharacter = {
  name: string;
  role: string;
  description?: string;
};

export type AttelierBriefReference = {
  kind: "image" | "video" | "url";
  assetId?: string;
  url?: string;
  note: string;
  observation?: { timestampsSeconds: number[]; observed: string[]; unobserved: string[] };
};

/** Explicit creator decisions, not agent suggestions or applied timeline facts. */
export type AttelierCreativeDecision = {
  id: string;
  aspect: string;
  instruction: string;
  status: "accepted" | "rejected";
  assetIds?: string[];
  elementIds?: string[];
};

export type AttelierProjectBrief = {
  title: string;
  logline?: string;
  script: AttelierBriefScriptLine[];
  characters: AttelierBriefCharacter[];
  references?: AttelierBriefReference[];
  decisions?: AttelierCreativeDecision[];
  style?: {
    profile?: string;
    lowerThirdTemplate?: string;
    look?: string;
  };
  /** Markdown sections that do not map to a structured brief field. */
  notes?: string;
};

/**
 * Creator-facing direction shared by Studio and every headless harness client.
 * Timeline revisions remain independent: changing the working script or beats
 * must never rewrite editorial or spend history.
 */
export type AttelierProjectPlanContent = {
  logline?: string;
  audience?: string;
  channel?: string;
  tone?: string;
  cta?: string;
  script?: string;
  /**
   * The delivery quality profile this piece is judged under — the declaration
   * that chooses which deterministic gates block an export. A documentary and a
   * product ad are not the same piece of work and must not be gated the same
   * way, and inferring the profile from the canvas guesses wrong as often as it
   * guesses right.
   *
   * One of `QUALITY_PROFILE_IDS` in `@attelier/capability-schema/project-quality`;
   * the agent schema does not import the capability schema, so it is carried as
   * a validated string and the API rejects an unknown id.
   */
  profile?: string;
  brief?: AttelierProjectBrief;
  beats: AttelierProjectPlanBeat[];
};

export type AttelierProjectPlanPatch = Partial<Omit<AttelierProjectPlanContent, "beats">> & {
  beats?: AttelierProjectPlanBeat[];
};

export type AttelierProjectPlan = AttelierProjectPlanContent & {
  schemaVersion: typeof ATTELIER_PROJECT_PLAN_SCHEMA_VERSION;
  projectId: string;
  version: number;
  updatedAt: number | null;
  updatedBy: string | null;
};

export type EditorialPlan = {
  id: string; projectId: string; version: number; briefVersion: number; baseRevision: number;
  sessionId: string; proposalId: string; direction: string; rationale: string; expectedResult: string;
  estimatedCostUsd: number; diagnosis: string; evidenceIds: string[]; pendingReview: string[];
  status: "pending" | "applied" | "discarded" | "invalidated";
  /** Independent of whether its historical transaction was applied. */
  currency: "current" | "superseded";
  createdBy: string; createdAt: number; fingerprint: string; idempotencyKey: string;
  changes?: string[];
  deliveryReview?: { renderJobId: string; revision: number; renderSha256?: string; briefVersion?: number; summary: string; findings: string[]; unobserved: string[] };
};
export type EditorialPlanInput = {
  action: "get" | "propose" | "accept" | "discard";
  expectedVersion?: number; expectedRevision?: number; idempotencyKey?: string;
  direction?: string; rationale?: string; expectedResult?: string; diagnosis?: string;
  estimatedCostUsd?: number; evidenceIds?: string[]; pendingReview?: string[];
  calls?: Array<{ tool: string; arguments: Record<string, unknown> }>;
};
