export const ATTELIER_SESSION_SCHEMA_VERSION = 1 as const;

export type AttelierJsonPrimitive = string | number | boolean | null;
export type AttelierJsonValue = AttelierJsonPrimitive | AttelierJsonValue[] | { [key: string]: AttelierJsonValue };
export type AttelierJsonObject = { [key: string]: AttelierJsonValue };

export type AttelierGoalStatus = "active" | "paused" | "blocked" | "complete";

export type AttelierSessionGoal = {
  objective: string;
  status: AttelierGoalStatus;
  createdAt: number;
  updatedAt: number;
};

export type AttelierRoutingPolicy = "balanced" | "quality" | "cost";

export const ATTELIER_MEDIA_FAMILIES = ["video", "image", "voice", "music", "effects"] as const;
export type AttelierMediaFamily = typeof ATTELIER_MEDIA_FAMILIES[number];

export type AttelierModelSelection =
  | { mode: "auto"; policy: AttelierRoutingPolicy }
  | { mode: "pinned"; modelId: string };

export type AttelierMediaRouters = Record<AttelierMediaFamily, AttelierModelSelection>;

export type AttelierSessionMessage = {
  eventId: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt: number;
};

export type AttelierSessionFork = {
  sessionId: string;
  sequence: number;
};

export type AttelierSessionEventEnvelope<Type extends string, Data extends AttelierJsonObject> = {
  schemaVersion: typeof ATTELIER_SESSION_SCHEMA_VERSION;
  eventId: string;
  sessionId: string;
  sequence: number;
  createdAt: number;
  type: Type;
  data: Data;
};

export type AttelierSessionEvent =
  | AttelierSessionEventEnvelope<"action.updated", {
      actionId: string; runId: string; projectId: string; toolName: string; input: AttelierJsonObject;
      status: "pending" | "quoted" | "running" | "complete" | "discarded";
      quote?: AttelierJsonObject; jobId?: string; placementProposalId?: string;
    }>
  | AttelierSessionEventEnvelope<"tool.policy.changed", { disabledTools: string[] }>
  | AttelierSessionEventEnvelope<"review.created", Omit<AttelierSessionReview, "id"> & { reviewId: string }>
  | AttelierSessionEventEnvelope<"history.cleared", Record<string, never>>
  | AttelierSessionEventEnvelope<"turn.requested", { runId: string; fingerprint: string; reservedUsd?: number }>
  | AttelierSessionEventEnvelope<"turn.finished", { runId: string; status: number; result: AttelierJsonObject }>
  | AttelierSessionEventEnvelope<"proposal.created", {
      proposalId: string; runId: string; projectId: string; baseRevision: number;
      toolName: string; explanation: string; transaction: AttelierJsonObject; simulation: AttelierJsonObject;
    }>
  | AttelierSessionEventEnvelope<"proposal.resolved", {
      proposalId: string; status: "applied" | "discarded" | "invalidated"; revision?: number;
    }>
  | AttelierSessionEventEnvelope<"session.created", {
      title: string;
      workingDirectory: string;
      model: AttelierModelSelection;
      mediaRouters?: Partial<AttelierMediaRouters>;
      /** Replay-only compatibility for sessions created before family-scoped routers. */
      mediaRouting?: AttelierModelSelection;
      projectId: string | null;
      pipelineId?: string;
      /** Optional lineage for an explicit history fork. */
      forkedFrom?: AttelierSessionFork;
      /** Forked sessions may inherit durable working state without replaying history. */
      budgetUsd?: number | null;
      goal?: AttelierSessionGoal | null;
      /** When true, this terminal session is edit-only: no model or media capability may start. */
      aiLocked?: boolean;
    }>
  | AttelierSessionEventEnvelope<"session.resumed", {
      workingDirectory: string;
      client: "terminal" | "studio" | "api";
    }>
  | AttelierSessionEventEnvelope<"message.appended", {
      role: "user" | "assistant" | "system";
      content: string;
      audience: "model" | "ui" | "both";
    }>
  | AttelierSessionEventEnvelope<"goal.changed", {
      action: "set" | "edit" | "pause" | "resume" | "block" | "complete" | "clear";
      goal: AttelierSessionGoal | null;
    }>
  | AttelierSessionEventEnvelope<"model.changed", {
      selection: AttelierModelSelection;
    }>
  | AttelierSessionEventEnvelope<"ai.lock.changed", {
      locked: boolean;
    }>
  | AttelierSessionEventEnvelope<"media_routing.changed", {
      selection: AttelierModelSelection;
    }>
  | AttelierSessionEventEnvelope<"media_router.changed", {
      family: AttelierMediaFamily;
      selection: AttelierModelSelection;
    }>
  | AttelierSessionEventEnvelope<"routing.decision.recorded", {
      runId: string;
      target: "planner" | "capability" | AttelierMediaFamily;
      intent: string;
      policy: AttelierRoutingPolicy | "manual";
      selectedId: string;
      candidateIds: string[];
      reason: string;
      registryVersion: string;
      fallback: boolean;
    }>
  | AttelierSessionEventEnvelope<"planner.thread.bound", {
      providerId: string;
      modelId: string;
      threadId: string;
    }>
  | AttelierSessionEventEnvelope<"budget.changed", {
      budgetUsd: number | null;
    }>
  | AttelierSessionEventEnvelope<"project.selected", {
      projectId: string | null;
    }>
  | AttelierSessionEventEnvelope<"project.plan.updated", {
      runId: string;
      projectId: string;
      version: number;
      changedFields: string[];
    }>
  | AttelierSessionEventEnvelope<"run.started", {
      runId: string;
      kind: "plan" | "edit" | "analysis" | "capability" | "render" | "workflow" | "version" | "inspect";
      summary: string;
      cancellable?: boolean;
    }>
  | AttelierSessionEventEnvelope<"run.completed", {
      runId: string;
      summary: string;
    }>
  | AttelierSessionEventEnvelope<"run.failed", {
      runId: string;
      error: string;
    }>
  | AttelierSessionEventEnvelope<"run.waiting", { runId: string; summary: string }>
  | AttelierSessionEventEnvelope<"run.stop_requested", { runId: string }>
  | AttelierSessionEventEnvelope<"run.cancelled", { runId: string; summary: string }>
  | AttelierSessionEventEnvelope<"run.interrupted", {
      runId: string;
      message: string;
    }>
  | AttelierSessionEventEnvelope<"tool.started", {
      runId: string;
      callId: string;
      toolName: string;
      input: AttelierJsonObject;
    }>
  | AttelierSessionEventEnvelope<"tool.completed", {
      runId: string;
      callId: string;
      toolName: string;
      output: AttelierJsonValue;
    }>
  | AttelierSessionEventEnvelope<"tool.failed", {
      runId: string;
      callId: string;
      toolName: string;
      error: string;
    }>
  | AttelierSessionEventEnvelope<"plan.updated", {
      runId: string;
      planId: string;
      projectId: string;
      baseRevision: number;
      summary: string;
      transaction: AttelierJsonObject;
    }>
  | AttelierSessionEventEnvelope<"project.revision.created", {
      runId: string;
      projectId: string;
      revision: number;
      transactionId: string;
    }>
  | AttelierSessionEventEnvelope<"project.revision.restored", {
      runId: string;
      projectId: string;
      intent: "undo" | "redo" | "restore";
      previousRevision: number;
      targetRevision: number;
      revision: number;
    }>
  | AttelierSessionEventEnvelope<"capability.requested", {
      runId: string;
      capability: string;
      input: AttelierJsonObject;
      idempotencyKey: string;
    }>
  | AttelierSessionEventEnvelope<"capability.quoted", {
      runId: string;
      quoteId: string;
      capability: string;
      providerId: string;
      model: string;
      currency: "USD";
      amount: number;
      approvalRequired: boolean;
      reservationRequired: boolean;
    }>
  | AttelierSessionEventEnvelope<"approval.resolved", {
      runId: string;
      quoteId: string;
      decision: "approved" | "declined" | "blocked";
      actor: "user" | "harness";
    }>
  | AttelierSessionEventEnvelope<"spend.reserved", {
      runId: string;
      reservationId: string;
      quoteId: string;
      currency: "USD";
      amount: number;
    }>
  | AttelierSessionEventEnvelope<"spend.released", {
      runId: string;
      reservationId: string;
      currency: "USD";
      amount: number;
    }>
  | AttelierSessionEventEnvelope<"spend.settled", {
      runId: string;
      reservationId: string;
      currency: "USD";
      amount: number;
    }>
  | AttelierSessionEventEnvelope<"spend.reconciliation_pending", {
      runId: string;
      reservationId: string;
      currency: "USD";
      amount: number;
    }>
  | AttelierSessionEventEnvelope<"capability.job.updated", {
      runId: string;
      jobId: string;
      capability: string;
      providerId: string;
      status: "queued" | "running" | "complete" | "failed" | "cancelled";
      progress: number;
      /** Provider observation time. Optional for schema-v1 replay compatibility. */
      jobUpdatedAt?: number;
    }>
  | AttelierSessionEventEnvelope<"render.job.updated", {
      runId: string;
      jobId: string;
      projectId: string;
      revision: number;
      format: "mp4" | "webm" | "mov" | "audio" | "image_sequence";
      status: "queued" | "running" | "complete" | "failed" | "cancelled" | "rejected";
      progress: number;
      jobUpdatedAt?: number;
    }>
  | AttelierSessionEventEnvelope<"usage.recorded", {
      runId: string;
      resourceType: "model" | "capability" | "effect" | "render" | "workflow";
      resourceId: string;
      providerId: string;
      model: string | null;
      currency: "USD";
      estimatedAmount: number;
      actualAmount: number;
      pricingStatus?: "actual" | "estimated" | "unavailable";
      inputTokens?: number;
      outputTokens?: number;
      cachedInputTokens?: number;
      cacheWriteInputTokens?: number;
      reasoningTokens?: number;
      /** Turn cost including this round, so a surface can show a running total
       * on the round chip while the agentic loop is still working. */
      runningCostUsd?: number;
    }>;

export type AttelierSessionEventInput = AttelierSessionEvent extends infer Event
  ? Event extends AttelierSessionEventEnvelope<infer Type, infer Data>
    ? { type: Type; data: Data; eventId?: string }
    : never
  : never;

export type AttelierSessionRunProjection = {
  id: string;
  kind: "plan" | "edit" | "analysis" | "capability" | "render" | "workflow" | "version" | "inspect";
  status: "running" | "stopping" | "waiting" | "complete" | "failed" | "interrupted" | "cancelled";
  summary: string;
  cancellable?: boolean;
  error?: string;
};

export type AttelierPendingPlan = {
  runId: string;
  planId: string;
  projectId: string;
  baseRevision: number;
  summary: string;
  transaction: AttelierJsonObject;
};

export type AttelierLastRestore = {
  intent: "undo" | "redo" | "restore";
  previousRevision: number;
  targetRevision: number;
  revision: number;
};

export type AttelierRoutingDecision = {
  runId: string;
  target: "planner" | "capability" | AttelierMediaFamily;
  intent: string;
  policy: AttelierRoutingPolicy | "manual";
  selectedId: string;
  candidateIds: string[];
  reason: string;
  registryVersion: string;
  fallback: boolean;
};

export type AttelierPlannerThread = {
  providerId: string;
  modelId: string;
  threadId: string;
};

export type AttelierCapabilityJobProjection = {
  runId: string;
  jobId: string;
  capability: string;
  providerId: string;
  status: "queued" | "running" | "complete" | "failed" | "cancelled";
  progress: number;
  updatedAt: number;
};

export type AttelierRenderJobProjection = {
  runId: string;
  jobId: string;
  projectId: string;
  revision: number;
  format: "mp4" | "webm" | "mov" | "audio" | "image_sequence";
  status: "queued" | "running" | "complete" | "failed" | "cancelled" | "rejected";
  progress: number;
  updatedAt: number;
};

export type AttelierSessionProjection = {
  schemaVersion: typeof ATTELIER_SESSION_SCHEMA_VERSION;
  id: string;
  title: string;
  workingDirectory: string;
  createdAt: number;
  updatedAt: number;
  lastSequence: number;
  /** Live server authority; event-only/offline projections omit these reservations. */
  modelBudget?: { reservedUsd: number; pendingUsd: number };
  forkedFrom?: AttelierSessionFork | null;
  projectId: string | null;
  pipelineId?: string;
  projectPlanVersion?: number | null;
  model: AttelierModelSelection;
  mediaRouters: AttelierMediaRouters;
  /** Edit-only safety state, durable across terminal resumes and forks. */
  /** Omitted only by legacy projections; omitted means unlocked. */
  aiLocked?: boolean;
  budgetUsd: number | null;
  goal: AttelierSessionGoal | null;
  messages: AttelierSessionMessage[];
  activeRun: AttelierSessionRunProjection | null;
  lastRun: AttelierSessionRunProjection | null;
  pendingPlan: AttelierPendingPlan | null;
  /** Absent only in older projections. Legacy plans are not invented proposals. */
  proposals?: AttelierSessionProposal[];
  actions?: AttelierSessionAction[];
  reviews?: AttelierSessionReview[];
  disabledTools?: string[];
  projectRevision: number | null;
  lastRestore: AttelierLastRestore | null;
  lastRoutingDecision: AttelierRoutingDecision | null;
  plannerThread: AttelierPlannerThread | null;
  capabilityJobs: AttelierCapabilityJobProjection[];
  renderJobs: AttelierRenderJobProjection[];
  usage: {
    currency: "USD";
    quotedAmount: number;
    reservedAmount: number;
    pendingReconciliationAmount: number;
    estimatedAmount: number;
    actualAmount: number;
    modelInputTokens: number;
    modelOutputTokens: number;
    modelCachedInputTokens: number;
    modelCacheWriteInputTokens: number;
    modelReasoningTokens: number;
    unpricedModelTurns: number;
  };
};

export type AttelierSessionProposal = {
  id: string; runId: string; projectId: string; baseRevision: number;
  toolName: string; explanation: string; transaction: AttelierJsonObject; simulation: AttelierJsonObject;
  status: "pending" | "applied" | "discarded" | "invalidated";
  revision?: number;
};

export type AttelierSessionAction = {
  id: string; runId: string; projectId: string; toolName: string; input: AttelierJsonObject;
  status: "pending" | "quoted" | "running" | "complete" | "discarded";
  quote?: AttelierJsonObject; jobId?: string;
  placementProposalId?: string;
};

export type AttelierSessionReview = {
  id: string; runId: string; projectId: string; revision: number;
  kind?: "cut" | "visual"; model?: string; verdict?: string;
  frames?: Array<{ atSeconds: number; url: string }>;
  range: { startSeconds: number; endSeconds: number };
  counts: { errors: number; warnings: number; infos: number };
  coverage: { clipsWithTranscript: number; clipsWithAudioAnalysis: number; framesReviewed?: number };
  issues: Array<{ severity: "error" | "warning" | "info"; code: string; atSeconds: number; message: string; elementIds: string[]; elementNames: string[] }>;
};
